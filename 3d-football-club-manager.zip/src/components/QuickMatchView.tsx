"use client";

import React, { useState } from "react";
import {
  CareerState,
  DIVISION_CLUB_NAMES,
  DIVISIONS_META,
  FormationName,
  generateStartingSquad,
  KitConfig,
  makeShortName,
} from "@/lib/gameData";
import { ClubBadge } from "@/components/ClubBadge";
import { Moon, Play, Shield, Sparkles, Sun, Swords } from "lucide-react";

interface QuickMatchViewProps {
  career: CareerState;
  onStartQuickMatch: (config: {
    homeName: string;
    homeShort: string;
    homeKit: KitConfig;
    homeFormation: FormationName;
    awayName: string;
    awayShort: string;
    awayKit: KitConfig;
    awayFormation: FormationName;
    awayDivId: number;
    stadiumTier: number;
    nightMatch: boolean;
  }) => void;
}

export function QuickMatchView({
  career,
  onStartQuickMatch,
}: QuickMatchViewProps) {
  const [selectedDivId, setSelectedDivId] = useState<number>(0); // Default to Premier Division opponents for fun or any division
  const [selectedOpponentIdx, setSelectedOpponentIdx] = useState<number>(0);
  const [stadiumTier, setStadiumTier] = useState<number>(4);
  const [nightMatch, setNightMatch] = useState<boolean>(true);
  const [userFormation, setUserFormation] = useState<FormationName>(
    career.formation
  );

  const opponentList = DIVISION_CLUB_NAMES[selectedDivId] || DIVISION_CLUB_NAMES[0];
  const opponentName = opponentList[selectedOpponentIdx] || opponentList[0];

  const handleLaunch = () => {
    onStartQuickMatch({
      homeName: career.club.name,
      homeShort: career.club.shortName,
      homeKit: career.club.homeKit,
      homeFormation: userFormation,
      awayName: opponentName,
      awayShort: makeShortName(opponentName),
      awayKit: {
        pattern: "stripes",
        primaryColor: "#EF4444",
        secondaryColor: "#1E293B",
        shortsColor: "#0F172A",
        socksColor: "#EF4444",
      },
      awayFormation: "4-3-3",
      awayDivId: selectedDivId,
      stadiumTier,
      nightMatch,
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4 mb-6">
          <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
            <Swords className="w-6 h-6" />
          </div>
          <div>
            <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-400">
              Exhibition 3D Match Mode
            </div>
            <h2 className="text-xl font-black uppercase text-white">
              Quick Match 3D Arena Setup
            </h2>
            <p className="text-xs text-slate-400">
              Test your squad and tactics against any club from Division 5 to the Premier Division in a standalone 3D match.
            </p>
          </div>
        </div>

        {/* Matchup Header */}
        <div className="grid grid-cols-1 md:grid-cols-7 gap-4 items-center bg-slate-900/90 border border-slate-800 rounded-2xl p-5 mb-6">
          <div className="md:col-span-3 flex items-center gap-3.5">
            <ClubBadge badge={career.club.badge} size={60} />
            <div>
              <div className="text-[10px] font-bold uppercase text-emerald-400">
                Home Team (You)
              </div>
              <div className="text-lg font-black text-white">
                {career.club.name}
              </div>
              <div className="text-xs text-slate-400">
                Formation: {userFormation}
              </div>
            </div>
          </div>

          <div className="md:col-span-1 text-center">
            <span className="inline-block px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 font-mono text-sm font-black text-amber-400">
              VS
            </span>
          </div>

          <div className="md:col-span-3 flex items-center justify-end gap-3.5 text-right">
            <div>
              <div className="text-[10px] font-bold uppercase text-amber-400">
                Away Opponent
              </div>
              <div className="text-lg font-black text-white">{opponentName}</div>
              <div className="text-xs text-slate-400">
                {DIVISIONS_META.find((d) => d.id === selectedDivId)?.name} • Avg{" "}
                {DIVISIONS_META.find((d) => d.id === selectedDivId)?.avgOvr} OVR
              </div>
            </div>
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center font-mono font-black text-rose-400">
              {makeShortName(opponentName)}
            </div>
          </div>
        </div>

        {/* Settings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-300 mb-2">
              1. Select Opponent Division
            </label>
            <div className="grid grid-cols-3 gap-2">
              {DIVISIONS_META.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => {
                    setSelectedDivId(d.id);
                    setSelectedOpponentIdx(0);
                  }}
                  className={`py-2 px-2.5 rounded-xl border text-xs font-bold uppercase transition ${
                    selectedDivId === d.id
                      ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                      : "bg-slate-900 border-slate-800 text-slate-400"
                  }`}
                >
                  {d.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-300 mb-2">
              2. Select Opponent Club (20 Clubs in Division)
            </label>
            <select
              value={selectedOpponentIdx}
              onChange={(e) => setSelectedOpponentIdx(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm font-semibold focus:border-emerald-500 focus:outline-none"
            >
              {opponentList.map((clubName, idx) => (
                <option key={clubName} value={idx}>
                  {clubName} ({makeShortName(clubName)})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-300 mb-2">
              3. 3D Stadium Tier & Capacity
            </label>
            <div className="grid grid-cols-5 gap-2">
              {[1, 2, 3, 4, 5].map((tier) => (
                <button
                  key={tier}
                  type="button"
                  onClick={() => setStadiumTier(tier)}
                  className={`py-2 rounded-xl border font-mono text-xs font-bold transition ${
                    stadiumTier === tier
                      ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                      : "bg-slate-900 border-slate-800 text-slate-400"
                  }`}
                >
                  Tier {tier}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-300 mb-2">
              4. Lighting & Match Atmosphere
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setNightMatch(true)}
                className={`flex items-center justify-center gap-2 py-2 rounded-xl border text-xs font-bold uppercase transition ${
                  nightMatch
                    ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                    : "bg-slate-900 border-slate-800 text-slate-400"
                }`}
              >
                <Moon className="w-4 h-4" />
                Night Floodlights
              </button>
              <button
                type="button"
                onClick={() => setNightMatch(false)}
                className={`flex items-center justify-center gap-2 py-2 rounded-xl border text-xs font-bold uppercase transition ${
                  !nightMatch
                    ? "bg-amber-500/20 border-amber-500 text-amber-300"
                    : "bg-slate-900 border-slate-800 text-slate-400"
                }`}
              >
                <Sun className="w-4 h-4" />
                Daylight Sunshine
              </button>
            </div>
          </div>
        </div>

        <button
          onClick={handleLaunch}
          className="mt-6 w-full py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black uppercase tracking-wider text-sm shadow-xl flex items-center justify-center gap-2 transition"
        >
          <Play className="w-5 h-5 fill-current" />
          Kick Off 3D Exhibition Match Now
        </button>
      </div>
    </div>
  );
}
