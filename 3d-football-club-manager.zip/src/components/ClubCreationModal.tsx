"use client";

import React, { useState } from "react";
import {
  BadgeConfig,
  BadgeIcon,
  BadgePattern,
  BadgeShape,
  ClubIdentity,
  DIVISIONS_META,
  KitConfig,
  KitPattern,
  makeShortName,
} from "@/lib/gameData";
import { ClubBadge, KitJerseyPreview } from "@/components/ClubBadge";
import { PlayerKit3DPreview } from "@/components/Stadium3DPreview";
import {
  CheckCircle2,
  Palette,
  Shield,
  Shirt,
  Sparkles,
  Trophy,
  Wand2,
} from "lucide-react";

interface ClubCreationModalProps {
  initialClub: ClubIdentity;
  onComplete: (club: ClubIdentity) => void;
  onClose?: () => void;
  isNewCareer?: boolean;
}

const COUNTRIES = [
  { name: "England", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", leaguePrefix: "English" },
  { name: "Spain", flag: "🇪🇸", leaguePrefix: "Spanish" },
  { name: "Germany", flag: "🇩🇪", leaguePrefix: "German" },
  { name: "Italy", flag: "🇮🇹", leaguePrefix: "Italian" },
  { name: "France", flag: "🇫🇷", leaguePrefix: "French" },
  { name: "Brazil", flag: "🇧🇷", leaguePrefix: "Brazilian" },
  { name: "Netherlands", flag: "🇳🇱", leaguePrefix: "Dutch" },
  { name: "Portugal", flag: "🇵🇹", leaguePrefix: "Portuguese" },
];

const PRESET_CLUBS = [
  {
    name: "Oakwood Rovers FC",
    stadium: "Oakwood Community Ground",
    primary: "#10B981",
    secondary: "#0F172A",
    accent: "#F59E0B",
  },
  {
    name: "Redcliffe Athletic",
    stadium: "Redcliffe Iron Arena",
    primary: "#EF4444",
    secondary: "#FFFFFF",
    accent: "#FACC15",
  },
  {
    name: "Cobalt Harbor FC",
    stadium: "Harborfront Park",
    primary: "#2563EB",
    secondary: "#0F172A",
    accent: "#38BDF8",
  },
  {
    name: "Valhalla United",
    stadium: "Nordic Crown Stadium",
    primary: "#7C3AED",
    secondary: "#18181B",
    accent: "#FDE047",
  },
];

export function ClubCreationModal({
  initialClub,
  onComplete,
  onClose,
  isNewCareer = true,
}: ClubCreationModalProps) {
  const [name, setName] = useState(initialClub.name);
  const [managerName, setManagerName] = useState(initialClub.managerName);
  const [stadiumName, setStadiumName] = useState(initialClub.stadiumName);
  const [country, setCountry] = useState(initialClub.country || "England");
  const [startingDivisionId, setStartingDivisionId] = useState(
    initialClub.startingDivisionId ?? 5
  );
  const [badge, setBadge] = useState<BadgeConfig>(initialClub.badge);
  const [homeKit, setHomeKit] = useState<KitConfig>(initialClub.homeKit);
  const [awayKit, setAwayKit] = useState<KitConfig>(initialClub.awayKit);
  const [activeTab, setActiveTab] = useState<"identity" | "badge" | "kits">(
    "identity"
  );
  const [previewKitMode, setPreviewKitMode] = useState<"home" | "away">("home");

  const handleRandomize = () => {
    const preset =
      PRESET_CLUBS[Math.floor(Math.random() * PRESET_CLUBS.length)];
    const shapes: BadgeShape[] = [
      "classic",
      "hexagon",
      "royal",
      "diamond",
      "circle",
    ];
    const patterns: BadgePattern[] = [
      "stripes",
      "sash",
      "quartered",
      "solid",
      "chevron",
    ];
    const icons: BadgeIcon[] = [
      "lion",
      "eagle",
      "crown",
      "star",
      "ball",
      "lightning",
      "anchor",
      "flame",
    ];
    const kitPatterns: KitPattern[] = [
      "solid",
      "stripes",
      "hoops",
      "sash",
      "halves",
    ];

    setName(preset.name);
    setStadiumName(preset.stadium);
    setBadge({
      shape: shapes[Math.floor(Math.random() * shapes.length)],
      pattern: patterns[Math.floor(Math.random() * patterns.length)],
      icon: icons[Math.floor(Math.random() * icons.length)],
      primaryColor: preset.primary,
      secondaryColor: preset.secondary,
      accentColor: preset.accent,
    });
    setHomeKit({
      pattern: kitPatterns[Math.floor(Math.random() * kitPatterns.length)],
      primaryColor: preset.primary,
      secondaryColor: preset.secondary,
      shortsColor: "#0F172A",
      socksColor: preset.primary,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = name.trim() || "Oakwood Rovers FC";
    onComplete({
      name: finalName,
      shortName: makeShortName(finalName),
      managerName: managerName.trim() || "Alex Mercer",
      stadiumName: stadiumName.trim() || "Community Park",
      country,
      startingDivisionId,
      badge,
      homeKit,
      awayKit,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-lg flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="w-full max-w-5xl bg-[#0F1623] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950/90 via-slate-900 to-slate-900 px-6 py-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase tracking-wider text-white">
                {isNewCareer
                  ? "Found Your Football Club — 3D Studio"
                  : "Customize Club Identity & Kits"}
              </h2>
              <p className="text-xs text-slate-400">
                Design your badge, home & away kits, stadium name, country, and starting division.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRandomize}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-400 border border-slate-700 transition"
            >
              <Wand2 className="w-3.5 h-3.5" />
              Randomize Preset
            </button>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300"
              >
                Cancel
              </button>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12">
          {/* Left 7 Cols: Customization Controls */}
          <div className="lg:col-span-7 p-6 space-y-5 border-b lg:border-b-0 lg:border-r border-slate-800">
            {/* Step Navigation Tabs */}
            <div className="grid grid-cols-3 gap-2 bg-slate-900/90 p-1.5 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setActiveTab("identity")}
                className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                  activeTab === "identity"
                    ? "bg-emerald-500 text-slate-950 shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Shield className="w-4 h-4" />
                1. Club & League
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("badge")}
                className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                  activeTab === "badge"
                    ? "bg-emerald-500 text-slate-950 shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Palette className="w-4 h-4" />
                2. Custom Badge
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("kits")}
                className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                  activeTab === "kits"
                    ? "bg-emerald-500 text-slate-950 shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <Shirt className="w-4 h-4" />
                3. Home & Away Kits
              </button>
            </div>

            {/* TAB 1: CLUB IDENTITY, COUNTRY & STARTING LEAGUE */}
            {activeTab === "identity" && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Club Name
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Oakwood Rovers FC"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm font-semibold focus:border-emerald-500 focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Manager / Owner Name
                    </label>
                    <input
                      type="text"
                      value={managerName}
                      onChange={(e) => setManagerName(e.target.value)}
                      placeholder="e.g. Alex Mercer"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm font-semibold focus:border-emerald-500 focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Stadium Name
                  </label>
                  <input
                    type="text"
                    value={stadiumName}
                    onChange={(e) => setStadiumName(e.target.value)}
                    placeholder="e.g. Oakwood Park Arena"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm font-semibold focus:border-emerald-500 focus:outline-none"
                    required
                  />
                </div>

                {/* Starting Country Selector */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Starting Country
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {COUNTRIES.map((c) => (
                      <button
                        key={c.name}
                        type="button"
                        onClick={() => setCountry(c.name)}
                        className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-bold transition ${
                          country === c.name
                            ? "bg-emerald-500/20 border-emerald-500 text-white"
                            : "bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <span className="text-base">{c.flag}</span>
                        <span>{c.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Starting League Selector */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Starting League Division (Recommended: Division 5 Road-to-Glory)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {DIVISIONS_META.map((div) => (
                      <button
                        key={div.id}
                        type="button"
                        onClick={() => setStartingDivisionId(div.id)}
                        className={`p-2.5 rounded-xl border text-left transition ${
                          startingDivisionId === div.id
                            ? "bg-emerald-500/20 border-emerald-500 text-white"
                            : "bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-extrabold uppercase text-white">
                            {div.name}
                          </span>
                          {div.id === 5 && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-black">
                              START
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Avg Squad: {div.avgOvr} OVR
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: CUSTOM BADGE BUILDER */}
            {activeTab === "badge" && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Shield Shape
                  </label>
                  <div className="grid grid-cols-5 gap-2">
                    {(
                      ["classic", "hexagon", "royal", "diamond", "circle"] as BadgeShape[]
                    ).map((sh) => (
                      <button
                        key={sh}
                        type="button"
                        onClick={() => setBadge({ ...badge, shape: sh })}
                        className={`py-2 px-2 rounded-xl border text-xs font-bold uppercase transition ${
                          badge.shape === sh
                            ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                            : "bg-slate-900 border-slate-800 text-slate-400"
                        }`}
                      >
                        {sh}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Crest Pattern
                  </label>
                  <div className="grid grid-cols-5 gap-2">
                    {(
                      ["stripes", "sash", "quartered", "solid", "chevron"] as BadgePattern[]
                    ).map((pat) => (
                      <button
                        key={pat}
                        type="button"
                        onClick={() => setBadge({ ...badge, pattern: pat })}
                        className={`py-2 px-2 rounded-xl border text-xs font-bold uppercase transition ${
                          badge.pattern === pat
                            ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                            : "bg-slate-900 border-slate-800 text-slate-400"
                        }`}
                      >
                        {pat}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Central Emblem Icon
                  </label>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                    {(
                      [
                        "lion",
                        "eagle",
                        "crown",
                        "star",
                        "ball",
                        "lightning",
                        "anchor",
                        "flame",
                      ] as BadgeIcon[]
                    ).map((ic) => (
                      <button
                        key={ic}
                        type="button"
                        onClick={() => setBadge({ ...badge, icon: ic })}
                        className={`py-2 px-1 rounded-xl border text-[11px] font-bold uppercase transition ${
                          badge.icon === ic
                            ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                            : "bg-slate-900 border-slate-800 text-slate-400"
                        }`}
                      >
                        {ic}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Primary Color
                    </label>
                    <input
                      type="color"
                      value={badge.primaryColor}
                      onChange={(e) =>
                        setBadge({ ...badge, primaryColor: e.target.value })
                      }
                      className="w-full h-10 rounded-lg cursor-pointer bg-slate-900 border border-slate-700"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Secondary Color
                    </label>
                    <input
                      type="color"
                      value={badge.secondaryColor}
                      onChange={(e) =>
                        setBadge({ ...badge, secondaryColor: e.target.value })
                      }
                      className="w-full h-10 rounded-lg cursor-pointer bg-slate-900 border border-slate-700"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Crest Trim / Icon
                    </label>
                    <input
                      type="color"
                      value={badge.accentColor}
                      onChange={(e) =>
                        setBadge({ ...badge, accentColor: e.target.value })
                      }
                      className="w-full h-10 rounded-lg cursor-pointer bg-slate-900 border border-slate-700"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: HOME & AWAY KITS */}
            {activeTab === "kits" && (
              <div className="space-y-4">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setPreviewKitMode("home")}
                    className={`flex-1 py-2 rounded-xl font-bold text-xs uppercase border transition ${
                      previewKitMode === "home"
                        ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                        : "bg-slate-900 border-slate-800 text-slate-400"
                    }`}
                  >
                    Editing Home Kit
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewKitMode("away")}
                    className={`flex-1 py-2 rounded-xl font-bold text-xs uppercase border transition ${
                      previewKitMode === "away"
                        ? "bg-amber-500/20 border-amber-500 text-amber-300"
                        : "bg-slate-900 border-slate-800 text-slate-400"
                    }`}
                  >
                    Editing Away Kit
                  </button>
                </div>

                {(() => {
                  const currentKit =
                    previewKitMode === "home" ? homeKit : awayKit;
                  const updateKit = (patch: Partial<KitConfig>) => {
                    if (previewKitMode === "home") {
                      setHomeKit({ ...homeKit, ...patch });
                    } else {
                      setAwayKit({ ...awayKit, ...patch });
                    }
                  };

                  return (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                          Jersey Pattern ({previewKitMode.toUpperCase()})
                        </label>
                        <div className="grid grid-cols-5 gap-2">
                          {(
                            ["solid", "stripes", "hoops", "sash", "halves"] as KitPattern[]
                          ).map((kp) => (
                            <button
                              key={kp}
                              type="button"
                              onClick={() => updateKit({ pattern: kp })}
                              className={`py-2 px-2 rounded-xl border text-xs font-bold uppercase transition ${
                                currentKit.pattern === kp
                                  ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                                  : "bg-slate-900 border-slate-800 text-slate-400"
                              }`}
                            >
                              {kp}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-300 mb-1">
                            Shirt Primary
                          </label>
                          <input
                            type="color"
                            value={currentKit.primaryColor}
                            onChange={(e) =>
                              updateKit({
                                primaryColor: e.target.value,
                                socksColor: e.target.value,
                              })
                            }
                            className="w-full h-10 rounded-lg cursor-pointer bg-slate-900 border border-slate-700"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-300 mb-1">
                            Shirt Pattern Color
                          </label>
                          <input
                            type="color"
                            value={currentKit.secondaryColor}
                            onChange={(e) =>
                              updateKit({ secondaryColor: e.target.value })
                            }
                            className="w-full h-10 rounded-lg cursor-pointer bg-slate-900 border border-slate-700"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-300 mb-1">
                            Shorts Color
                          </label>
                          <input
                            type="color"
                            value={currentKit.shortsColor}
                            onChange={(e) =>
                              updateKit({ shortsColor: e.target.value })
                            }
                            className="w-full h-10 rounded-lg cursor-pointer bg-slate-900 border border-slate-700"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Right 5 Cols: Live 3D Player & Badge Preview */}
          <div className="lg:col-span-5 p-6 bg-slate-950/60 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  Live 3D Club Identity Preview
                </span>
                <span className="text-xs font-mono text-slate-400">
                  {makeShortName(name)} • {country}
                </span>
              </div>

              {/* Club Card Preview */}
              <div className="flex items-center gap-4 bg-slate-900/90 border border-slate-800 p-4 rounded-2xl mb-4">
                <ClubBadge badge={badge} size={72} />
                <div className="min-w-0 flex-1">
                  <div className="text-lg font-black text-white truncate">
                    {name || "Your Club FC"}
                  </div>
                  <div className="text-xs text-emerald-400 font-semibold">
                    🏟️ {stadiumName || "Community Ground"}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Manager: {managerName || "Alex Mercer"} •{" "}
                    {DIVISIONS_META.find((d) => d.id === startingDivisionId)?.name}
                  </div>
                </div>
              </div>

              {/* 3D Rotating Blocky Player Preview */}
              <div className="relative">
                <PlayerKit3DPreview
                  homeKit={homeKit}
                  awayKit={awayKit}
                  activeKit={previewKitMode}
                />
                <div className="absolute top-2.5 right-2.5 flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => setPreviewKitMode("home")}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase ${
                      previewKitMode === "home"
                        ? "bg-emerald-500 text-slate-950"
                        : "bg-slate-900/80 text-slate-300"
                    }`}
                  >
                    Home 3D
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewKitMode("away")}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase ${
                      previewKitMode === "away"
                        ? "bg-amber-500 text-slate-950"
                        : "bg-slate-900/80 text-slate-300"
                    }`}
                  >
                    Away 3D
                  </button>
                </div>
              </div>

              {/* 2D Kit Jerseys Side-by-Side */}
              <div className="flex items-center justify-around bg-slate-900/60 border border-slate-800/80 rounded-xl py-2.5 mt-3">
                <KitJerseyPreview kit={homeKit} size={52} label="Home Kit" />
                <KitJerseyPreview kit={awayKit} size={52} label="Away Kit" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black uppercase tracking-wider text-sm shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 transition"
            >
              <CheckCircle2 className="w-5 h-5" />
              {isNewCareer ? "Launch Football Club Career" : "Save Club Customization"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
