import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { careerSaves } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const slotKey = req.nextUrl.searchParams.get("slot") || "primary_career";
    const rows = await db
      .select()
      .from(careerSaves)
      .where(eq(careerSaves.slotKey, slotKey))
      .limit(1);

    if (rows.length === 0) {
      return NextResponse.json({ found: false, save: null });
    }

    return NextResponse.json({
      found: true,
      save: rows[0],
    });
  } catch (err) {
    console.error("GET /api/career error:", err);
    return NextResponse.json({ found: false, save: null, error: "db_unavailable" });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      slotKey = "primary_career",
      clubName = "Custom FC",
      managerName = "Alex Mercer",
      divisionId = 5,
      season = 1,
      week = 1,
      balance = 1250000,
      stadiumLevel = 1,
      stateJson,
    } = body;

    if (!stateJson) {
      return NextResponse.json({ error: "Missing stateJson" }, { status: 400 });
    }

    const existing = await db
      .select({ id: careerSaves.id })
      .from(careerSaves)
      .where(eq(careerSaves.slotKey, slotKey))
      .limit(1);

    if (existing.length > 0) {
      const updated = await db
        .update(careerSaves)
        .set({
          clubName,
          managerName,
          divisionId: Number(divisionId) || 5,
          season: Number(season) || 1,
          week: Number(week) || 1,
          balance: Math.round(Number(balance) || 0),
          stadiumLevel: Number(stadiumLevel) || 1,
          stateJson,
          updatedAt: new Date(),
        })
        .where(eq(careerSaves.slotKey, slotKey))
        .returning();

      return NextResponse.json({ ok: true, save: updated[0] });
    } else {
      const inserted = await db
        .insert(careerSaves)
        .values({
          slotKey,
          clubName,
          managerName,
          divisionId: Number(divisionId) || 5,
          season: Number(season) || 1,
          week: Number(week) || 1,
          balance: Math.round(Number(balance) || 0),
          stadiumLevel: Number(stadiumLevel) || 1,
          stateJson,
        })
        .returning();

      return NextResponse.json({ ok: true, save: inserted[0] });
    }
  } catch (err) {
    console.error("POST /api/career error:", err);
    return NextResponse.json({ ok: false, error: "Failed to save to DB" }, { status: 200 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const slotKey = req.nextUrl.searchParams.get("slot") || "primary_career";
    await db.delete(careerSaves).where(eq(careerSaves.slotKey, slotKey));
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("DELETE /api/career error:", err);
    return NextResponse.json({ ok: false });
  }
}
