"use client";

import React, { useState } from "react";
import {
  formatCurrency,
  IncomingTransferOffer,
  Player,
  Position,
} from "@/lib/gameData";
import {
  Briefcase,
  CheckCircle2,
  DollarSign,
  Filter,
  Handshake,
  Search,
  Sparkles,
  TrendingUp,
  UserPlus,
  XCircle,
} from "lucide-react";

interface TransferMarketViewProps {
  market: Player[];
  squad: Player[];
  incomingOffers: IncomingTransferOffer[];
  balance: number;
  onBuyPlayer: (
    player: Player,
    agreedFee: number,
    agreedSalary: number,
    contractYears: number
  ) => void;
  onAcceptIncomingOffer: (offerId: string, finalFee?: number) => void;
  onRejectIncomingOffer: (offerId: string) => void;
  onGenerateNewIncomingOffer: () => void;
}

export function TransferMarketView({
  market,
  squad,
  incomingOffers,
  balance,
  onBuyPlayer,
  onAcceptIncomingOffer,
  onRejectIncomingOffer,
  onGenerateNewIncomingOffer,
}: TransferMarketViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [posFilter, setPosFilter] = useState<string>("ALL");
  const [maxPriceFilter, setMaxPriceFilter] = useState<number>(50000000);
  const [minOvrFilter, setMinOvrFilter] = useState<number>(50);
  const [affordableOnly, setAffordableOnly] = useState<boolean>(false);

  // Negotiation Modal State
  const [negotiatingPlayer, setNegotiatingPlayer] = useState<Player | null>(
    null
  );
  const [negStep, setNegStep] = useState<"fee" | "contract">("fee");
  const [offeredFee, setOfferedFee] = useState<number>(0);
  const [aiCounterFee, setAiCounterFee] = useState<number | null>(null);
  const [clubResponseMsg, setClubResponseMsg] = useState<string>("");
  const [patience, setPatience] = useState<number>(100);

  // Contract Step State
  const [offeredSalary, setOfferedSalary] = useState<number>(0);
  const [offeredYears, setOfferedYears] = useState<number>(3);
  const [agentMsg, setAgentMsg] = useState<string>("");

  const openNegotiation = (player: Player) => {
    setNegotiatingPlayer(player);
    setNegStep("fee");
    setOfferedFee(player.marketValue);
    setAiCounterFee(null);
    setPatience(100);
    setClubResponseMsg(
      `${player.clubName} (${
        player.aiClubStrategy || "Balanced"
      }) values ${player.name} at ${formatCurrency(player.marketValue)}. Submit your opening transfer bid.`
    );
    setOfferedSalary(player.weeklySalary);
    setOfferedYears(3);
    setAgentMsg(
      `${player.name}'s agent expects around ${formatCurrency(
        player.weeklySalary
      )}/wk on a multi-year deal.`
    );
  };

  const handleProposeFee = () => {
    if (!negotiatingPlayer) return;
    if (offeredFee > balance) {
      setClubResponseMsg(
        "❌ Your club balance cannot cover this transfer fee! Lower your bid or sell a player first."
      );
      return;
    }

    const mv = negotiatingPlayer.marketValue;
    const strategy = negotiatingPlayer.aiClubStrategy || "Balanced";
    const minMultiplier =
      strategy === "Galactico Buyers"
        ? 1.08
        : strategy === "Youth Developers" && negotiatingPlayer.age <= 21
        ? 1.12
        : strategy === "Bargain Hunters"
        ? 0.92
        : 0.96;

    const requiredFee = Math.round((mv * minMultiplier) / 5000) * 5000;

    if (offeredFee >= requiredFee) {
      setClubResponseMsg(
        `✅ ${negotiatingPlayer.clubName} has ACCEPTED your transfer bid of ${formatCurrency(
          offeredFee
        )}! Proceed to personal contract terms.`
      );
      setNegStep("contract");
    } else if (offeredFee >= requiredFee * 0.8) {
      const counter = Math.round(((requiredFee + mv) / 2) / 5000) * 5000;
      setAiCounterFee(counter);
      setPatience((p) => Math.max(20, p - 25));
      setClubResponseMsg(
        `🤝 ${negotiatingPlayer.clubName} rejects ${formatCurrency(
          offeredFee
        )}, but counters with a firm asking price of ${formatCurrency(counter)}.`
      );
    } else {
      setPatience((p) => Math.max(0, p - 45));
      setClubResponseMsg(
        `⚠️ ${negotiatingPlayer.clubName} finds your offer of ${formatCurrency(
          offeredFee
        )} insulting! Increase your bid closer to ${formatCurrency(requiredFee)}.`
      );
    }
  };

  const handleFinalizeContract = () => {
    if (!negotiatingPlayer) return;
    const minWage = Math.round(negotiatingPlayer.weeklySalary * 0.92);
    if (offeredSalary < minWage) {
      setAgentMsg(
        `❌ Agent: "${negotiatingPlayer.name} won't sign for less than ${formatCurrency(
          minWage
        )}/wk!"`
      );
      return;
    }

    onBuyPlayer(negotiatingPlayer, offeredFee, offeredSalary, offeredYears);
    setNegotiatingPlayer(null);
  };

  const pendingOffers = incomingOffers.filter((o) => o.status === "pending");

  const filteredMarket = market.filter((p) => {
    if (
      searchQuery &&
      !p.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !p.clubName.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    if (posFilter !== "ALL" && p.position !== posFilter) return false;
    if (p.overall < minOvrFilter) return false;
    if (p.marketValue > maxPriceFilter) return false;
    if (affordableOnly && p.marketValue > balance) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Incoming Transfer Offers Section */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-amber-400" />
              Incoming AI Club Transfer Bids ({pendingOffers.length} Active)
            </h3>
            <p className="text-xs text-slate-400">
              AI clubs across the pyramid actively scout your squad. Accept, negotiate a +15% premium, or reject offers.
            </p>
          </div>
          <button
            onClick={onGenerateNewIncomingOffer}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 hover:bg-amber-500/30 text-amber-300 text-xs font-bold uppercase transition"
          >
            <Sparkles className="w-4 h-4" />
            Invite New AI Transfer Bids
          </button>
        </div>

        {pendingOffers.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-4 text-xs text-slate-400 text-center">
            No pending incoming bids right now. Click &ldquo;Invite New AI Transfer Bids&rdquo; to alert rival sporting directors!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingOffers.map((offer) => (
              <div
                key={offer.id}
                className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between gap-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono font-bold text-xs">
                        {offer.playerPosition} • {offer.playerOvr} OVR
                      </span>
                      <span className="text-sm font-black text-white">
                        {offer.playerName}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 mt-1">
                      Bidding Club:{" "}
                      <strong className="text-white">
                        {offer.buyingClubName}
                      </strong>{" "}
                      <span className="text-[11px] text-amber-400">
                        ({offer.buyingClubStrategy})
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-bold uppercase text-slate-400">
                      Transfer Bid
                    </div>
                    <div className="text-lg font-black font-mono text-emerald-400">
                      {formatCurrency(offer.offeredFee)}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      Valuation: {formatCurrency(offer.marketValue)}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => onAcceptIncomingOffer(offer.id)}
                    disabled={squad.length <= 12}
                    className="flex-1 py-2 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-black text-xs uppercase flex items-center justify-center gap-1 transition"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Accept {formatCurrency(offer.offeredFee)}
                  </button>
                  <button
                    onClick={() =>
                      onAcceptIncomingOffer(
                        offer.id,
                        Math.round((offer.offeredFee * 1.15) / 5000) * 5000
                      )
                    }
                    disabled={squad.length <= 12}
                    className="py-2 px-3 rounded-lg bg-amber-500/20 border border-amber-500/40 hover:bg-amber-500/30 disabled:opacity-40 text-amber-300 font-bold text-xs uppercase transition"
                  >
                    Counter +15% ({formatCurrency(Math.round(offer.offeredFee * 1.15))})
                  </button>
                  <button
                    onClick={() => onRejectIncomingOffer(offer.id)}
                    className="py-2 px-3 rounded-lg bg-rose-500/20 border border-rose-500/40 hover:bg-rose-500/30 text-rose-300 font-bold text-xs uppercase transition"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Search & Filter Controls */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 flex-1 min-w-[240px]">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search player name or selling club..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold uppercase text-slate-400">
                Min OVR: {minOvrFilter}
              </span>
              <input
                type="range"
                min={50}
                max={88}
                value={minOvrFilter}
                onChange={(e) => setMinOvrFilter(Number(e.target.value))}
                className="w-24 accent-emerald-500"
              />
            </div>

            <label className="flex items-center gap-2 text-xs font-bold text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={affordableOnly}
                onChange={(e) => setAffordableOnly(e.target.checked)}
                className="rounded accent-emerald-500"
              />
              Within Transfer Budget ({formatCurrency(balance)})
            </label>
          </div>
        </div>

        {/* Position Pills */}
        <div className="flex flex-wrap gap-1.5">
          {(
            [
              "ALL",
              "GK",
              "CB",
              "LB",
              "RB",
              "CDM",
              "CM",
              "CAM",
              "LW",
              "RW",
              "ST",
            ] as const
          ).map((pos) => (
            <button
              key={pos}
              onClick={() => setPosFilter(pos)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                posFilter === pos
                  ? "bg-emerald-500 text-slate-950 shadow"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              {pos}
            </button>
          ))}
        </div>

        {/* Market Players Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5 pt-2">
          {filteredMarket.slice(0, 24).map((player) => {
            const canAfford = balance >= player.marketValue * 0.85;
            return (
              <div
                key={player.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 flex flex-col justify-between transition group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-slate-950 border border-emerald-500/40 flex flex-col items-center justify-center font-mono">
                        <span className="text-lg font-black text-emerald-400 leading-none">
                          {player.overall}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400">
                          {player.position}
                        </span>
                      </div>
                      <div>
                        <div className="text-sm font-black text-white flex items-center gap-1.5">
                          <span>{player.flag}</span>
                          <span>{player.name}</span>
                        </div>
                        <div className="text-xs text-slate-400">
                          {player.clubName} • Age {player.age}
                        </div>
                        <div className="text-[10px] text-amber-400 font-semibold mt-0.5">
                          Strategy: {player.aiClubStrategy || "Balanced"}
                        </div>
                      </div>
                    </div>

                    <div className="text-right font-mono">
                      <div className="text-sm font-black text-emerald-400">
                        {formatCurrency(player.marketValue)}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {formatCurrency(player.weeklySalary)}/wk
                      </div>
                      <div className="text-[10px] text-amber-300">
                        POT {player.potential}
                      </div>
                    </div>
                  </div>

                  {/* Mini Attribute Strip */}
                  <div className="grid grid-cols-6 gap-1 mt-3 pt-2.5 border-t border-slate-800/80 text-center font-mono text-[10px]">
                    <div>
                      <span className="text-slate-500 block">SHO</span>
                      <span className="text-white font-bold">
                        {player.attributes.shooting}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">PAS</span>
                      <span className="text-white font-bold">
                        {player.attributes.passing}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">DEF</span>
                      <span className="text-white font-bold">
                        {player.attributes.defending}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">SPD</span>
                      <span className="text-white font-bold">
                        {player.attributes.speed}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">STA</span>
                      <span className="text-white font-bold">
                        {player.attributes.stamina}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">GK</span>
                      <span className="text-white font-bold">
                        {player.attributes.goalkeeping}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => openNegotiation(player)}
                  className={`mt-3 w-full py-2.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition ${
                    canAfford
                      ? "bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow"
                      : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                  }`}
                >
                  <Handshake className="w-4 h-4" />
                  Approach to Sign / Negotiate
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* INTERACTIVE TRANSFER & CONTRACT NEGOTIATION MODAL */}
      {negotiatingPlayer && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#0F1623] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                  {negStep === "fee"
                    ? "Step 1 of 2 • Club Transfer Fee Negotiation"
                    : "Step 2 of 2 • Player Contract & Wage Negotiation"}
                </div>
                <h3 className="text-lg font-black text-white mt-0.5">
                  {negotiatingPlayer.flag} {negotiatingPlayer.name} (
                  {negotiatingPlayer.position} • {negotiatingPlayer.overall} OVR)
                </h3>
              </div>
              <button
                onClick={() => setNegotiatingPlayer(null)}
                className="text-slate-400 hover:text-white"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* Player Valuation Summary */}
              <div className="grid grid-cols-3 gap-2 bg-slate-900/90 border border-slate-800 rounded-xl p-3 text-center">
                <div>
                  <div className="text-[10px] uppercase text-slate-400 font-bold">
                    Market Value
                  </div>
                  <div className="text-sm font-black font-mono text-emerald-400">
                    {formatCurrency(negotiatingPlayer.marketValue)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase text-slate-400 font-bold">
                    Current Wage
                  </div>
                  <div className="text-sm font-black font-mono text-white">
                    {formatCurrency(negotiatingPlayer.weeklySalary)}/wk
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase text-slate-400 font-bold">
                    Your Budget
                  </div>
                  <div className="text-sm font-black font-mono text-amber-400">
                    {formatCurrency(balance)}
                  </div>
                </div>
              </div>

              {negStep === "fee" ? (
                <>
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-200 leading-relaxed">
                    {clubResponseMsg}
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold mb-1.5">
                      <span className="text-slate-400 uppercase">
                        Your Transfer Offer
                      </span>
                      <span className="font-mono text-emerald-400 text-sm">
                        {formatCurrency(offeredFee)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={Math.round(negotiatingPlayer.marketValue * 0.6)}
                      max={Math.round(negotiatingPlayer.marketValue * 1.5)}
                      step={5000}
                      value={offeredFee}
                      onChange={(e) => setOfferedFee(Number(e.target.value))}
                      className="w-full accent-emerald-500"
                    />
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={handleProposeFee}
                      disabled={patience <= 0}
                      className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-black text-xs uppercase tracking-wider transition"
                    >
                      Submit Bid ({formatCurrency(offeredFee)})
                    </button>

                    {aiCounterFee && (
                      <button
                        onClick={() => {
                          if (aiCounterFee > balance) {
                            setClubResponseMsg(
                              "❌ Insufficient club funds to accept the counter-offer!"
                            );
                            return;
                          }
                          setOfferedFee(aiCounterFee);
                          setNegStep("contract");
                        }}
                        className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider transition"
                      >
                        Accept Counter ({formatCurrency(aiCounterFee)})
                      </button>
                    )}
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-emerald-950/30 border border-emerald-500/40 rounded-xl p-3.5 text-xs text-emerald-200">
                    Agreed Transfer Fee:{" "}
                    <strong className="font-mono">
                      {formatCurrency(offeredFee)}
                    </strong>
                    . {agentMsg}
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold mb-1.5">
                      <span className="text-slate-400 uppercase">
                        Offered Weekly Salary
                      </span>
                      <span className="font-mono text-emerald-400 text-sm">
                        {formatCurrency(offeredSalary)}/wk
                      </span>
                    </div>
                    <input
                      type="range"
                      min={Math.round(negotiatingPlayer.weeklySalary * 0.75)}
                      max={Math.round(negotiatingPlayer.weeklySalary * 1.6)}
                      step={100}
                      value={offeredSalary}
                      onChange={(e) => setOfferedSalary(Number(e.target.value))}
                      className="w-full accent-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-400 mb-1.5">
                      Contract Duration (Years)
                    </label>
                    <div className="grid grid-cols-5 gap-2">
                      {[1, 2, 3, 4, 5].map((yr) => (
                        <button
                          key={yr}
                          type="button"
                          onClick={() => setOfferedYears(yr)}
                          className={`py-2 rounded-lg font-mono text-xs font-bold border transition ${
                            offeredYears === yr
                              ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                              : "bg-slate-900 border-slate-800 text-slate-400"
                          }`}
                        >
                          {yr} Yr{yr > 1 ? "s" : ""}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={handleFinalizeContract}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 transition"
                  >
                    <UserPlus className="w-4 h-4" />
                    Sign Player & Complete Transfer ({formatCurrency(offeredFee)})
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
