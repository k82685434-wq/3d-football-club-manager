"use client";

import React, { useEffect, useState, useCallback } from "react";
import confetti from "canvas-confetti";
import {
  AD_CLICK_REWARD,
  calculateMarketValue,
  calculateSquadOverall,
  calculateWeeklySalary,
  calculateWeeklyWageBill,
  CareerState,
  ClubIdentity,
  computeOverallFromAttributes,
  createDefaultObjectives,
  createInitialCareerState,
  FormationName,
  FORMATIONS,
  formatCurrency,
  generateSeasonFixtures,
  generateStartingSquad,
  getDivisionMeta,
  KitConfig,
  LeagueStanding,
  Mentality,
  Player,
  sortStandings,
  SPONSOR_OPTIONS,
  STADIUM_CAPACITY_TIERS,
  TrainingCategory,
} from "@/lib/gameData";
import { ClubBadge } from "@/components/ClubBadge";
import { ClubCreationModal } from "@/components/ClubCreationModal";
import { DashboardView } from "@/components/DashboardView";
import { SquadManagementView } from "@/components/SquadManagementView";
import { TransferMarketView } from "@/components/TransferMarketView";
import { LeagueTableView } from "@/components/LeagueTableView";
import { TrainingCenterView } from "@/components/TrainingCenterView";
import { StadiumEconomyView } from "@/components/StadiumEconomyView";
import { QuickMatchView } from "@/components/QuickMatchView";
import { Match3DEngine, MatchStatsSummary } from "@/components/Match3DEngine";
import {
  Briefcase,
  Building2,
  CheckCircle2,
  Coins,
  Dumbbell,
  LayoutDashboard,
  Megaphone,
  Palette,
  Play,
  RotateCcw,
  Save,
  Swords,
  Trophy,
  Users,
} from "lucide-react";

type ActiveTab =
  | "dashboard"
  | "squad"
  | "transfers"
  | "league"
  | "training"
  | "stadium"
  | "quickmatch"
  | "match3d";

const STORAGE_KEY = "ufcm_career_state_v1";

export default function UltimateFootballManagerPage() {
  const [career, setCareer] = useState<CareerState>(() =>
    createInitialCareerState()
  );
  const [activeTab, setActiveTab] = useState<ActiveTab>("dashboard");
  const [showClubModal, setShowClubModal] = useState<boolean>(false);
  const [isNewCareerModal, setIsNewCareerModal] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);
  const [seasonEndModal, setSeasonEndModal] = useState<{
    season: number;
    divisionName: string;
    rank: number;
    promoted: boolean;
    relegated: boolean;
    nextDivisionName: string;
    prizeMoney: number;
  } | null>(null);

  // Quick Match custom config when launched from Quick Match tab
  const [quickMatchConfig, setQuickMatchConfig] = useState<{
    homeName: string;
    homeShort: string;
    homeKit: KitConfig;
    homeFormation: FormationName;
    awayName: string;
    awayShort: string;
    awayKit: KitConfig;
    awayFormation: FormationName;
    awayDivId: number;
    stadiumTier: number;
    nightMatch: boolean;
  } | null>(null);

  const showNotification = useCallback((msg: string) => {
    setSaveToast(msg);
    setTimeout(() => {
      setSaveToast((prev) => (prev === msg ? null : prev));
    }, 3500);
  }, []);

  // Load saved career from LocalStorage or PostgreSQL on mount
  useEffect(() => {
    let loadedLocal = false;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as CareerState;
        if (parsed && parsed.club && parsed.squad) {
          setCareer(parsed);
          loadedLocal = true;
        }
      }
    } catch {
      // ignore storage parse error
    }

    if (!loadedLocal) {
      fetch("/api/career?slot=primary_career")
        .then((r) => r.json())
        .then((data) => {
          if (data?.found && data?.save?.stateJson) {
            setCareer(data.save.stateJson as CareerState);
            window.localStorage.setItem(
              STORAGE_KEY,
              JSON.stringify(data.save.stateJson)
            );
          }
        })
        .catch(() => {});
    }
  }, []);

  // Persist career state to LocalStorage and PostgreSQL
  const persistCareer = useCallback((nextState: CareerState) => {
    setCareer(nextState);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextState));
    } catch {
      // ignore quota error
    }

    fetch("/api/career", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        slotKey: "primary_career",
        clubName: nextState.club.name,
        managerName: nextState.club.managerName,
        divisionId: nextState.currentDivisionId,
        season: nextState.season,
        week: nextState.week,
        balance: nextState.balance,
        stadiumLevel: nextState.stadium.capacityLevel,
        stateJson: nextState,
      }),
    }).catch(() => {});
  }, []);

  // Club Creation / Customization completion handler
  const handleCompleteClubCustomization = (customClub: ClubIdentity) => {
    if (isNewCareerModal) {
      const fresh = createInitialCareerState(customClub);
      persistCareer(fresh);
      showNotification(`Founded ${customClub.name} in ${getDivisionMeta(customClub.startingDivisionId).name}!`);
    } else {
      // Update existing club identity & kits while preserving squad/progress
      const updatedDivisions = { ...career.divisions };
      const curList = [...(updatedDivisions[career.currentDivisionId] || [])];
      const userIdx = curList.findIndex((c) => c.isUser);
      if (userIdx !== -1) {
        curList[userIdx] = {
          ...curList[userIdx],
          clubName: customClub.name,
          shortName: customClub.shortName,
          primaryColor: customClub.badge.primaryColor,
          secondaryColor: customClub.badge.secondaryColor,
        };
        updatedDivisions[career.currentDivisionId] = curList;
      }

      const updatedFixtures = career.fixtures.map((f) => {
        if (f.homeClubId === "user_club") {
          return {
            ...f,
            homeClubName: customClub.name,
            homeShort: customClub.shortName,
            homePrimary: customClub.badge.primaryColor,
            homeSecondary: customClub.badge.secondaryColor,
          };
        }
        if (f.awayClubId === "user_club") {
          return {
            ...f,
            awayClubName: customClub.name,
            awayShort: customClub.shortName,
            awayPrimary: customClub.badge.primaryColor,
            awaySecondary: customClub.badge.secondaryColor,
          };
        }
        return f;
      });

      const nextState: CareerState = {
        ...career,
        club: customClub,
        divisions: updatedDivisions,
        fixtures: updatedFixtures,
      };
      persistCareer(nextState);
      showNotification(`Updated ${customClub.name} badge, kits & stadium identity!`);
    }
    setShowClubModal(false);
  };

  // Process a single matchweek (either after 3D match finishes or via Quick Sim)
  const advanceMatchweekWithUserResult = useCallback(
    (userHomeScore?: number, userAwayScore?: number) => {
      const currentWeek = career.week;
      if (currentWeek > career.maxWeeksPerSeason) return;

      const userSquadOvr = calculateSquadOverall(career.squad);
      const updatedDivisions: Record<number, LeagueStanding[]> = {};

      // Simulate all 6 divisions
      for (let divId = 5; divId >= 0; divId--) {
        const table = [...(career.divisions[divId] || [])].map((row) => ({
          ...row,
          form: [...row.form],
        }));

        if (divId !== career.currentDivisionId) {
          // Pair up teams in other divisions and simulate their matchweek
          for (let i = 0; i < table.length; i += 2) {
            const h = table[i];
            const a = table[i + 1];
            if (!h || !a) continue;
            const diff = (h.overallRating - a.overallRating) * 0.08;
            const hg = Math.max(
              0,
              Math.round(Math.random() * 2.6 + diff)
            );
            const ag = Math.max(
              0,
              Math.round(Math.random() * 2.3 - diff)
            );
            h.played += 1;
            a.played += 1;
            h.goalsFor += hg;
            h.goalsAgainst += ag;
            a.goalsFor += ag;
            a.goalsAgainst += hg;
            if (hg > ag) {
              h.won += 1;
              h.points += 3;
              h.form.push("W");
              a.lost += 1;
              a.form.push("L");
            } else if (hg === ag) {
              h.drawn += 1;
              a.drawn += 1;
              h.points += 1;
              a.points += 1;
              h.form.push("D");
              a.form.push("D");
            } else {
              a.won += 1;
              a.points += 3;
              a.form.push("W");
              h.lost += 1;
              h.form.push("L");
            }
          }
        }
        updatedDivisions[divId] = table;
      }

      // Now process User's Division fixtures for currentWeek
      const curTable = updatedDivisions[career.currentDivisionId];
      let userWon = false;
      let userDrew = false;
      let userMatchTitle = "";

      const updatedFixtures = career.fixtures.map((fix) => {
        if (fix.week !== currentWeek || fix.played) return fix;

        let hGoals = 0;
        let aGoals = 0;

        if (fix.isUserMatch) {
          if (
            typeof userHomeScore === "number" &&
            typeof userAwayScore === "number"
          ) {
            hGoals = userHomeScore;
            aGoals = userAwayScore;
          } else {
            // Quick Sim user match based on squad OVR vs opponent OVR
            const userIsHome = fix.homeClubId === "user_club";
            const hOvr = userIsHome ? userSquadOvr : fix.homeOvr;
            const aOvr = userIsHome ? fix.awayOvr : userSquadOvr;
            const adv = (hOvr - aOvr) * 0.12 + 0.25;
            hGoals = Math.max(0, Math.round(Math.random() * 2.7 + adv));
            aGoals = Math.max(0, Math.round(Math.random() * 2.3 - adv));
          }

          const userIsHome = fix.homeClubId === "user_club";
          const uG = userIsHome ? hGoals : aGoals;
          const oG = userIsHome ? aGoals : hGoals;
          userWon = uG > oG;
          userDrew = uG === oG;
          userMatchTitle = `${fix.homeClubName} ${hGoals} - ${aGoals} ${fix.awayClubName}`;
        } else {
          const adv = (fix.homeOvr - fix.awayOvr) * 0.08 + 0.15;
          hGoals = Math.max(0, Math.round(Math.random() * 2.5 + adv));
          aGoals = Math.max(0, Math.round(Math.random() * 2.2 - adv));
        }

        // Update standings rows
        const hRow = curTable.find((r) => r.clubId === fix.homeClubId);
        const aRow = curTable.find((r) => r.clubId === fix.awayClubId);
        if (hRow && aRow) {
          hRow.played += 1;
          aRow.played += 1;
          hRow.goalsFor += hGoals;
          hRow.goalsAgainst += aGoals;
          aRow.goalsFor += aGoals;
          aRow.goalsAgainst += hGoals;

          if (hGoals > aGoals) {
            hRow.won += 1;
            hRow.points += 3;
            hRow.form.push("W");
            aRow.lost += 1;
            aRow.form.push("L");
          } else if (hGoals === aGoals) {
            hRow.drawn += 1;
            aRow.drawn += 1;
            hRow.points += 1;
            aRow.points += 1;
            hRow.form.push("D");
            aRow.form.push("D");
          } else {
            aRow.won += 1;
            aRow.points += 3;
            aRow.form.push("W");
            hRow.lost += 1;
            hRow.form.push("L");
          }
        }

        return {
          ...fix,
          played: true,
          homeScore: hGoals,
          awayScore: aGoals,
        };
      });

      // Calculate Matchweek Economy (Gate Revenue + Sponsor - Wages - Maintenance)
      const capTier =
        STADIUM_CAPACITY_TIERS.find(
          (t) => t.level === career.stadium.capacityLevel
        ) || STADIUM_CAPACITY_TIERS[0];
      const divMeta = getDivisionMeta(career.currentDivisionId);
      const sponsor =
        SPONSOR_OPTIONS.find((s) => s.id === career.activeSponsorId) ||
        SPONSOR_OPTIONS[0];

      const idealTicket = 22 + (5 - career.currentDivisionId) * 9;
      const priceFactor = Math.max(
        0.45,
        Math.min(1.0, 1 - (career.stadium.ticketPrice - idealTicket) * 0.015)
      );
      const attendance = Math.round(
        capTier.capacity * divMeta.baseAttendanceFactor * priceFactor
      );
      const gateRevenue =
        attendance * career.stadium.ticketPrice +
        career.stadium.commercialLevel * 18000 +
        career.stadium.lightingLevel * 12000;
      const sponsorIncome =
        sponsor.weeklyBase + (userWon ? sponsor.winBonus : 0);
      const wageExpense = calculateWeeklyWageBill(career.squad);
      const loanInterest = Math.round(career.clubDebt * 0.015);
      const netWeekDelta =
        gateRevenue +
        sponsorIncome -
        wageExpense -
        capTier.maintenance -
        loanInterest;

      // Update Squad appearances, fatigue, morale, and goal stats
      const updatedSquad = career.squad.map((p) => {
        if (p.isStarter) {
          const fatLoss = 4 + Math.floor(Math.random() * 5);
          return {
            ...p,
            appearances: p.appearances + 1,
            fitness: Math.max(52, p.fitness - fatLoss),
            morale: Math.min(
              100,
              Math.max(45, p.morale + (userWon ? 4 : userDrew ? 1 : -3))
            ),
            xp: Math.min(100, p.xp + (userWon ? 14 : 8)),
          };
        } else {
          return {
            ...p,
            fitness: Math.min(100, p.fitness + 10),
          };
        }
      });

      const newFinances = [
        {
          id: `fin_gate_${career.season}_${currentWeek}`,
          week: currentWeek,
          season: career.season,
          description: `Matchday Gate (${attendance.toLocaleString()} fans) & LED Adverts`,
          amount: gateRevenue,
          category: "gate" as const,
        },
        {
          id: `fin_spon_${career.season}_${currentWeek}`,
          week: currentWeek,
          season: career.season,
          description: `${sponsor.brandName} Weekly + Win Bonus`,
          amount: sponsorIncome,
          category: "sponsor" as const,
        },
        {
          id: `fin_wage_${career.season}_${currentWeek}`,
          week: currentWeek,
          season: career.season,
          description: `Weekly Squad Wages & Stadium Upkeep`,
          amount: -(wageExpense + capTier.maintenance + loanInterest),
          category: "wages" as const,
        },
        ...career.finances,
      ].slice(0, 35);

      const newNews = [
        {
          id: `news_wk_${career.season}_${currentWeek}`,
          week: currentWeek,
          season: career.season,
          title: `Matchweek ${currentWeek} Result: ${userMatchTitle}`,
          body: `${attendance.toLocaleString()} supporters attended ${
            career.club.stadiumName
          }, generating ${formatCurrency(gateRevenue)} in matchday revenue.`,
          category: "match" as const,
          timestamp: `Season ${career.season} • Week ${currentWeek}`,
        },
        ...career.news,
      ].slice(0, 25);

      const nextWeek = currentWeek + 1;
      const nextState: CareerState = {
        ...career,
        week: nextWeek,
        balance: career.balance + netWeekDelta,
        squad: updatedSquad,
        divisions: updatedDivisions,
        fixtures: updatedFixtures,
        finances: newFinances,
        news: newNews,
        trainedThisWeek: false,
      };

      persistCareer(nextState);

      // Check if season has finished (after week 19)
      if (nextWeek > career.maxWeeksPerSeason) {
        const finalStandings = sortStandings(
          updatedDivisions[career.currentDivisionId]
        );
        const userRank = finalStandings.findIndex((s) => s.isUser) + 1;
        const promoted = userRank <= 3 && career.currentDivisionId > 0;
        const relegated = userRank >= 18 && career.currentDivisionId < 5;
        const prize =
          userRank === 1
            ? divMeta.championPrize
            : userRank <= 3
            ? divMeta.promotionPrize
            : Math.round(divMeta.promotionPrize * 0.35);

        const nextDivId = promoted
          ? career.currentDivisionId - 1
          : relegated
          ? career.currentDivisionId + 1
          : career.currentDivisionId;

        if (promoted || userRank === 1) {
          confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
        }

        setSeasonEndModal({
          season: career.season,
          divisionName: divMeta.name,
          rank: userRank,
          promoted,
          relegated,
          nextDivisionName: getDivisionMeta(nextDivId).name,
          prizeMoney: prize,
        });
      }
    },
    [career, persistCareer]
  );

  // Simulate remaining weeks of the current season
  const handleSimRestOfSeason = () => {
    let tempState = { ...career };
    const userSquadOvr = calculateSquadOverall(tempState.squad);

    while (tempState.week <= tempState.maxWeeksPerSeason) {
      const w = tempState.week;
      const curTable = [...(tempState.divisions[tempState.currentDivisionId] || [])];

      tempState.fixtures = tempState.fixtures.map((fix) => {
        if (fix.week !== w || fix.played) return fix;
        const userIsHome = fix.homeClubId === "user_club";
        const hOvr = userIsHome ? userSquadOvr : fix.homeOvr;
        const aOvr = userIsHome ? fix.awayOvr : userSquadOvr;
        const adv = (hOvr - aOvr) * 0.12 + 0.25;
        const hGoals = Math.max(0, Math.round(Math.random() * 2.7 + adv));
        const aGoals = Math.max(0, Math.round(Math.random() * 2.2 - adv));

        const hRow = curTable.find((r) => r.clubId === fix.homeClubId);
        const aRow = curTable.find((r) => r.clubId === fix.awayClubId);
        if (hRow && aRow) {
          hRow.played += 1;
          aRow.played += 1;
          hRow.goalsFor += hGoals;
          hRow.goalsAgainst += aGoals;
          aRow.goalsFor += aGoals;
          aRow.goalsAgainst += hGoals;
          if (hGoals > aGoals) {
            hRow.won += 1;
            hRow.points += 3;
            hRow.form.push("W");
            aRow.lost += 1;
            aRow.form.push("L");
          } else if (hGoals === aGoals) {
            hRow.drawn += 1;
            aRow.drawn += 1;
            hRow.points += 1;
            aRow.points += 1;
            hRow.form.push("D");
            aRow.form.push("D");
          } else {
            aRow.won += 1;
            aRow.points += 3;
            aRow.form.push("W");
            hRow.lost += 1;
            hRow.form.push("L");
          }
        }

        return { ...fix, played: true, homeScore: hGoals, awayScore: aGoals };
      });

      tempState.divisions = {
        ...tempState.divisions,
        [tempState.currentDivisionId]: curTable,
      };
      tempState.balance += 45000;
      tempState.week += 1;
    }

    persistCareer(tempState);

    const divMeta = getDivisionMeta(tempState.currentDivisionId);
    const finalStandings = sortStandings(
      tempState.divisions[tempState.currentDivisionId]
    );
    const userRank = finalStandings.findIndex((s) => s.isUser) + 1;
    const promoted = userRank <= 3 && tempState.currentDivisionId > 0;
    const relegated = userRank >= 18 && tempState.currentDivisionId < 5;
    const prize =
      userRank === 1
        ? divMeta.championPrize
        : userRank <= 3
        ? divMeta.promotionPrize
        : Math.round(divMeta.promotionPrize * 0.35);

    const nextDivId = promoted
      ? tempState.currentDivisionId - 1
      : relegated
      ? tempState.currentDivisionId + 1
      : tempState.currentDivisionId;

    if (promoted || userRank === 1) {
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
    }

    setSeasonEndModal({
      season: tempState.season,
      divisionName: divMeta.name,
      rank: userRank,
      promoted,
      relegated,
      nextDivisionName: getDivisionMeta(nextDivId).name,
      prizeMoney: prize,
    });
  };

  // Proceed to Next Season (Applies Promotion/Relegation & Prize Money)
  const handleStartNextSeason = () => {
    if (!seasonEndModal) return;

    const promoted = seasonEndModal.promoted;
    const relegated = seasonEndModal.relegated;
    const nextDivId = promoted
      ? Math.max(0, career.currentDivisionId - 1)
      : relegated
      ? Math.min(5, career.currentDivisionId + 1)
      : career.currentDivisionId;

    const newDivisions = { ...career.divisions };

    // Reset all divisions for the new season and place user club in nextDivId
    for (let d = 5; d >= 0; d--) {
      const list = (newDivisions[d] || []).map((row) => ({
        ...row,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        goalsFor: 0,
        goalsAgainst: 0,
        points: 0,
        form: [],
      }));
      newDivisions[d] = list;
    }

    if (nextDivId !== career.currentDivisionId) {
      const oldList = newDivisions[career.currentDivisionId];
      const targetList = newDivisions[nextDivId];
      const uIdx = oldList.findIndex((r) => r.isUser);
      if (uIdx !== -1 && targetList.length > 0) {
        const userEntry = oldList[uIdx];
        const swappedAI = targetList[0];
        oldList[uIdx] = { ...swappedAI, isUser: false };
        targetList[0] = { ...userEntry, isUser: true };
      }
    }

    const newFixtures = generateSeasonFixtures(
      nextDivId,
      newDivisions[nextDivId]
    );

    const newTrophies =
      seasonEndModal.rank <= 3
        ? [
            ...career.trophies,
            {
              season: career.season,
              title:
                seasonEndModal.rank === 1
                  ? `${seasonEndModal.divisionName} Champions`
                  : `${seasonEndModal.divisionName} Promoted`,
              divisionName: seasonEndModal.divisionName,
            },
          ]
        : career.trophies;

    const nextSeasonState: CareerState = {
      ...career,
      season: career.season + 1,
      week: 1,
      currentDivisionId: nextDivId,
      balance: career.balance + seasonEndModal.prizeMoney,
      divisions: newDivisions,
      fixtures: newFixtures,
      objectives: createDefaultObjectives(nextDivId),
      trophies: newTrophies,
      finances: [
        {
          id: `fin_prize_s${career.season}`,
          week: 1,
          season: career.season + 1,
          description: `Season ${career.season} ${seasonEndModal.divisionName} Prize (#${seasonEndModal.rank})`,
          amount: seasonEndModal.prizeMoney,
          category: "prize",
        },
        ...career.finances,
      ],
      news: [
        {
          id: `news_s${career.season + 1}`,
          week: 1,
          season: career.season + 1,
          title: promoted
            ? `🎉 PROMOTED! ${career.club.name} Advances to ${seasonEndModal.nextDivisionName}!`
            : `Season ${career.season + 1} Kicks Off in ${seasonEndModal.nextDivisionName}`,
          body: `Your club received ${formatCurrency(
            seasonEndModal.prizeMoney
          )} in season prize money. The new 19-matchweek campaign begins now!`,
          category: "league",
          timestamp: `Season ${career.season + 1} • Week 1`,
        },
        ...career.news,
      ],
    };

    persistCareer(nextSeasonState);
    setSeasonEndModal(null);
    setActiveTab("dashboard");
    showNotification(
      `Welcome to Season ${nextSeasonState.season} in ${getDivisionMeta(nextDivId).name}!`
    );
  };

  // Squad Management Handlers
  const handleSwapPlayers = (idA: string, idB: string) => {
    const updated = [...career.squad];
    const idxA = updated.findIndex((p) => p.id === idA);
    const idxB = updated.findIndex((p) => p.id === idB);
    if (idxA === -1 || idxB === -1) return;

    const pA = { ...updated[idxA] };
    const pB = { ...updated[idxB] };

    const tempStarter = pA.isStarter;
    const tempSlot = pA.starterSlot;

    pA.isStarter = pB.isStarter;
    pA.starterSlot = pB.starterSlot;
    pB.isStarter = tempStarter;
    pB.starterSlot = tempSlot;

    updated[idxA] = pA;
    updated[idxB] = pB;

    persistCareer({ ...career, squad: updated });
    showNotification(`Swapped ${pA.name} and ${pB.name} in lineup!`);
  };

  const handleAutoPickBestXI = () => {
    const sorted = [...career.squad].sort(
      (a, b) => b.overall * (b.fitness / 100) - a.overall * (a.fitness / 100)
    );
    const gk = sorted.find((p) => p.position === "GK") || sorted[0];
    const outfield = sorted.filter((p) => p.id !== gk.id);
    const topTen = outfield.slice(0, 10);
    const starterIds = new Set([gk.id, ...topTen.map((p) => p.id)]);

    let slotCounter = 1;
    const updated = career.squad.map((p) => {
      if (p.id === gk.id) {
        return { ...p, isStarter: true, starterSlot: 0 };
      }
      if (starterIds.has(p.id)) {
        const slot = slotCounter++;
        return { ...p, isStarter: true, starterSlot: slot };
      }
      return { ...p, isStarter: false, starterSlot: null };
    });

    persistCareer({ ...career, squad: updated });
    showNotification("Auto-picked highest rated Starting XI!");
  };

  const handleExtendContract = (playerId: string) => {
    const player = career.squad.find((p) => p.id === playerId);
    if (!player) return;
    const bonus = Math.round(player.weeklySalary * 4);
    if (career.balance < bonus) {
      showNotification("Insufficient balance for contract signing bonus!");
      return;
    }

    const updatedSquad = career.squad.map((p) =>
      p.id === playerId
        ? {
            ...p,
            contractYears: p.contractYears + 2,
            morale: Math.min(100, p.morale + 10),
          }
        : p
    );

    persistCareer({
      ...career,
      balance: career.balance - bonus,
      squad: updatedSquad,
    });
    showNotification(
      `Extended ${player.name}'s contract by +2 years (Bonus: ${formatCurrency(bonus)})!`
    );
  };

  const handleSellPlayer = (playerId: string) => {
    if (career.squad.length <= 12) return;
    const player = career.squad.find((p) => p.id === playerId);
    if (!player) return;

    const fee = Math.round(player.marketValue * 0.9);
    const remaining = career.squad.filter((p) => p.id !== playerId);

    // Ensure 11 starters remain
    if (player.isStarter) {
      const replacement = remaining.find((p) => !p.isStarter);
      if (replacement) {
        replacement.isStarter = true;
        replacement.starterSlot = player.starterSlot;
      }
    }

    persistCareer({
      ...career,
      balance: career.balance + fee,
      squad: remaining,
      transferMarket: [
        { ...player, isStarter: false, starterSlot: null, clubName: "Free Transfer List" },
        ...career.transferMarket,
      ],
      finances: [
        {
          id: `fin_sell_${Date.now()}`,
          week: career.week,
          season: career.season,
          description: `Sold ${player.name} (${player.position})`,
          amount: fee,
          category: "transfer",
        },
        ...career.finances,
      ],
      news: [
        {
          id: `news_sell_${Date.now()}`,
          week: career.week,
          season: career.season,
          title: `Transfer Completed: ${player.name} Departed for ${formatCurrency(fee)}`,
          body: `${career.club.name} sanctioned the sale of ${player.name}, adding ${formatCurrency(fee)} to the transfer budget.`,
          category: "transfer",
          timestamp: `Season ${career.season} • Week ${career.week}`,
        },
        ...career.news,
      ],
    });
    showNotification(`Sold ${player.name} for ${formatCurrency(fee)}!`);
  };

  const handleRestSquad = () => {
    const updated = career.squad.map((p) => ({
      ...p,
      fitness: Math.min(100, p.fitness + 15),
      morale: Math.min(100, p.morale + 4),
    }));
    persistCareer({ ...career, squad: updated });
    showNotification("Squad completed cryo-recovery & fitness session (+15% Fitness)!");
  };

  // Transfer Market Handlers
  const handleBuyPlayer = (
    player: Player,
    agreedFee: number,
    agreedSalary: number,
    contractYears: number
  ) => {
    const newPlayer: Player = {
      ...player,
      id: `usr_signed_${Date.now()}`,
      weeklySalary: agreedSalary,
      contractYears,
      clubId: "user_club",
      clubName: career.club.name,
      isStarter: false,
      starterSlot: null,
      fitness: 98,
      morale: 95,
      kitNumber: 20 + (career.squad.length % 70),
    };

    const nextState: CareerState = {
      ...career,
      balance: career.balance - agreedFee,
      squad: [...career.squad, newPlayer],
      transferMarket: career.transferMarket.filter((p) => p.id !== player.id),
      finances: [
        {
          id: `fin_buy_${Date.now()}`,
          week: career.week,
          season: career.season,
          description: `Signed ${player.name} from ${player.clubName}`,
          amount: -agreedFee,
          category: "transfer",
        },
        ...career.finances,
      ],
      news: [
        {
          id: `news_buy_${Date.now()}`,
          week: career.week,
          season: career.season,
          title: `🚨 OFFICIAL SIGNING: ${career.club.name} Signs ${player.name} (${player.overall} OVR)!`,
          body: `${player.name} has completed a ${formatCurrency(
            agreedFee
          )} transfer from ${player.clubName} on a ${contractYears}-year contract worth ${formatCurrency(
            agreedSalary
          )}/wk.`,
          category: "transfer",
          timestamp: `Season ${career.season} • Week ${career.week}`,
        },
        ...career.news,
      ],
    };

    persistCareer(nextState);
    confetti({ particleCount: 45, spread: 55, origin: { y: 0.65 } });
    showNotification(
      `Welcome to ${career.club.name}, ${player.name} (${player.overall} OVR)!`
    );
  };

  const handleAcceptIncomingOffer = (offerId: string, customFee?: number) => {
    const offer = career.incomingOffers.find((o) => o.id === offerId);
    if (!offer || career.squad.length <= 12) return;

    const finalFee = customFee || offer.offeredFee;
    const soldPlayer = career.squad.find((p) => p.id === offer.playerId);
    const remainingSquad = career.squad.filter((p) => p.id !== offer.playerId);

    if (soldPlayer?.isStarter) {
      const benchSub = remainingSquad.find((p) => !p.isStarter);
      if (benchSub) {
        benchSub.isStarter = true;
        benchSub.starterSlot = soldPlayer.starterSlot;
      }
    }

    persistCareer({
      ...career,
      balance: career.balance + finalFee,
      squad: remainingSquad,
      incomingOffers: career.incomingOffers.map((o) =>
        o.id === offerId ? { ...o, status: "accepted" } : o
      ),
      finances: [
        {
          id: `fin_inc_${Date.now()}`,
          week: career.week,
          season: career.season,
          description: `Transfer Sale: ${offer.playerName} to ${offer.buyingClubName}`,
          amount: finalFee,
          category: "transfer",
        },
        ...career.finances,
      ],
      news: [
        {
          id: `news_inc_${Date.now()}`,
          week: career.week,
          season: career.season,
          title: `Deal Agreed: ${offer.playerName} Joins ${offer.buyingClubName} for ${formatCurrency(finalFee)}`,
          body: `Your board praised the shrewd negotiation that brought ${formatCurrency(finalFee)} into the club treasury.`,
          category: "transfer",
          timestamp: `Season ${career.season} • Week ${career.week}`,
        },
        ...career.news,
      ],
    });
    showNotification(
      `Accepted ${formatCurrency(finalFee)} from ${offer.buyingClubName} for ${offer.playerName}!`
    );
  };

  const handleRejectIncomingOffer = (offerId: string) => {
    persistCareer({
      ...career,
      incomingOffers: career.incomingOffers.map((o) =>
        o.id === offerId ? { ...o, status: "rejected" } : o
      ),
    });
    showNotification("Transfer bid rejected.");
  };

  const handleGenerateNewIncomingOffer = () => {
    const candidate =
      career.squad[Math.floor(Math.random() * career.squad.length)];
    if (!candidate) return;
    const buyers = [
      { name: "Albion Metro FC", strat: "Galactico Buyers", mult: 1.18 },
      { name: "Falconbridge Rovers", strat: "Youth Developers", mult: 1.12 },
      { name: "Durham Dynamo", strat: "Balanced", mult: 1.05 },
      { name: "Newcastle Falcons", strat: "Bargain Hunters", mult: 0.96 },
    ];
    const buyer = buyers[Math.floor(Math.random() * buyers.length)];
    const fee = Math.round((candidate.marketValue * buyer.mult) / 5000) * 5000;

    const newOffer = {
      id: `offer_${Date.now()}`,
      playerId: candidate.id,
      playerName: candidate.name,
      playerPosition: candidate.position,
      playerOvr: candidate.overall,
      buyingClubName: buyer.name,
      buyingClubStrategy: buyer.strat,
      offeredFee: fee,
      marketValue: candidate.marketValue,
      week: career.week,
      status: "pending" as const,
    };

    persistCareer({
      ...career,
      incomingOffers: [newOffer, ...career.incomingOffers],
    });
    showNotification(
      `New Bid: ${buyer.name} offered ${formatCurrency(fee)} for ${candidate.name}!`
    );
  };

  // Training Center Handlers
  const handleRunSquadTraining = () => {
    const extraCost = career.trainedThisWeek ? 15000 : 0;
    if (career.balance < extraCost) {
      showNotification("Not enough balance for extra bonus coaching session!");
      return;
    }

    const focus = career.trainingFocus;
    const mult =
      career.trainingIntensity === "intense"
        ? 1.5
        : career.trainingIntensity === "balanced"
        ? 1.15
        : 0.85;
    const fitCost =
      focus === "fitness"
        ? -18
        : career.trainingIntensity === "intense"
        ? 9
        : career.trainingIntensity === "balanced"
        ? 5
        : 3;

    let leveledUpNames: string[] = [];

    const updatedSquad = career.squad.map((p) => {
      const attrs = { ...p.attributes };
      if (focus === "shooting") attrs.shooting = Math.min(99, attrs.shooting + 1);
      else if (focus === "passing") attrs.passing = Math.min(99, attrs.passing + 1);
      else if (focus === "defending")
        attrs.defending = Math.min(99, attrs.defending + 1);
      else if (focus === "speed") attrs.speed = Math.min(99, attrs.speed + 1);
      else if (focus === "fitness") attrs.stamina = Math.min(99, attrs.stamina + 1);
      else if (focus === "goalkeeping" && p.position === "GK")
        attrs.goalkeeping = Math.min(99, attrs.goalkeeping + 2);

      const xpGain = Math.round((p.age <= 21 ? 34 : 22) * mult);
      let newXp = p.xp + xpGain;
      let newOvr = computeOverallFromAttributes(p.position, attrs);

      if (newXp >= 100 && p.overall < p.potential) {
        newXp -= 100;
        newOvr = Math.min(p.potential, Math.max(newOvr, p.overall + 1));
        leveledUpNames.push(`${p.name} (${newOvr} OVR)`);
      }

      return {
        ...p,
        attributes: attrs,
        overall: newOvr,
        marketValue: calculateMarketValue(newOvr, p.age, p.potential),
        weeklySalary: calculateWeeklySalary(newOvr),
        xp: Math.min(99, newXp),
        fitness: Math.max(45, Math.min(100, p.fitness - fitCost)),
      };
    });

    const updatedObjectives = career.objectives.map((obj) =>
      obj.id === "obj_youth"
        ? {
            ...obj,
            progress: Math.min(100, obj.progress + 25),
            completed: obj.progress + 25 >= 100,
          }
        : obj
    );

    persistCareer({
      ...career,
      balance: career.balance - extraCost,
      squad: updatedSquad,
      trainedThisWeek: true,
      objectives: updatedObjectives,
      news:
        leveledUpNames.length > 0
          ? [
              {
                id: `news_tr_${Date.now()}`,
                week: career.week,
                season: career.season,
                title: `📈 Training Breakthrough: ${leveledUpNames.slice(0, 3).join(", ")} Improved!`,
                body: `Intensive ${focus.toUpperCase()} drills at the Training Center unlocked higher overall ratings.`,
                category: "training",
                timestamp: `Season ${career.season} • Week ${career.week}`,
              },
              ...career.news,
            ]
          : career.news,
    });

    showNotification(
      leveledUpNames.length > 0
        ? `Training Complete! Level Up: ${leveledUpNames.slice(0, 2).join(", ")}!`
        : `Completed ${focus.toUpperCase()} squad training drill!`
    );
  };

  const handleRunIndividualDrill = (
    playerId: string,
    category: TrainingCategory
  ) => {
    if (career.balance < 8000) return;
    const updatedSquad = career.squad.map((p) => {
      if (p.id !== playerId) return p;
      const attrs = { ...p.attributes };
      if (category === "shooting")
        attrs.shooting = Math.min(99, attrs.shooting + 2);
      if (category === "passing")
        attrs.passing = Math.min(99, attrs.passing + 2);
      if (category === "defending")
        attrs.defending = Math.min(99, attrs.defending + 2);
      if (category === "speed") attrs.speed = Math.min(99, attrs.speed + 2);
      if (category === "fitness")
        attrs.stamina = Math.min(99, attrs.stamina + 2);
      if (category === "goalkeeping")
        attrs.goalkeeping = Math.min(99, attrs.goalkeeping + 2);

      const newOvr = Math.min(
        p.potential,
        Math.max(p.overall, computeOverallFromAttributes(p.position, attrs))
      );

      return {
        ...p,
        attributes: attrs,
        overall: newOvr,
        marketValue: calculateMarketValue(newOvr, p.age, p.potential),
        xp: Math.min(99, p.xp + 30),
      };
    });

    persistCareer({
      ...career,
      balance: career.balance - 8000,
      squad: updatedSquad,
    });
    showNotification(`Completed 1-on-1 ${category.toUpperCase()} coaching session!`);
  };

  // Stadium & Economy Handlers
  const handleUpgradeStadium = (
    module: "capacityLevel" | "pitchLevel" | "lightingLevel" | "commercialLevel",
    cost: number
  ) => {
    if (career.balance < cost || career.stadium[module] >= 5) return;

    const updatedStadium = {
      ...career.stadium,
      [module]: career.stadium[module] + 1,
    };

    const updatedObjectives = career.objectives.map((obj) =>
      obj.id === "obj_stadium"
        ? { ...obj, progress: 100, completed: true }
        : obj
    );

    persistCareer({
      ...career,
      balance: career.balance - cost,
      stadium: updatedStadium,
      objectives: updatedObjectives,
      finances: [
        {
          id: `fin_stad_${Date.now()}`,
          week: career.week,
          season: career.season,
          description: `Stadium Upgrade: ${module.replace("Level", "").toUpperCase()} to Level ${updatedStadium[module]}`,
          amount: -cost,
          category: "stadium",
        },
        ...career.finances,
      ],
      news: [
        {
          id: `news_stad_${Date.now()}`,
          week: career.week,
          season: career.season,
          title: `🏟️ ${career.club.stadiumName} Upgraded to Level ${updatedStadium[module]}!`,
          body: `Construction crews completed the new stadium expansion, boosting matchday capacity and commercial revenue.`,
          category: "finance",
          timestamp: `Season ${career.season} • Week ${career.week}`,
        },
        ...career.news,
      ],
    });
    showNotification(
      `Upgraded ${career.club.stadiumName} (${module.replace("Level", "")} Level ${updatedStadium[module]})!`
    );
  };

  // Click Advertisement Handler -> Credits £9,000,000 (AD_CLICK_REWARD) per click
  const handleClickAdvertisement = useCallback(
    (brandName = "Sponsor Advertisement") => {
      setCareer((prev) => {
        const nextBalance = prev.balance + AD_CLICK_REWARD;
        const nextState: CareerState = {
          ...prev,
          balance: nextBalance,
          finances: [
            {
              id: `fin_ad_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
              week: prev.week,
              season: prev.season,
              description: `Advertisement Click Payout: ${brandName}`,
              amount: AD_CLICK_REWARD,
              category: "sponsor" as const,
            },
            ...prev.finances,
          ].slice(0, 40),
          news: [
            {
              id: `news_ad_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
              week: prev.week,
              season: prev.season,
              title: `💰 +£9.00M Advertisement Revenue Credited (${brandName})`,
              body: `Your club earned ${formatCurrency(
                AD_CLICK_REWARD
              )} from clicking the ${brandName} campaign. New treasury balance: ${formatCurrency(
                nextBalance
              )}.`,
              category: "finance" as const,
              timestamp: `Season ${prev.season} • Week ${prev.week}`,
            },
            ...prev.news,
          ].slice(0, 25),
        };

        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextState));
        } catch {
          // ignore quota error
        }

        fetch("/api/career", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            slotKey: "primary_career",
            clubName: nextState.club.name,
            managerName: nextState.club.managerName,
            divisionId: nextState.currentDivisionId,
            season: nextState.season,
            week: nextState.week,
            balance: nextState.balance,
            stadiumLevel: nextState.stadium.capacityLevel,
            stateJson: nextState,
          }),
        }).catch(() => {});

        return nextState;
      });

      confetti({
        particleCount: 35,
        spread: 60,
        origin: { y: 0.7 },
      });
      showNotification(
        `💰 Advertisement Clicked! +${formatCurrency(AD_CLICK_REWARD)} (£9,000,000) added from ${brandName}!`
      );
    },
    [showNotification]
  );

  // Prepare 3D Match Teams for either Career Match or Quick Match
  const currentCareerFixture = career.fixtures.find(
    (f) => f.week === career.week && f.isUserMatch
  );

  const handle3DMatchComplete = (summary: MatchStatsSummary) => {
    // Log match to PostgreSQL backend
    const homeName = quickMatchConfig
      ? quickMatchConfig.homeName
      : currentCareerFixture?.homeClubName || career.club.name;
    const awayName = quickMatchConfig
      ? quickMatchConfig.awayName
      : currentCareerFixture?.awayClubName || "Rival FC";

    fetch("/api/matches", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        homeClub: homeName,
        awayClub: awayName,
        homeScore: summary.homeScore,
        awayScore: summary.awayScore,
        divisionName: getDivisionMeta(career.currentDivisionId).name,
        season: career.season,
        week: career.week,
        mode: quickMatchConfig ? "quickmatch" : "career",
      }),
    }).catch(() => {});

    if (quickMatchConfig) {
      setQuickMatchConfig(null);
      setActiveTab("dashboard");
      showNotification(
        `Exhibition Full Time: ${homeName} ${summary.homeScore} - ${summary.awayScore} ${awayName}!`
      );
      return;
    }

    // Career mode match complete -> update league & advance matchweek
    advanceMatchweekWithUserResult(summary.homeScore, summary.awayScore);
    setActiveTab("dashboard");
    showNotification(
      `Full Time: ${homeName} ${summary.homeScore} - ${summary.awayScore} ${awayName}! League table updated.`
    );
  };

  const navItems: {
    id: ActiveTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
  }[] = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "squad", label: "Squad & Tactics", icon: Users },
    {
      id: "transfers",
      label: "Transfer Market",
      icon: Briefcase,
      badge: career.incomingOffers.filter((o) => o.status === "pending").length,
    },
    { id: "league", label: "Leagues (Div 5–Prem)", icon: Trophy },
    { id: "training", label: "Training Center", icon: Dumbbell },
    { id: "stadium", label: "3D Stadium & Economy", icon: Building2 },
    { id: "quickmatch", label: "Quick Match", icon: Swords },
  ];

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 flex flex-col font-sans">
      {/* TOPPERSISTENT COMMAND HEADER */}
      <header className="sticky top-0 z-30 bg-[#090D16]/95 backdrop-blur-md border-b border-slate-800/90 px-4 lg:px-6 py-2.5">
        <div className="max-w-[1600px] mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Left: Club Identity & Division */}
          <div className="flex items-center gap-3">
            <ClubBadge badge={career.club.badge} size={42} />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-black tracking-tight text-white uppercase">
                  {career.club.name}
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-[10px] font-black uppercase">
                  {getDivisionMeta(career.currentDivisionId).name}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 flex items-center gap-2 font-mono">
                <span>
                  Season {career.season} • Week{" "}
                  {Math.min(career.week, career.maxWeeksPerSeason)}/
                  {career.maxWeeksPerSeason}
                </span>
                <span>•</span>
                <span className="text-emerald-400 font-bold">
                  {formatCurrency(career.balance)}
                </span>
              </div>
            </div>
          </div>

          {/* Center: Navigation Tabs */}
          <nav className="flex items-center gap-1 overflow-x-auto py-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setQuickMatchConfig(null);
                    setActiveTab(item.id);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition ${
                    isActive
                      ? "bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-950/50"
                      : "text-slate-300 hover:bg-slate-800/80 hover:text-white"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.badge && item.badge > 0 ? (
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono font-black ${
                        isActive
                          ? "bg-slate-950 text-emerald-400"
                          : "bg-amber-500 text-slate-950"
                      }`}
                    >
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>

          {/* Right: Click Ad (+£9M), Play 3D Match & Club Studio Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleClickAdvertisement("VIP Broadcast Sponsor Ad")}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-xs font-black text-amber-300 uppercase tracking-wider transition active:scale-95"
              title="Click Advertisement to Earn £9,000,000 Instantly"
            >
              <Megaphone className="w-3.5 h-3.5 text-amber-400" />
              <span>Click Ad (+£9M)</span>
            </button>

            <button
              onClick={() => {
                setIsNewCareerModal(false);
                setShowClubModal(true);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-200 transition"
              title="Customize Club Badge, Kits, Stadium & Name"
            >
              <Palette className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Customize Club</span>
            </button>

            <button
              onClick={() => {
                setIsNewCareerModal(true);
                setShowClubModal(true);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-slate-200 transition"
              title="Start a Brand New Club Career"
            >
              <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden xl:inline">New Career</span>
            </button>

            <button
              onClick={() => {
                setQuickMatchConfig(null);
                setActiveTab("match3d");
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg transition"
            >
              <Play className="w-4 h-4 fill-current" />
              Play 3D Match
            </button>
          </div>
        </div>
      </header>

      {/* NOTIFICATION TOAST */}
      {saveToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900/95 border border-emerald-500/60 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-bold animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{saveToast}</span>
        </div>
      )}

      {/* MAIN VIEWPORT */}
      {activeTab === "match3d" ? (
        (() => {
          if (quickMatchConfig) {
            const oppSquad = generateStartingSquad(
              quickMatchConfig.awayName,
              quickMatchConfig.awayDivId
            );
            return (
              <Match3DEngine
                homeClub={{
                  name: quickMatchConfig.homeName,
                  shortName: quickMatchConfig.homeShort,
                  kit: quickMatchConfig.homeKit,
                  badge: career.club.badge,
                  squad: career.squad,
                  formation: quickMatchConfig.homeFormation,
                  mentality: career.mentality,
                  isUser: true,
                }}
                awayClub={{
                  name: quickMatchConfig.awayName,
                  shortName: quickMatchConfig.awayShort,
                  kit: quickMatchConfig.awayKit,
                  squad: oppSquad,
                  formation: quickMatchConfig.awayFormation,
                  mentality: "balanced",
                  isUser: false,
                }}
                stadium={{
                  ...career.stadium,
                  capacityLevel: quickMatchConfig.stadiumTier,
                }}
                stadiumName={career.club.stadiumName}
                competitionLabel="Exhibition Quick Match"
                nightMatch={quickMatchConfig.nightMatch}
                onMatchComplete={handle3DMatchComplete}
                onClickAdvertisement={handleClickAdvertisement}
                onCancelQuickMatch={() => {
                  setQuickMatchConfig(null);
                  setActiveTab("dashboard");
                }}
              />
            );
          }

          // Career Mode 3D Match
          const fix = currentCareerFixture;
          const userIsHome = !fix || fix.homeClubId === "user_club";
          const oppName = fix
            ? userIsHome
              ? fix.awayClubName
              : fix.homeClubName
            : "Ironbridge Town";
          const oppShort = fix
            ? userIsHome
              ? fix.awayShort
              : fix.homeShort
            : "IRN";
          const oppColor = fix
            ? userIsHome
              ? fix.awayPrimary
              : fix.homePrimary
            : "#EF4444";

          const aiSquad = generateStartingSquad(
            oppName,
            career.currentDivisionId
          );

          const userTeamObj = {
            name: career.club.name,
            shortName: career.club.shortName,
            kit: userIsHome ? career.club.homeKit : career.club.awayKit,
            badge: career.club.badge,
            squad: career.squad,
            formation: career.formation,
            mentality: career.mentality,
            isUser: true,
          };

          const aiTeamObj = {
            name: oppName,
            shortName: oppShort,
            kit: {
              pattern: "stripes" as const,
              primaryColor: oppColor,
              secondaryColor: "#0F172A",
              shortsColor: "#0F172A",
              socksColor: oppColor,
            },
            squad: aiSquad,
            formation: "4-4-2" as FormationName,
            mentality: "balanced" as Mentality,
            isUser: false,
          };

          return (
            <Match3DEngine
              homeClub={userIsHome ? userTeamObj : aiTeamObj}
              awayClub={userIsHome ? aiTeamObj : userTeamObj}
              stadium={career.stadium}
              stadiumName={
                userIsHome ? career.club.stadiumName : `${oppName} Stadium`
              }
              competitionLabel={`${
                getDivisionMeta(career.currentDivisionId).name
              } • Week ${career.week}`}
              nightMatch={career.week % 2 === 1}
              onMatchComplete={handle3DMatchComplete}
              onClickAdvertisement={handleClickAdvertisement}
              onCancelQuickMatch={() => setActiveTab("dashboard")}
            />
          );
        })()
      ) : (
        <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 sm:p-6">
          {activeTab === "dashboard" && (
            <DashboardView
              career={career}
              onPlayMatch3D={() => setActiveTab("match3d")}
              onQuickSimWeek={() => advanceMatchweekWithUserResult()}
              onOpenCustomizeClub={() => {
                setIsNewCareerModal(false);
                setShowClubModal(true);
              }}
              onClickAdvertisement={handleClickAdvertisement}
              onNavigateTab={(t) => setActiveTab(t)}
            />
          )}

          {activeTab === "squad" && (
            <SquadManagementView
              squad={career.squad}
              formation={career.formation}
              mentality={career.mentality}
              balance={career.balance}
              onChangeFormation={(f) =>
                persistCareer({ ...career, formation: f })
              }
              onChangeMentality={(m) =>
                persistCareer({ ...career, mentality: m })
              }
              onSwapPlayers={handleSwapPlayers}
              onAutoPickBestXI={handleAutoPickBestXI}
              onExtendContract={handleExtendContract}
              onSellPlayer={handleSellPlayer}
              onRestSquad={handleRestSquad}
            />
          )}

          {activeTab === "transfers" && (
            <TransferMarketView
              market={career.transferMarket}
              squad={career.squad}
              incomingOffers={career.incomingOffers}
              balance={career.balance}
              onBuyPlayer={handleBuyPlayer}
              onAcceptIncomingOffer={handleAcceptIncomingOffer}
              onRejectIncomingOffer={handleRejectIncomingOffer}
              onGenerateNewIncomingOffer={handleGenerateNewIncomingOffer}
            />
          )}

          {activeTab === "league" && (
            <LeagueTableView
              currentDivisionId={career.currentDivisionId}
              season={career.season}
              week={career.week}
              maxWeeks={career.maxWeeksPerSeason}
              divisions={career.divisions}
              fixtures={career.fixtures}
              onPlayNextMatch3D={() => setActiveTab("match3d")}
              onQuickSimWeek={() => advanceMatchweekWithUserResult()}
              onSimRestOfSeason={handleSimRestOfSeason}
            />
          )}

          {activeTab === "training" && (
            <TrainingCenterView
              squad={career.squad}
              trainingFocus={career.trainingFocus}
              trainingIntensity={career.trainingIntensity}
              trainedThisWeek={career.trainedThisWeek}
              balance={career.balance}
              onSelectCategory={(cat) =>
                persistCareer({ ...career, trainingFocus: cat })
              }
              onSelectIntensity={(intensity) =>
                persistCareer({ ...career, trainingIntensity: intensity })
              }
              onRunSquadTraining={handleRunSquadTraining}
              onRunIndividualDrill={handleRunIndividualDrill}
            />
          )}

          {activeTab === "stadium" && (
            <StadiumEconomyView
              stadiumName={career.club.stadiumName}
              primaryColor={career.club.badge.primaryColor}
              stadium={career.stadium}
              currentDivisionId={career.currentDivisionId}
              balance={career.balance}
              clubDebt={career.clubDebt}
              squad={career.squad}
              activeSponsorId={career.activeSponsorId}
              finances={career.finances}
              onUpgradeStadium={handleUpgradeStadium}
              onClickAdvertisement={handleClickAdvertisement}
              onChangeTicketPrice={(price) =>
                persistCareer({
                  ...career,
                  stadium: { ...career.stadium, ticketPrice: price },
                })
              }
              onSelectSponsor={(sponsorId) => {
                const sp = SPONSOR_OPTIONS.find((s) => s.id === sponsorId);
                if (!sp) return;
                persistCareer({
                  ...career,
                  activeSponsorId: sponsorId,
                  balance: career.balance + sp.signingBonus,
                  finances: [
                    {
                      id: `fin_sp_sign_${Date.now()}`,
                      week: career.week,
                      season: career.season,
                      description: `${sp.brandName} Contract Signing Advance`,
                      amount: sp.signingBonus,
                      category: "sponsor",
                    },
                    ...career.finances,
                  ],
                });
                showNotification(
                  `Signed ${sp.brandName} sponsorship (+${formatCurrency(sp.signingBonus)} signing bonus)!`
                );
              }}
              onTakeLoan={(amount) => {
                persistCareer({
                  ...career,
                  balance: career.balance + amount,
                  clubDebt: career.clubDebt + amount,
                  finances: [
                    {
                      id: `fin_loan_${Date.now()}`,
                      week: career.week,
                      season: career.season,
                      description: "Football Bank Infrastructure Credit Drawdown",
                      amount,
                      category: "loan",
                    },
                    ...career.finances,
                  ],
                });
                showNotification(`Borrowed ${formatCurrency(amount)} bank credit.`);
              }}
              onRepayLoan={(amount) => {
                persistCareer({
                  ...career,
                  balance: career.balance - amount,
                  clubDebt: Math.max(0, career.clubDebt - amount),
                  finances: [
                    {
                      id: `fin_repay_${Date.now()}`,
                      week: career.week,
                      season: career.season,
                      description: "Club Bank Debt Repayment",
                      amount: -amount,
                      category: "loan",
                    },
                    ...career.finances,
                  ],
                });
                showNotification(`Repaid ${formatCurrency(amount)} of club debt!`);
              }}
            />
          )}

          {activeTab === "quickmatch" && (
            <QuickMatchView
              career={career}
              onStartQuickMatch={(cfg) => {
                setQuickMatchConfig(cfg);
                setActiveTab("match3d");
              }}
            />
          )}
        </main>
      )}

      {/* CLUB CREATION & CUSTOMIZATION MODAL */}
      {showClubModal && (
        <ClubCreationModal
          initialClub={career.club}
          isNewCareer={isNewCareerModal}
          onComplete={handleCompleteClubCustomization}
          onClose={() => setShowClubModal(false)}
        />
      )}

      {/* SEASON FINALE & PROMOTION CEREMONY MODAL */}
      {seasonEndModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#0F1623] border border-emerald-500/50 rounded-2xl shadow-2xl overflow-hidden text-center">
            <div className="bg-gradient-to-r from-emerald-900/70 via-slate-900 to-emerald-900/70 p-6 border-b border-slate-800">
              <Trophy className="w-14 h-14 text-amber-400 mx-auto mb-2" />
              <div className="text-xs font-black uppercase tracking-widest text-emerald-400">
                Season {seasonEndModal.season} Official Finale
              </div>
              <h2 className="text-2xl font-black uppercase text-white mt-1">
                {seasonEndModal.rank === 1
                  ? `🏆 ${seasonEndModal.divisionName} CHAMPIONS!`
                  : seasonEndModal.promoted
                  ? `🎉 PROMOTED TO ${seasonEndModal.nextDivisionName}!`
                  : `Finished #${seasonEndModal.rank} in ${seasonEndModal.divisionName}`}
              </h2>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-sm text-slate-300">
                {career.club.name} completed the 19-matchweek campaign in{" "}
                <strong>Position #{seasonEndModal.rank}</strong> of 20 clubs!
              </p>

              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                <div className="text-xs font-bold uppercase text-slate-400">
                  Season Prize Money Awarded
                </div>
                <div className="text-3xl font-black font-mono text-emerald-400 mt-1">
                  +{formatCurrency(seasonEndModal.prizeMoney)}
                </div>
                <div className="text-xs text-amber-400 font-semibold mt-1">
                  Next Season League: {seasonEndModal.nextDivisionName}
                </div>
              </div>

              <button
                onClick={handleStartNextSeason}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black uppercase tracking-wider text-sm shadow-lg transition"
              >
                Claim Prize Money & Launch Season {seasonEndModal.season + 1}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
