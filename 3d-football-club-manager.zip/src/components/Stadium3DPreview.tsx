"use client";

import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { KitConfig, StadiumState } from "@/lib/gameData";

export function PlayerKit3DPreview({
  homeKit,
  awayKit,
  activeKit = "home",
}: {
  homeKit: KitConfig;
  awayKit: KitConfig;
  activeKit?: "home" | "away";
}) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const kit = activeKit === "home" ? homeKit : awayKit;

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const w = container.clientWidth || 280;
    const h = container.clientHeight || 280;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#090D16");

    const camera = new THREE.PerspectiveCamera(40, w / h, 0.1, 100);
    camera.position.set(0, 2.3, 5.2);
    camera.lookAt(0, 1.4, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = "";
    container.appendChild(renderer.domElement);

    const amb = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(amb);
    const dir = new THREE.DirectionalLight(0xffffff, 1.4);
    dir.position.set(4, 8, 5);
    scene.add(dir);

    // Turf Podium
    const podGeo = new THREE.CylinderGeometry(1.5, 1.7, 0.25, 32);
    const podMat = new THREE.MeshStandardMaterial({ color: "#15803d", roughness: 0.7 });
    const podium = new THREE.Mesh(podGeo, podMat);
    podium.position.y = -0.12;
    scene.add(podium);

    const ringGeo = new THREE.RingGeometry(1.3, 1.42, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: kit.primaryColor,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.02;
    scene.add(ring);

    // Kit Texture
    const canvas = document.createElement("canvas");
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = kit.primaryColor;
    ctx.fillRect(0, 0, 128, 128);
    ctx.fillStyle = kit.secondaryColor;
    if (kit.pattern === "stripes") {
      for (let x = 16; x < 128; x += 32) ctx.fillRect(x, 0, 14, 128);
    } else if (kit.pattern === "hoops") {
      for (let y = 16; y < 128; y += 32) ctx.fillRect(0, y, 128, 14);
    } else if (kit.pattern === "sash") {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(36, 0);
      ctx.lineTo(128, 92);
      ctx.lineTo(128, 128);
      ctx.lineTo(92, 128);
      ctx.lineTo(0, 36);
      ctx.closePath();
      ctx.fill();
    } else if (kit.pattern === "halves") {
      ctx.fillRect(64, 0, 64, 128);
    }
    const kitTex = new THREE.CanvasTexture(canvas);

    // Blocky Player Group
    const playerGroup = new THREE.Group();

    const torso = new THREE.Mesh(
      new THREE.BoxGeometry(1.05, 1.22, 0.56),
      new THREE.MeshStandardMaterial({ map: kitTex, roughness: 0.5 })
    );
    torso.position.y = 1.5;
    playerGroup.add(torso);

    const head = new THREE.Mesh(
      new THREE.BoxGeometry(0.74, 0.74, 0.74),
      new THREE.MeshStandardMaterial({ color: "#E8B89A" })
    );
    head.position.y = 2.52;
    playerGroup.add(head);

    const hair = new THREE.Mesh(
      new THREE.BoxGeometry(0.78, 0.25, 0.78),
      new THREE.MeshStandardMaterial({ color: "#1C1917" })
    );
    hair.position.y = 2.9;
    playerGroup.add(hair);

    const leftArm = new THREE.Mesh(
      new THREE.BoxGeometry(0.34, 1.05, 0.34),
      new THREE.MeshStandardMaterial({ color: "#E8B89A" })
    );
    leftArm.position.set(-0.74, 1.48, 0);
    playerGroup.add(leftArm);

    const rightArm = new THREE.Mesh(
      new THREE.BoxGeometry(0.34, 1.05, 0.34),
      new THREE.MeshStandardMaterial({ color: "#E8B89A" })
    );
    rightArm.position.set(0.74, 1.48, 0);
    playerGroup.add(rightArm);

    const leftLeg = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.95, 0.42),
      new THREE.MeshStandardMaterial({ color: kit.shortsColor })
    );
    leftLeg.position.set(-0.26, 0.48, 0);
    playerGroup.add(leftLeg);

    const rightLeg = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.95, 0.42),
      new THREE.MeshStandardMaterial({ color: kit.shortsColor })
    );
    rightLeg.position.set(0.26, 0.48, 0);
    playerGroup.add(rightLeg);

    // 3D Ball at feet
    const ball = new THREE.Mesh(
      new THREE.SphereGeometry(0.32, 16, 16),
      new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.3 })
    );
    ball.position.set(0.55, 0.32, 0.55);
    playerGroup.add(ball);

    scene.add(playerGroup);

    let frameId = 0;
    let t = 0;
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      t += 0.025;
      playerGroup.rotation.y = Math.sin(t * 0.7) * 0.65;
      leftArm.rotation.x = Math.sin(t * 2) * 0.15;
      rightArm.rotation.x = -Math.sin(t * 2) * 0.15;
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frameId);
      renderer.dispose();
    };
  }, [kit]);

  return <div ref={mountRef} className="w-full h-56 rounded-xl overflow-hidden border border-slate-800" />;
}

export function Stadium3DPreview({
  stadium,
  primaryColor,
}: {
  stadium: StadiumState;
  primaryColor: string;
}) {
  const mountRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const w = container.clientWidth || 600;
    const h = container.clientHeight || 340;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#070B14");

    const camera = new THREE.PerspectiveCamera(42, w / h, 0.5, 300);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(w, h);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = "";
    container.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 0.85));
    const sun = new THREE.DirectionalLight(0xfffbeb, 1.4);
    sun.position.set(25, 45, 30);
    scene.add(sun);

    // Pitch
    const pitch = new THREE.Mesh(
      new THREE.PlaneGeometry(52, 34),
      new THREE.MeshStandardMaterial({
        color: stadium.pitchLevel >= 3 ? "#16a34a" : "#15803d",
        roughness: 0.7,
      })
    );
    pitch.rotation.x = -Math.PI / 2;
    scene.add(pitch);

    // White markings outline
    const lineGeo = new THREE.RingGeometry(4.5, 4.8, 32);
    const lineMat = new THREE.MeshBasicMaterial({
      color: "#ffffff",
      side: THREE.DoubleSide,
    });
    const centerCircle = new THREE.Mesh(lineGeo, lineMat);
    centerCircle.rotation.x = -Math.PI / 2;
    centerCircle.position.y = 0.05;
    scene.add(centerCircle);

    // Multi-tier stands based on capacityLevel
    const tiers = stadium.capacityLevel;
    const standMat = new THREE.MeshStandardMaterial({ color: "#1e293b" });
    const accentMat = new THREE.MeshStandardMaterial({ color: primaryColor });

    for (let t = 0; t < tiers; t++) {
      const y = 1.2 + t * 2.4;
      const dist = 3.5 + t * 2.8;

      const north = new THREE.Mesh(new THREE.BoxGeometry(56 + t * 4, 2.1, 2.8), standMat);
      north.position.set(0, y, -17 - dist);
      scene.add(north);

      const northAccent = new THREE.Mesh(
        new THREE.BoxGeometry(56 + t * 4, 0.35, 2.95),
        accentMat
      );
      northAccent.position.set(0, y + 1.0, -17 - dist);
      scene.add(northAccent);

      const south = new THREE.Mesh(new THREE.BoxGeometry(56 + t * 4, 2.1, 2.8), standMat);
      south.position.set(0, y, 17 + dist);
      scene.add(south);

      const west = new THREE.Mesh(new THREE.BoxGeometry(2.8, 2.1, 34 + t * 4), standMat);
      west.position.set(-26 - dist, y, 0);
      scene.add(west);

      const east = new THREE.Mesh(new THREE.BoxGeometry(2.8, 2.1, 34 + t * 4), standMat);
      east.position.set(26 + dist, y, 0);
      scene.add(east);
    }

    // Floodlight towers
    const towerH = 14 + stadium.lightingLevel * 2.5;
    [
      [-32, -22],
      [32, -22],
      [-32, 22],
      [32, 22],
    ].forEach(([cx, cz]) => {
      const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.5, towerH, 8),
        new THREE.MeshStandardMaterial({ color: "#64748b" })
      );
      pole.position.set(cx, towerH / 2, cz);
      scene.add(pole);

      const lamp = new THREE.Mesh(
        new THREE.BoxGeometry(3.2, 1.6, 0.6),
        new THREE.MeshBasicMaterial({ color: "#fef08a" })
      );
      lamp.position.set(cx, towerH, cz);
      lamp.lookAt(0, 0, 0);
      scene.add(lamp);
    });

    // Scoreboard
    const sb = new THREE.Mesh(
      new THREE.BoxGeometry(10 + stadium.commercialLevel * 1.5, 4.2, 0.6),
      new THREE.MeshBasicMaterial({ color: "#10b981" })
    );
    sb.position.set(0, 5 + tiers * 2.5, -20 - tiers * 2.8);
    scene.add(sb);

    let frameId = 0;
    let angle = 0.6;
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      angle += 0.0045;
      const radius = 58 + tiers * 4;
      camera.position.set(
        Math.cos(angle) * radius,
        28 + tiers * 2.5,
        Math.sin(angle) * radius
      );
      camera.lookAt(0, 2, 0);
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frameId);
      renderer.dispose();
    };
  }, [stadium, primaryColor]);

  return (
    <div
      ref={mountRef}
      className="w-full h-72 sm:h-80 rounded-2xl overflow-hidden border border-slate-800 shadow-inner"
    />
  );
}
