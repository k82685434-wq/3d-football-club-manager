"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";
import confetti from "canvas-confetti";
import {
  ClubIdentity,
  FormationName,
  FORMATIONS,
  KitConfig,
  Mentality,
  Player,
  StadiumState,
} from "@/lib/gameData";
import { ClubBadge } from "@/components/ClubBadge";
import {
  Camera,
  FastForward,
  Pause,
  Play,
  Shield,
  Swords,
  Target,
  Users,
  Volume2,
  VolumeX,
  Zap,
  Sparkles,
  RefreshCw,
  Award,
} from "lucide-react";

export interface MatchGoalEvent {
  minute: number;
  team: "home" | "away";
  scorerId: string;
  scorerName: string;
  assistName?: string;
}

export interface MatchStatsSummary {
  homeScore: number;
  awayScore: number;
  homePossession: number;
  awayPossession: number;
  homeShots: number;
  awayShots: number;
  homeOnTarget: number;
  awayOnTarget: number;
  homePasses: number;
  awayPasses: number;
  homeTackles: number;
  awayTackles: number;
  goals: MatchGoalEvent[];
  mvpName: string;
}

interface Match3DEngineProps {
  homeClub: {
    name: string;
    shortName: string;
    kit: KitConfig;
    badge?: ClubIdentity["badge"];
    squad: Player[];
    formation: FormationName;
    mentality: Mentality;
    isUser: boolean;
  };
  awayClub: {
    name: string;
    shortName: string;
    kit: KitConfig;
    badge?: ClubIdentity["badge"];
    squad: Player[];
    formation: FormationName;
    mentality: Mentality;
    isUser: boolean;
  };
  stadium: StadiumState;
  stadiumName: string;
  competitionLabel: string;
  nightMatch?: boolean;
  onMatchComplete: (summary: MatchStatsSummary) => void;
  onCancelQuickMatch?: () => void;
  onClickAdvertisement?: (brandName?: string) => void;
}

type CameraMode = "broadcast" | "tactical" | "closeup" | "orbit";

interface SimPlayer {
  id: string;
  name: string;
  kitNumber: number;
  team: "home" | "away";
  role: string;
  isGK: boolean;
  slotIndex: number;
  baseNormX: number; // -1..0
  baseNormZ: number; // -1..1
  x: number;
  z: number;
  vx: number;
  vz: number;
  facingAngle: number;
  speedStat: number;
  shootStat: number;
  passStat: number;
  defendStat: number;
  gkStat: number;
  stamina: number;
  animPhase: number;
  kickTimer: number;
  tackleTimer: number;
  diveTimer: number;
  diveDir: number;
  meshGroup: THREE.Group;
  leftArm: THREE.Mesh;
  rightArm: THREE.Mesh;
  leftLeg: THREE.Mesh;
  rightLeg: THREE.Mesh;
  ringMesh: THREE.Mesh;
}

const PITCH_HALF_W = 46; // Total length = 92m (-46 to +46)
const PITCH_HALF_H = 30; // Total width = 60m (-30 to +30)
const GOAL_HALF_WIDTH = 5.2;
const GOAL_HEIGHT = 3.2;

function createKitTexture(kit: KitConfig, isGK = false): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext("2d")!;

  if (isGK) {
    ctx.fillStyle = "#F59E0B";
    ctx.fillRect(0, 0, 128, 128);
    ctx.fillStyle = "#1E293B";
    ctx.fillRect(0, 96, 128, 32);
  } else {
    ctx.fillStyle = kit.primaryColor;
    ctx.fillRect(0, 0, 128, 128);

    ctx.fillStyle = kit.secondaryColor;
    if (kit.pattern === "stripes") {
      for (let x = 16; x < 128; x += 32) {
        ctx.fillRect(x, 0, 14, 128);
      }
    } else if (kit.pattern === "hoops") {
      for (let y = 16; y < 128; y += 32) {
        ctx.fillRect(0, y, 128, 14);
      }
    } else if (kit.pattern === "sash") {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(36, 0);
      ctx.lineTo(128, 92);
      ctx.lineTo(128, 128);
      ctx.lineTo(92, 128);
      ctx.lineTo(0, 36);
      ctx.closePath();
      ctx.fill();
    } else if (kit.pattern === "halves") {
      ctx.fillRect(64, 0, 64, 128);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

function createPitchTexture(pitchLevel: number): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 680;
  const ctx = canvas.getContext("2d")!;

  // Rich mowed grass stripes
  const numStripes = 18;
  const stripeW = canvas.width / numStripes;
  for (let i = 0; i < numStripes; i++) {
    ctx.fillStyle =
      i % 2 === 0
        ? pitchLevel >= 3
          ? "#15803d"
          : "#166534"
        : pitchLevel >= 3
        ? "#16a34a"
        : "#15803d";
    ctx.fillRect(i * stripeW, 0, stripeW + 1, canvas.height);
  }

  // Subtle turf grain
  ctx.strokeStyle = "rgba(255, 255, 255, 0.92)";
  ctx.lineWidth = 4;

  const padX = 48;
  const padY = 44;
  const w = canvas.width - padX * 2;
  const h = canvas.height - padY * 2;

  // Outer touchline
  ctx.strokeRect(padX, padY, w, h);

  // Halfway line
  ctx.beginPath();
  ctx.moveTo(canvas.width / 2, padY);
  ctx.lineTo(canvas.width / 2, padY + h);
  ctx.stroke();

  // Center circle
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2, 74, 0, Math.PI * 2);
  ctx.stroke();

  // Center spot
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2, 6, 0, Math.PI * 2);
  ctx.fill();

  // Left & Right Penalty Boxes
  const penW = 148;
  const penH = 310;
  ctx.strokeRect(padX, (canvas.height - penH) / 2, penW, penH);
  ctx.strokeRect(padX + w - penW, (canvas.height - penH) / 2, penW, penH);

  // 6-yard boxes
  const sixW = 56;
  const sixH = 150;
  ctx.strokeRect(padX, (canvas.height - sixH) / 2, sixW, sixH);
  ctx.strokeRect(padX + w - sixW, (canvas.height - sixH) / 2, sixW, sixH);

  // Penalty arcs
  ctx.beginPath();
  ctx.arc(padX + 105, canvas.height / 2, 58, -0.65, 0.65);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(padX + w - 105, canvas.height / 2, 58, Math.PI - 0.65, Math.PI + 0.65);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.anisotropy = 4;
  texture.needsUpdate = true;
  return texture;
}

function createAdBoardTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 64;
  const ctx = canvas.getContext("2d")!;

  const brands = [
    { bg: "#064E3B", text: "VORTEX AD • +£9M", color: "#10B981" },
    { bg: "#1E293B", text: "APEX BOOTS • +£9M", color: "#F59E0B" },
    { bg: "#1E1B4B", text: "KINETIC 5G • +£9M", color: "#38BDF8" },
    { bg: "#3B0764", text: "HYPERION • +£9M", color: "#F472B6" },
    { bg: "#0F172A", text: "TURBO AIR • +£9M", color: "#FACC15" },
    { bg: "#14532D", text: "CLICK AD • +£9M", color: "#FFFFFF" },
  ];

  const segW = canvas.width / brands.length;
  brands.forEach((b, idx) => {
    ctx.fillStyle = b.bg;
    ctx.fillRect(idx * segW, 0, segW, canvas.height);
    ctx.strokeStyle = "#ffffff33";
    ctx.lineWidth = 2;
    ctx.strokeRect(idx * segW, 0, segW, canvas.height);
    ctx.fillStyle = b.color;
    ctx.font = "bold 22px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(b.text, idx * segW + segW / 2, canvas.height / 2);
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

export function Match3DEngine({
  homeClub,
  awayClub,
  stadium,
  stadiumName,
  competitionLabel,
  nightMatch = true,
  onMatchComplete,
  onCancelQuickMatch,
  onClickAdvertisement,
}: Match3DEngineProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const onClickAdRef = useRef(onClickAdvertisement);
  useEffect(() => {
    onClickAdRef.current = onClickAdvertisement;
  }, [onClickAdvertisement]);

  // UI state synced with simulation
  const [minute, setMinute] = useState<number>(0);
  const [homeScore, setHomeScore] = useState<number>(0);
  const [awayScore, setAwayScore] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [simSpeed, setSimSpeed] = useState<1 | 2 | 4>(1);
  const [cameraMode, setCameraMode] = useState<CameraMode>("broadcast");
  const [userMentality, setUserMentality] = useState<Mentality>(
    homeClub.isUser ? homeClub.mentality : awayClub.mentality
  );
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [goalBanner, setGoalBanner] = useState<{
    teamName: string;
    scorerName: string;
    minute: number;
    color: string;
  } | null>(null);
  const [commentary, setCommentary] = useState<string[]>([
    `Welcome to ${stadiumName} for this ${competitionLabel} clash between ${homeClub.name} and ${awayClub.name}!`,
    "The referee checks his watch and blows the whistle for kick-off!",
  ]);
  const [ballCarrierName, setBallCarrierName] = useState<string>("Kick-off");
  const [possessionPct, setPossessionPct] = useState<[number, number]>([50, 50]);
  const [shotsCount, setShotsCount] = useState<[number, number]>([0, 0]);
  const [onTargetCount, setOnTargetCount] = useState<[number, number]>([0, 0]);
  const [passesCount, setPassesCount] = useState<[number, number]>([0, 0]);
  const [tacklesCount, setTacklesCount] = useState<[number, number]>([0, 0]);
  const [goalsList, setGoalsList] = useState<MatchGoalEvent[]>([]);
  const [isFullTime, setIsFullTime] = useState<boolean>(false);
  const [showSubDrawer, setShowSubDrawer] = useState<boolean>(false);
  const [subsUsed, setSubsUsed] = useState<number>(0);
  const [pressBoostTimer, setPressBoostTimer] = useState<number>(0);

  // Radar canvas ref
  const radarCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Mutable refs for real-time 60fps loop access
  const stateRef = useRef({
    minute: 0,
    homeScore: 0,
    awayScore: 0,
    isPaused: false,
    simSpeed: 1,
    cameraMode: "broadcast" as CameraMode,
    userMentality: (homeClub.isUser ? homeClub.mentality : awayClub.mentality) as Mentality,
    pressBoost: 0,
    celebrationTimer: 0,
    celebratingScorerId: null as string | null,
    homePossFrames: 100,
    awayPossFrames: 100,
    homeShots: 0,
    awayShots: 0,
    homeOnTarget: 0,
    awayOnTarget: 0,
    homePasses: 0,
    awayPasses: 0,
    homeTackles: 0,
    awayTackles: 0,
    goals: [] as MatchGoalEvent[],
    isFullTime: false,
    forceCommand: null as null | "shoot" | "pass",
    scoreboardCtx: null as CanvasRenderingContext2D | null,
    scoreboardTex: null as THREE.CanvasTexture | null,
  });

  // Web Audio synthesizer for whistle, kick, and goal roar
  const playSound = useCallback(
    (type: "kick" | "whistle" | "goal" | "post") => {
      if (!soundEnabled || typeof window === "undefined") return;
      try {
        const AudioCtx =
          window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        const now = ctx.currentTime;

        if (type === "kick") {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(135, now);
          osc.frequency.exponentialRampToValueAtTime(42, now + 0.09);
          gain.gain.setValueAtTime(0.18, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.09);
        } else if (type === "whistle") {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(2750, now);
          osc.frequency.setValueAtTime(2900, now + 0.12);
          gain.gain.setValueAtTime(0.08, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.35);
        } else if (type === "goal") {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sawtooth";
          osc.frequency.setValueAtTime(220, now);
          osc.frequency.exponentialRampToValueAtTime(440, now + 0.45);
          gain.gain.setValueAtTime(0.12, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.8);
        }
      } catch {
        // Ignore audio errors if blocked by browser autoplay policy
      }
    },
    [soundEnabled]
  );

  const pushCommentary = useCallback((line: string) => {
    setCommentary((prev) => [line, ...prev.slice(0, 14)]);
  }, []);

  // Sync control states into ref
  useEffect(() => {
    stateRef.current.isPaused = isPaused;
  }, [isPaused]);
  useEffect(() => {
    stateRef.current.simSpeed = simSpeed;
  }, [simSpeed]);
  useEffect(() => {
    stateRef.current.cameraMode = cameraMode;
  }, [cameraMode]);
  useEffect(() => {
    stateRef.current.userMentality = userMentality;
  }, [userMentality]);

  // Update 3D stadium scoreboard canvas
  const update3DScoreboard = useCallback(
    (hScore: number, aScore: number, min: number) => {
      const ctx = stateRef.current.scoreboardCtx;
      const tex = stateRef.current.scoreboardTex;
      if (!ctx || !tex) return;

      ctx.fillStyle = "#090D16";
      ctx.fillRect(0, 0, 512, 192);
      ctx.strokeStyle = "#10B981";
      ctx.lineWidth = 6;
      ctx.strokeRect(4, 4, 504, 184);

      ctx.fillStyle = "#94A3B8";
      ctx.font = "bold 20px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(competitionLabel.toUpperCase(), 256, 36);

      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 46px monospace";
      ctx.fillText(
        `${homeClub.shortName}  ${hScore} - ${aScore}  ${awayClub.shortName}`,
        256,
        104
      );

      ctx.fillStyle = "#10B981";
      ctx.font = "bold 32px monospace";
      ctx.fillText(`${Math.min(90, Math.floor(min))}'`, 256, 158);

      tex.needsUpdate = true;
    },
    [competitionLabel, homeClub.shortName, awayClub.shortName]
  );

  // Main Three.js Scene & 11v11 Match Simulation Loop
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 1000;
    const height = container.clientHeight || 620;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(nightMatch ? "#060913" : "#38bdf8");
    scene.fog = new THREE.FogExp2(nightMatch ? "#060913" : "#bae6fd", 0.0042);

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.5, 450);
    camera.position.set(0, 38, 56);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.innerHTML = "";
    container.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(
      nightMatch ? 0xdbeafe : 0xffffff,
      nightMatch ? 0.75 : 1.05
    );
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffbeb, nightMatch ? 1.35 : 1.6);
    sunLight.position.set(35, 65, 40);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 180;
    sunLight.shadow.camera.left = -60;
    sunLight.shadow.camera.right = 60;
    sunLight.shadow.camera.top = 45;
    sunLight.shadow.camera.bottom = -45;
    scene.add(sunLight);

    // Outer stadium apron
    const apronGeo = new THREE.PlaneGeometry(160, 120);
    const apronMat = new THREE.MeshStandardMaterial({
      color: "#1e293b",
      roughness: 0.9,
    });
    const apronMesh = new THREE.Mesh(apronGeo, apronMat);
    apronMesh.rotation.x = -Math.PI / 2;
    apronMesh.position.y = -0.08;
    apronMesh.receiveShadow = true;
    scene.add(apronMesh);

    // Pitch surface with markings
    const pitchTex = createPitchTexture(stadium.pitchLevel);
    const pitchGeo = new THREE.PlaneGeometry(PITCH_HALF_W * 2 + 8, PITCH_HALF_H * 2 + 8);
    const pitchMat = new THREE.MeshStandardMaterial({
      map: pitchTex,
      roughness: 0.78,
      metalness: 0.04,
    });
    const pitchMesh = new THREE.Mesh(pitchGeo, pitchMat);
    pitchMesh.rotation.x = -Math.PI / 2;
    pitchMesh.receiveShadow = true;
    scene.add(pitchMesh);

    // Build 3D Goals at both ends (-PITCH_HALF_W and +PITCH_HALF_W)
    const buildGoal = (xPos: number, dir: number) => {
      const goalGroup = new THREE.Group();
      const postMat = new THREE.MeshStandardMaterial({
        color: "#ffffff",
        roughness: 0.2,
        metalness: 0.5,
      });

      const postGeo = new THREE.CylinderGeometry(0.14, 0.14, GOAL_HEIGHT, 12);
      const leftPost = new THREE.Mesh(postGeo, postMat);
      leftPost.position.set(xPos, GOAL_HEIGHT / 2, -GOAL_HALF_WIDTH);
      leftPost.castShadow = true;
      goalGroup.add(leftPost);

      const rightPost = new THREE.Mesh(postGeo, postMat);
      rightPost.position.set(xPos, GOAL_HEIGHT / 2, GOAL_HALF_WIDTH);
      rightPost.castShadow = true;
      goalGroup.add(rightPost);

      const crossbarGeo = new THREE.CylinderGeometry(
        0.14,
        0.14,
        GOAL_HALF_WIDTH * 2 + 0.2,
        12
      );
      const crossbar = new THREE.Mesh(crossbarGeo, postMat);
      crossbar.rotation.x = Math.PI / 2;
      crossbar.position.set(xPos, GOAL_HEIGHT, 0);
      crossbar.castShadow = true;
      goalGroup.add(crossbar);

      // Goal Net Box
      const netDepth = 2.6;
      const netGeo = new THREE.BoxGeometry(
        netDepth,
        GOAL_HEIGHT,
        GOAL_HALF_WIDTH * 2
      );
      const netMat = new THREE.MeshBasicMaterial({
        color: "#e2e8f0",
        wireframe: true,
        transparent: true,
        opacity: 0.35,
      });
      const netMesh = new THREE.Mesh(netGeo, netMat);
      netMesh.position.set(xPos + (dir * netDepth) / 2, GOAL_HEIGHT / 2, 0);
      goalGroup.add(netMesh);

      scene.add(goalGroup);
    };

    buildGoal(-PITCH_HALF_W, -1);
    buildGoal(PITCH_HALF_W, 1);

    // Perimeter LED Advertising Boards
    const adTex = createAdBoardTexture();
    const adMat = new THREE.MeshBasicMaterial({ map: adTex });
    const northAd = new THREE.Mesh(
      new THREE.BoxGeometry(PITCH_HALF_W * 2, 1.2, 0.3),
      adMat
    );
    northAd.position.set(0, 0.6, -PITCH_HALF_H - 3.6);
    scene.add(northAd);

    const southAd = new THREE.Mesh(
      new THREE.BoxGeometry(PITCH_HALF_W * 2, 1.2, 0.3),
      adMat
    );
    southAd.position.set(0, 0.6, PITCH_HALF_H + 3.6);
    scene.add(southAd);

    // Upgradeable 3D Stadium Stands & Spectators
    const tiers = Math.max(1, stadium.capacityLevel);
    const standMat = new THREE.MeshStandardMaterial({
      color: "#1e293b",
      roughness: 0.85,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: homeClub.kit.primaryColor,
      roughness: 0.5,
    });

    const crowdPositions: THREE.Vector3[] = [];

    for (let t = 0; t < tiers; t++) {
      const y = 1.6 + t * 3.2;
      const offset = 6.5 + t * 4.2;

      // North Stand
      const nStand = new THREE.Mesh(
        new THREE.BoxGeometry(PITCH_HALF_W * 2 + 8, 2.8, 4.0),
        standMat
      );
      nStand.position.set(0, y, -PITCH_HALF_H - offset);
      nStand.receiveShadow = true;
      scene.add(nStand);

      // Trim Fascia
      const nTrim = new THREE.Mesh(
        new THREE.BoxGeometry(PITCH_HALF_W * 2 + 8, 0.45, 4.15),
        trimMat
      );
      nTrim.position.set(0, y + 1.3, -PITCH_HALF_H - offset);
      scene.add(nTrim);

      // South Stand
      const sStand = new THREE.Mesh(
        new THREE.BoxGeometry(PITCH_HALF_W * 2 + 8, 2.8, 4.0),
        standMat
      );
      sStand.position.set(0, y, PITCH_HALF_H + offset);
      scene.add(sStand);

      // West & East Goal Stands
      const wStand = new THREE.Mesh(
        new THREE.BoxGeometry(4.0, 2.8, PITCH_HALF_H * 2 + 4),
        standMat
      );
      wStand.position.set(-PITCH_HALF_W - offset, y, 0);
      scene.add(wStand);

      const eStand = new THREE.Mesh(
        new THREE.BoxGeometry(4.0, 2.8, PITCH_HALF_H * 2 + 4),
        standMat
      );
      eStand.position.set(PITCH_HALF_W + offset, y, 0);
      scene.add(eStand);

      // Populate spectator positions along the stands
      for (let x = -PITCH_HALF_W; x <= PITCH_HALF_W; x += 2.6) {
        crowdPositions.push(new THREE.Vector3(x, y + 1.85, -PITCH_HALF_H - offset + 0.6));
        crowdPositions.push(new THREE.Vector3(x, y + 1.85, PITCH_HALF_H + offset - 0.6));
      }
      for (let z = -PITCH_HALF_H + 4; z <= PITCH_HALF_H - 4; z += 2.8) {
        crowdPositions.push(new THREE.Vector3(-PITCH_HALF_W - offset + 0.6, y + 1.85, z));
        crowdPositions.push(new THREE.Vector3(PITCH_HALF_W + offset - 0.6, y + 1.85, z));
      }
    }

    // Instanced 3D Blocky Spectators
    const crowdGeo = new THREE.BoxGeometry(0.65, 1.15, 0.65);
    const crowdMat = new THREE.MeshLambertMaterial({ color: "#ffffff" });
    const crowdInstanced = new THREE.InstancedMesh(
      crowdGeo,
      crowdMat,
      crowdPositions.length
    );
    const dummy = new THREE.Object3D();
    const colorObj = new THREE.Color();
    const palette = [
      homeClub.kit.primaryColor,
      homeClub.kit.secondaryColor,
      awayClub.kit.primaryColor,
      "#f8fafc",
      "#f59e0b",
    ];
    crowdPositions.forEach((pos, idx) => {
      dummy.position.copy(pos);
      dummy.updateMatrix();
      crowdInstanced.setMatrixAt(idx, dummy.matrix);
      colorObj.set(palette[idx % palette.length]);
      crowdInstanced.setColorAt(idx, colorObj);
    });
    crowdInstanced.instanceMatrix.needsUpdate = true;
    if (crowdInstanced.instanceColor) crowdInstanced.instanceColor.needsUpdate = true;
    scene.add(crowdInstanced);

    // 4 Corner Floodlight Towers
    const towerHeight = 22 + stadium.lightingLevel * 3;
    const cornerCoords = [
      [-PITCH_HALF_W - 10, -PITCH_HALF_H - 10],
      [PITCH_HALF_W + 10, -PITCH_HALF_H - 10],
      [-PITCH_HALF_W - 10, PITCH_HALF_H + 10],
      [PITCH_HALF_W + 10, PITCH_HALF_H + 10],
    ];
    cornerCoords.forEach(([cx, cz]) => {
      const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.45, 0.7, towerHeight, 8),
        new THREE.MeshStandardMaterial({ color: "#475569", metalness: 0.6 })
      );
      pole.position.set(cx, towerHeight / 2, cz);
      scene.add(pole);

      const head = new THREE.Mesh(
        new THREE.BoxGeometry(4.2, 2.2, 1.0),
        new THREE.MeshBasicMaterial({ color: "#fef08a" })
      );
      head.position.set(cx, towerHeight, cz);
      head.lookAt(0, 0, 0);
      scene.add(head);
    });

    // Giant 3D Stadium Scoreboard above North Stand
    const sbCanvas = document.createElement("canvas");
    sbCanvas.width = 512;
    sbCanvas.height = 192;
    const sbCtx = sbCanvas.getContext("2d")!;
    const sbTex = new THREE.CanvasTexture(sbCanvas);
    stateRef.current.scoreboardCtx = sbCtx;
    stateRef.current.scoreboardTex = sbTex;
    update3DScoreboard(0, 0, 0);

    const sbHeight = 8 + tiers * 3.3;
    const sbMesh = new THREE.Mesh(
      new THREE.BoxGeometry(18, 6.8, 0.8),
      new THREE.MeshBasicMaterial({ map: sbTex })
    );
    sbMesh.position.set(0, sbHeight, -PITCH_HALF_H - 8 - tiers * 3.5);
    scene.add(sbMesh);

    // Build Roblox-Inspired Low-Poly Articulated Player Character
    const createRobloxPlayerMesh = (
      kitTex: THREE.CanvasTexture,
      shortsColor: string,
      skinTone: string,
      hairColor: string,
      ringColor: string
    ) => {
      const group = new THREE.Group();

      // Selection / Role Ring on turf
      const ringGeo = new THREE.RingGeometry(0.75, 1.02, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: ringColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.65,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = -Math.PI / 2;
      ringMesh.position.y = 0.04;
      group.add(ringMesh);

      // Torso (Jersey)
      const torsoGeo = new THREE.BoxGeometry(0.95, 1.15, 0.52);
      const torsoMat = new THREE.MeshStandardMaterial({
        map: kitTex,
        roughness: 0.6,
      });
      const torso = new THREE.Mesh(torsoGeo, torsoMat);
      torso.position.y = 1.45;
      torso.castShadow = true;
      group.add(torso);

      // Head
      const headGeo = new THREE.BoxGeometry(0.68, 0.68, 0.68);
      const headMat = new THREE.MeshStandardMaterial({
        color: skinTone,
        roughness: 0.5,
      });
      const head = new THREE.Mesh(headGeo, headMat);
      head.position.y = 2.42;
      head.castShadow = true;
      group.add(head);

      // Blocky Hair Cap
      const hairGeo = new THREE.BoxGeometry(0.72, 0.24, 0.72);
      const hairMat = new THREE.MeshStandardMaterial({ color: hairColor });
      const hair = new THREE.Mesh(hairGeo, hairMat);
      hair.position.y = 2.76;
      group.add(hair);

      // Arms
      const armGeo = new THREE.BoxGeometry(0.32, 0.98, 0.32);
      const armMat = new THREE.MeshStandardMaterial({ color: skinTone });
      const leftArm = new THREE.Mesh(armGeo, armMat);
      leftArm.position.set(-0.66, 1.42, 0);
      leftArm.castShadow = true;
      group.add(leftArm);

      const rightArm = new THREE.Mesh(armGeo, armMat);
      rightArm.position.set(0.66, 1.42, 0);
      rightArm.castShadow = true;
      group.add(rightArm);

      // Legs
      const legGeo = new THREE.BoxGeometry(0.38, 0.92, 0.38);
      const legMat = new THREE.MeshStandardMaterial({ color: shortsColor });
      const leftLeg = new THREE.Mesh(legGeo, legMat);
      leftLeg.position.set(-0.24, 0.48, 0);
      leftLeg.castShadow = true;
      group.add(leftLeg);

      const rightLeg = new THREE.Mesh(legGeo, legMat);
      rightLeg.position.set(0.24, 0.48, 0);
      rightLeg.castShadow = true;
      group.add(rightLeg);

      return { group, leftArm, rightArm, leftLeg, rightLeg, ringMesh };
    };

    const homeKitTex = createKitTexture(homeClub.kit, false);
    const awayKitTex = createKitTexture(awayClub.kit, false);
    const gkKitTex = createKitTexture(homeClub.kit, true);

    const simPlayers: SimPlayer[] = [];

    const spawnTeam = (
      teamKey: "home" | "away",
      squad: Player[],
      formation: FormationName,
      kitTex: THREE.CanvasTexture,
      shortsColor: string,
      ringColor: string
    ) => {
      const slots = FORMATIONS[formation] || FORMATIONS["4-3-3"];
      const starters = squad.filter((p) => p.isStarter);
      const activeEleven =
        starters.length >= 11 ? starters.slice(0, 11) : squad.slice(0, 11);

      slots.forEach((slot, idx) => {
        const p = activeEleven[idx] || activeEleven[0];
        const isGK = slot.role === "GK" || idx === 0;
        const sideSign = teamKey === "home" ? 1 : -1;
        const startX = slot.normX * PITCH_HALF_W * sideSign;
        const startZ = slot.normZ * PITCH_HALF_H * sideSign;

        const rig = createRobloxPlayerMesh(
          isGK ? gkKitTex : kitTex,
          isGK ? "#0f172a" : shortsColor,
          p?.skinTone || "#E8B89A",
          p?.hairColor || "#1C1917",
          ringColor
        );
        rig.group.position.set(startX, 0, startZ);
        scene.add(rig.group);

        simPlayers.push({
          id: `${teamKey}_${p?.id || idx}`,
          name: p?.name || `${teamKey.toUpperCase()} #${idx + 1}`,
          kitNumber: p?.kitNumber || idx + 1,
          team: teamKey,
          role: slot.role,
          isGK,
          slotIndex: idx,
          baseNormX: slot.normX,
          baseNormZ: slot.normZ,
          x: startX,
          z: startZ,
          vx: 0,
          vz: 0,
          facingAngle: teamKey === "home" ? 0 : Math.PI,
          speedStat: p?.attributes.speed || 65,
          shootStat: p?.attributes.shooting || 62,
          passStat: p?.attributes.passing || 64,
          defendStat: p?.attributes.defending || 62,
          gkStat: p?.attributes.goalkeeping || 65,
          stamina: p?.fitness || 95,
          animPhase: idx * 0.7,
          kickTimer: 0,
          tackleTimer: 0,
          diveTimer: 0,
          diveDir: 0,
          meshGroup: rig.group,
          leftArm: rig.leftArm,
          rightArm: rig.rightArm,
          leftLeg: rig.leftLeg,
          rightLeg: rig.rightLeg,
          ringMesh: rig.ringMesh,
        });
      });
    };

    spawnTeam(
      "home",
      homeClub.squad,
      homeClub.formation,
      homeKitTex,
      homeClub.kit.shortsColor,
      homeClub.kit.primaryColor
    );
    spawnTeam(
      "away",
      awayClub.squad,
      awayClub.formation,
      awayKitTex,
      awayClub.kit.shortsColor,
      awayClub.kit.primaryColor
    );

    // 23rd Character on Pitch: The Referee!
    const refKitTex = createKitTexture(
      {
        pattern: "solid",
        primaryColor: "#111827",
        secondaryColor: "#facc15",
        shortsColor: "#111827",
        socksColor: "#111827",
      },
      false
    );
    const refRig = createRobloxPlayerMesh(
      refKitTex,
      "#111827",
      "#E8B89A",
      "#1C1917",
      "#facc15"
    );
    refRig.group.position.set(0, 0, -6);
    scene.add(refRig.group);

    // 3D Football Ball
    const ballGeo = new THREE.SphereGeometry(0.46, 20, 20);
    const ballMat = new THREE.MeshStandardMaterial({
      color: "#ffffff",
      roughness: 0.3,
      metalness: 0.1,
    });
    const ballMesh = new THREE.Mesh(ballGeo, ballMat);
    ballMesh.castShadow = true;
    ballMesh.position.set(0, 0.46, 0);
    scene.add(ballMesh);

    const ball = {
      x: 0,
      y: 0.46,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      owner: null as SimPlayer | null,
      lastTouchTeam: "home" as "home" | "away",
      lastPasserName: undefined as string | undefined,
      cooldown: 0,
    };

    const resetPositionsForKickoff = (kickingTeam: "home" | "away") => {
      ball.x = 0;
      ball.y = 0.46;
      ball.z = 0;
      ball.vx = 0;
      ball.vy = 0;
      ball.vz = 0;
      ball.owner = null;
      ball.cooldown = 0.4;

      simPlayers.forEach((sp) => {
        const sideSign = sp.team === "home" ? 1 : -1;
        sp.x = sp.baseNormX * PITCH_HALF_W * sideSign;
        sp.z = sp.baseNormZ * PITCH_HALF_H * sideSign;
        sp.vx = 0;
        sp.vz = 0;
        sp.diveTimer = 0;
        sp.tackleTimer = 0;
        if (sp.team === kickingTeam && sp.slotIndex === 9) {
          sp.x = sideSign * -1.2;
          sp.z = 0;
          ball.owner = sp;
        }
        sp.meshGroup.position.set(sp.x, 0, sp.z);
      });
    };

    resetPositionsForKickoff("home");
    playSound("whistle");

    let decisionCooldown = 0;
    let clock = new THREE.Clock();
    let animFrameId = 0;
    let orbitAngle = 0;

    const triggerGoal = (scoringTeam: "home" | "away", scorer: SimPlayer) => {
      playSound("goal");
      confetti({
        particleCount: 70,
        spread: 65,
        origin: { y: 0.6 },
      });

      const currentMin = Math.max(1, Math.min(90, Math.floor(stateRef.current.minute)));
      if (scoringTeam === "home") {
        stateRef.current.homeScore += 1;
        setHomeScore(stateRef.current.homeScore);
      } else {
        stateRef.current.awayScore += 1;
        setAwayScore(stateRef.current.awayScore);
      }

      const newGoal: MatchGoalEvent = {
        minute: currentMin,
        team: scoringTeam,
        scorerId: scorer.id,
        scorerName: scorer.name,
        assistName: ball.lastPasserName !== scorer.name ? ball.lastPasserName : undefined,
      };
      stateRef.current.goals.push(newGoal);
      setGoalsList([...stateRef.current.goals]);

      const clubName = scoringTeam === "home" ? homeClub.name : awayClub.name;
      const clubColor =
        scoringTeam === "home" ? homeClub.kit.primaryColor : awayClub.kit.primaryColor;

      setGoalBanner({
        teamName: clubName,
        scorerName: scorer.name,
        minute: currentMin,
        color: clubColor,
      });

      pushCommentary(
        `⚽ GOAL! (${currentMin}') ${scorer.name} fires it into the net for ${clubName}! (${stateRef.current.homeScore}-${stateRef.current.awayScore})`
      );

      update3DScoreboard(
        stateRef.current.homeScore,
        stateRef.current.awayScore,
        stateRef.current.minute
      );

      stateRef.current.celebrationTimer = 3.2;
      stateRef.current.celebratingScorerId = scorer.id;
    };

    const drawRadar = () => {
      const rCanvas = radarCanvasRef.current;
      if (!rCanvas) return;
      const rCtx = rCanvas.getContext("2d");
      if (!rCtx) return;

      const rw = rCanvas.width;
      const rh = rCanvas.height;
      rCtx.fillStyle = "#064e3b";
      rCtx.fillRect(0, 0, rw, rh);

      rCtx.strokeStyle = "rgba(255,255,255,0.35)";
      rCtx.lineWidth = 1.5;
      rCtx.strokeRect(4, 4, rw - 8, rh - 8);
      rCtx.beginPath();
      rCtx.moveTo(rw / 2, 4);
      rCtx.lineTo(rw / 2, rh - 4);
      rCtx.stroke();
      rCtx.beginPath();
      rCtx.arc(rw / 2, rh / 2, 14, 0, Math.PI * 2);
      rCtx.stroke();

      simPlayers.forEach((sp) => {
        const px = ((sp.x + PITCH_HALF_W) / (PITCH_HALF_W * 2)) * (rw - 12) + 6;
        const pz = ((sp.z + PITCH_HALF_H) / (PITCH_HALF_H * 2)) * (rh - 12) + 6;
        rCtx.fillStyle =
          sp.team === "home" ? homeClub.kit.primaryColor : awayClub.kit.primaryColor;
        rCtx.beginPath();
        rCtx.arc(px, pz, 4, 0, Math.PI * 2);
        rCtx.fill();
        rCtx.strokeStyle = "#ffffff";
        rCtx.lineWidth = 1;
        rCtx.stroke();
      });

      // Ball dot
      const bx = ((ball.x + PITCH_HALF_W) / (PITCH_HALF_W * 2)) * (rw - 12) + 6;
      const bz = ((ball.z + PITCH_HALF_H) / (PITCH_HALF_H * 2)) * (rh - 12) + 6;
      rCtx.fillStyle = "#facc15";
      rCtx.beginPath();
      rCtx.arc(bx, bz, 4.8, 0, Math.PI * 2);
      rCtx.fill();
    };

    // Main frame update
    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const rawDt = Math.min(clock.getDelta(), 0.05);

      if (stateRef.current.isPaused || stateRef.current.isFullTime) {
        renderer.render(scene, camera);
        return;
      }

      const dt = rawDt * stateRef.current.simSpeed;

      // Celebration sequence
      if (stateRef.current.celebrationTimer > 0) {
        stateRef.current.celebrationTimer -= rawDt;
        const scorer = simPlayers.find(
          (p) => p.id === stateRef.current.celebratingScorerId
        );
        if (scorer) {
          scorer.meshGroup.position.y =
            Math.abs(Math.sin(stateRef.current.celebrationTimer * 10)) * 1.4;
          scorer.meshGroup.rotation.y += rawDt * 8;
          scorer.leftArm.rotation.x = Math.PI;
          scorer.rightArm.rotation.x = Math.PI;

          // Camera swoops toward scorer
          camera.position.lerp(
            new THREE.Vector3(scorer.x * 0.7, 12, scorer.z + 18),
            0.08
          );
          camera.lookAt(scorer.x, 2, scorer.z);
        }

        if (stateRef.current.celebrationTimer <= 0) {
          setGoalBanner(null);
          const nextKickTeam =
            stateRef.current.goals[stateRef.current.goals.length - 1]?.team === "home"
              ? "away"
              : "home";
          resetPositionsForKickoff(nextKickTeam);
          playSound("whistle");
        }

        renderer.render(scene, camera);
        return;
      }

      // Advance Match Clock (90 minutes in ~90 real seconds at 1x speed)
      stateRef.current.minute += dt * 1.05;
      const flooredMin = Math.floor(stateRef.current.minute);
      setMinute(Math.min(90, flooredMin));

      if (stateRef.current.pressBoost > 0) {
        stateRef.current.pressBoost = Math.max(0, stateRef.current.pressBoost - dt);
        setPressBoostTimer(Math.ceil(stateRef.current.pressBoost));
      }

      if (flooredMin % 2 === 0) {
        update3DScoreboard(
          stateRef.current.homeScore,
          stateRef.current.awayScore,
          stateRef.current.minute
        );
      }

      // Full time check
      if (stateRef.current.minute >= 90 && !stateRef.current.isFullTime) {
        stateRef.current.isFullTime = true;
        setIsFullTime(true);
        playSound("whistle");
        pushCommentary(
          `🏁 FULL TIME! ${homeClub.name} ${stateRef.current.homeScore} - ${stateRef.current.awayScore} ${awayClub.name}!`
        );
        return;
      }

      // Ball cooldown
      if (ball.cooldown > 0) {
        ball.cooldown -= dt;
      }

      // Update Ball Physics when free
      if (ball.owner) {
        const owner = ball.owner;
        const forwardX = Math.cos(owner.facingAngle);
        const forwardZ = Math.sin(owner.facingAngle);
        ball.x = owner.x + forwardX * 0.85;
        ball.z = owner.z + forwardZ * 0.85;
        ball.y = 0.46;
        ball.vx = owner.vx;
        ball.vz = owner.vz;
        ball.vy = 0;

        if (owner.team === "home") stateRef.current.homePossFrames += 1;
        else stateRef.current.awayPossFrames += 1;

        const totalPoss =
          stateRef.current.homePossFrames + stateRef.current.awayPossFrames;
        if (Math.random() < 0.08) {
          const hPct = Math.round((stateRef.current.homePossFrames / totalPoss) * 100);
          setPossessionPct([hPct, 100 - hPct]);
          setBallCarrierName(`${owner.name} (#${owner.kitNumber})`);
        }
      } else {
        ball.x += ball.vx * dt;
        ball.y += ball.vy * dt;
        ball.z += ball.vz * dt;

        if (ball.y > 0.46) {
          ball.vy -= 25 * dt; // Gravity
        } else {
          ball.y = 0.46;
          if (Math.abs(ball.vy) > 2.2) {
            ball.vy = -ball.vy * 0.55;
          } else {
            ball.vy = 0;
          }
          // Turf friction
          ball.vx *= Math.pow(0.28, dt);
          ball.vz *= Math.pow(0.28, dt);
        }

        // Check Goal Scoring at Left Goal (-PITCH_HALF_W) or Right Goal (+PITCH_HALF_W)
        if (Math.abs(ball.z) < GOAL_HALF_WIDTH && ball.y < GOAL_HEIGHT + 0.3) {
          if (ball.x >= PITCH_HALF_W - 0.3) {
            // Home Team Scored (attacks +X)
            const homeScorer =
              simPlayers
                .filter((p) => p.team === "home" && !p.isGK)
                .sort(
                  (a, b) =>
                    Math.hypot(a.x - ball.x, a.z - ball.z) -
                    Math.hypot(b.x - ball.x, b.z - ball.z)
                )[0] || simPlayers[9];
            triggerGoal("home", homeScorer);
            return;
          } else if (ball.x <= -PITCH_HALF_W + 0.3) {
            // Away Team Scored (attacks -X)
            const awayScorer =
              simPlayers
                .filter((p) => p.team === "away" && !p.isGK)
                .sort(
                  (a, b) =>
                    Math.hypot(a.x - ball.x, a.z - ball.z) -
                    Math.hypot(b.x - ball.x, b.z - ball.z)
                )[0] || simPlayers[20];
            triggerGoal("away", awayScorer);
            return;
          }
        }

        // Keep ball inside pitch boundaries (bounce/throw-in recovery)
        if (Math.abs(ball.z) > PITCH_HALF_H - 0.5) {
          ball.z = Math.sign(ball.z) * (PITCH_HALF_H - 0.6);
          ball.vz = -ball.vz * 0.5;
        }
        if (Math.abs(ball.x) > PITCH_HALF_W - 0.5) {
          ball.x = Math.sign(ball.x) * (PITCH_HALF_W - 0.6);
          ball.vx = -ball.vx * 0.45;
        }
      }

      ballMesh.position.set(ball.x, ball.y, ball.z);
      ballMesh.rotation.x += ball.vz * dt * 0.8;
      ballMesh.rotation.z -= ball.vx * dt * 0.8;

      // Determine closest player from each team to chase the ball
      let closestHome: SimPlayer | null = null;
      let minHomeDist = 999;
      let closestAway: SimPlayer | null = null;
      let minAwayDist = 999;

      simPlayers.forEach((sp) => {
        if (sp.isGK) return;
        const d = Math.hypot(sp.x - ball.x, sp.z - ball.z);
        if (sp.team === "home" && d < minHomeDist) {
          minHomeDist = d;
          closestHome = sp;
        } else if (sp.team === "away" && d < minAwayDist) {
          minAwayDist = d;
          closestAway = sp;
        }
      });

      // AI Decisions for Ball Owner (Dribble, Pass, Shoot, or User Command)
      decisionCooldown -= dt;
      if (ball.owner && decisionCooldown <= 0) {
        const owner = ball.owner;
        const attackDir = owner.team === "home" ? 1 : -1;
        const goalX = attackDir * PITCH_HALF_W;
        const distToGoal = Math.hypot(goalX - owner.x, 0 - owner.z);

        const isUserTeam =
          (owner.team === "home" && homeClub.isUser) ||
          (owner.team === "away" && awayClub.isUser);

        const forced = isUserTeam ? stateRef.current.forceCommand : null;
        if (forced) stateRef.current.forceCommand = null;

        // Nearest opponent defender distance
        const nearestOppDist = simPlayers
          .filter((p) => p.team !== owner.team)
          .reduce(
            (min, p) => Math.min(min, Math.hypot(p.x - owner.x, p.z - owner.z)),
            999
          );

        // 1. Check Shoot Condition
        if (
          forced === "shoot" ||
          (distToGoal < 24 && (Math.random() < 0.42 || distToGoal < 14))
        ) {
          ball.owner = null;
          ball.cooldown = 0.45;
          owner.kickTimer = 0.35;
          playSound("kick");

          const aimZ = (Math.random() - 0.5) * (GOAL_HALF_WIDTH * 1.75);
          const dx = goalX - owner.x;
          const dz = aimZ - owner.z;
          const len = Math.hypot(dx, dz) || 1;
          const shotSpeed = 28 + (owner.shootStat / 100) * 14;

          ball.vx = (dx / len) * shotSpeed;
          ball.vz = (dz / len) * shotSpeed;
          ball.vy = 2.8 + Math.random() * 3.8;

          if (owner.team === "home") {
            stateRef.current.homeShots += 1;
            stateRef.current.homeOnTarget += 1;
          } else {
            stateRef.current.awayShots += 1;
            stateRef.current.awayOnTarget += 1;
          }
          setShotsCount([stateRef.current.homeShots, stateRef.current.awayShots]);
          setOnTargetCount([
            stateRef.current.homeOnTarget,
            stateRef.current.awayOnTarget,
          ]);

          pushCommentary(
            `💥 ${owner.name} unleashes a fierce strike toward the corner from ${Math.round(distToGoal)}m!`
          );
          decisionCooldown = 0.55;
        }
        // 2. Check Pass Condition
        else if (
          forced === "pass" ||
          owner.isGK ||
          nearestOppDist < 4.5 ||
          Math.random() < 0.38
        ) {
          // Find best open teammate
          const teammates = simPlayers.filter(
            (p) => p.team === owner.team && p.id !== owner.id && !p.isGK
          );
          let bestTarget: SimPlayer | null = null;
          let bestScore = -999;

          teammates.forEach((tm) => {
            const dist = Math.hypot(tm.x - owner.x, tm.z - owner.z);
            if (dist < 4 || dist > 38) return;
            const forwardGain = (tm.x - owner.x) * attackDir;
            const score = forwardGain * 1.4 - dist * 0.25 + (Math.random() - 0.5) * 8;
            if (score > bestScore) {
              bestScore = score;
              bestTarget = tm;
            }
          });

          if (bestTarget) {
            const target = bestTarget as SimPlayer;
            ball.owner = null;
            ball.cooldown = 0.32;
            ball.lastPasserName = owner.name;
            owner.kickTimer = 0.28;
            playSound("kick");

            const dx = target.x + target.vx * 0.35 - owner.x;
            const dz = target.z + target.vz * 0.35 - owner.z;
            const dist = Math.hypot(dx, dz) || 1;
            const passSpeed = Math.min(28, Math.max(15, dist * 1.15));

            ball.vx = (dx / dist) * passSpeed;
            ball.vz = (dz / dist) * passSpeed;
            ball.vy = dist > 20 ? 3.8 : 0.8;

            if (owner.team === "home") stateRef.current.homePasses += 1;
            else stateRef.current.awayPasses += 1;
            setPassesCount([
              stateRef.current.homePasses,
              stateRef.current.awayPasses,
            ]);

            if (Math.random() < 0.35) {
              pushCommentary(
                `${owner.name} threads a crisp pass toward ${target.name}.`
              );
            }
            decisionCooldown = 0.45;
          }
        } else {
          decisionCooldown = 0.28;
        }
      }

      // Update all 22 Players movement, tackling, GK saves, and limb animations
      const ballNormX = ball.x / PITCH_HALF_W; // -1..1

      simPlayers.forEach((sp) => {
        const sideSign = sp.team === "home" ? 1 : -1;
        const isUserSide =
          (sp.team === "home" && homeClub.isUser) ||
          (sp.team === "away" && awayClub.isUser);
        const mentality = isUserSide
          ? stateRef.current.userMentality
          : sp.team === "home"
          ? homeClub.mentality
          : awayClub.mentality;

        const mentalityShift =
          mentality === "attacking" ? 0.16 : mentality === "defensive" ? -0.14 : 0;

        let targetX = sp.x;
        let targetZ = sp.z;

        if (sp.isGK) {
          // Goalkeeper positioning & Shot-Stopping Dive
          const goalLineX = -sideSign * (PITCH_HALF_W - 1.4);
          targetX = goalLineX;
          targetZ = THREE.MathUtils.clamp(ball.z * 0.38, -GOAL_HALF_WIDTH + 0.8, GOAL_HALF_WIDTH - 0.8);

          // Check incoming fast shot toward this GK's goal
          const distToBall = Math.hypot(ball.x - sp.x, ball.z - sp.z);
          const ballMovingToGoal =
            (sp.team === "home" && ball.vx < -10) ||
            (sp.team === "away" && ball.vx > 10);

          if (!ball.owner && ballMovingToGoal && distToBall < 7.5 && ball.cooldown <= 0.25) {
            const saveChance = 0.36 + (sp.gkStat / 100) * 0.42;
            sp.diveTimer = 0.55;
            sp.diveDir = Math.sign(ball.z - sp.z) || 1;
            if (Math.random() < saveChance && distToBall < 4.4) {
              // GK Save / Parry!
              ball.vx = -ball.vx * 0.45 + sideSign * 8;
              ball.vz = (Math.random() - 0.5) * 14;
              ball.vy = 3.2;
              ball.cooldown = 0.4;
              playSound("kick");
              pushCommentary(
                `🧤 WHAT A SAVE! Goalkeeper ${sp.name} dives full-stretch to deny the goal!`
              );
            }
          }
        } else if (ball.owner === sp) {
          // Ball Carrier dribbles toward opponent goal while avoiding edge
          const attackGoalX = sideSign * PITCH_HALF_W;
          targetX = attackGoalX;
          targetZ = sp.z * 0.75 + Math.sin(stateRef.current.minute * 3 + sp.slotIndex) * 5;
        } else if (
          sp === closestHome ||
          sp === closestAway ||
          (!ball.owner && Math.hypot(sp.x - ball.x, sp.z - ball.z) < 9)
        ) {
          // Chase the ball / Press the ball carrier
          targetX = ball.x;
          targetZ = ball.z;
        } else {
          // Tactical Formation Positioning (shifts forward/back with ball & mentality)
          const dynamicShift = (ballNormX * 0.36 + mentalityShift * sideSign) * PITCH_HALF_W;
          const anchorX = sp.baseNormX * PITCH_HALF_W * sideSign + dynamicShift;
          const anchorZ = sp.baseNormZ * PITCH_HALF_H * sideSign + ball.z * 0.22;
          targetX = THREE.MathUtils.clamp(anchorX, -PITCH_HALF_W + 4, PITCH_HALF_W - 4);
          targetZ = THREE.MathUtils.clamp(anchorZ, -PITCH_HALF_H + 3, PITCH_HALF_H - 3);
        }

        const dx = targetX - sp.x;
        const dz = targetZ - sp.z;
        const dist = Math.hypot(dx, dz);

        const pressBonus =
          isUserSide && stateRef.current.pressBoost > 0 ? 1.22 : 1.0;
        const maxSpeed =
          (5.6 + (sp.speedStat / 100) * 3.8) *
          (ball.owner === sp ? 0.91 : 1.0) *
          pressBonus;

        if (dist > 0.25) {
          sp.vx = (dx / dist) * maxSpeed;
          sp.vz = (dz / dist) * maxSpeed;
          sp.x += sp.vx * dt;
          sp.z += sp.vz * dt;
          sp.facingAngle = Math.atan2(sp.vz, sp.vx);
        } else {
          sp.vx = 0;
          sp.vz = 0;
        }

        // Check Ball Acquisition or Tackle Duel
        const distToBall = Math.hypot(ball.x - sp.x, ball.z - sp.z);
        if (ball.cooldown <= 0 && distToBall < 1.55 && ball.y < 2.1) {
          if (!ball.owner) {
            ball.owner = sp;
            ball.cooldown = 0.22;
          } else if (ball.owner.team !== sp.team) {
            // Tackle duel between sp (defender) and ball.owner (attacker)
            const winProb =
              0.45 + (sp.defendStat - ball.owner.speedStat) * 0.006;
            sp.tackleTimer = 0.35;
            if (Math.random() < winProb) {
              const dispossessed = ball.owner.name;
              ball.owner = sp;
              ball.cooldown = 0.38;
              playSound("kick");
              if (sp.team === "home") stateRef.current.homeTackles += 1;
              else stateRef.current.awayTackles += 1;
              setTacklesCount([
                stateRef.current.homeTackles,
                stateRef.current.awayTackles,
              ]);
              if (Math.random() < 0.4) {
                pushCommentary(
                  `🛡️ Crunch tackle by ${sp.name} to dispossess ${dispossessed}!`
                );
              }
            } else {
              ball.cooldown = 0.25;
            }
          }
        }

        // Update 3D Roblox-Inspired Articulated Character Transforms
        sp.meshGroup.position.set(sp.x, 0, sp.z);
        sp.meshGroup.rotation.y = -sp.facingAngle + Math.PI / 2;

        const speedMag = Math.hypot(sp.vx, sp.vz);
        if (sp.diveTimer > 0) {
          sp.diveTimer -= dt;
          sp.meshGroup.rotation.z = sp.diveDir * 1.15;
          sp.leftArm.rotation.x = Math.PI * 0.85;
          sp.rightArm.rotation.x = Math.PI * 0.85;
        } else {
          sp.meshGroup.rotation.z = 0;
          if (sp.kickTimer > 0) {
            sp.kickTimer -= dt;
            sp.rightLeg.rotation.x = -1.1;
            sp.leftLeg.rotation.x = 0.35;
          } else if (sp.tackleTimer > 0) {
            sp.tackleTimer -= dt;
            sp.rightLeg.rotation.x = -0.9;
            sp.meshGroup.position.y = -0.18;
          } else if (speedMag > 0.6) {
            sp.animPhase += dt * speedMag * 2.1;
            const swing = Math.sin(sp.animPhase) * 0.72;
            sp.leftLeg.rotation.x = swing;
            sp.rightLeg.rotation.x = -swing;
            sp.leftArm.rotation.x = -swing * 0.65;
            sp.rightArm.rotation.x = swing * 0.65;
            sp.meshGroup.position.y = Math.abs(Math.cos(sp.animPhase)) * 0.14;
          } else {
            sp.leftLeg.rotation.x = 0;
            sp.rightLeg.rotation.x = 0;
            sp.leftArm.rotation.x = 0;
            sp.rightArm.rotation.x = 0;
            sp.meshGroup.position.y = 0;
          }
        }

        // Highlight ring under ball carrier
        const ringMat = sp.ringMesh.material as THREE.MeshBasicMaterial;
        if (ball.owner === sp) {
          sp.ringMesh.scale.set(1.35, 1.35, 1.35);
          ringMat.opacity = 0.95;
        } else {
          sp.ringMesh.scale.set(1, 1, 1);
          ringMat.opacity = 0.38;
        }
      });

      // Update Referee position (tracks play from a respectful distance)
      const refTargetX = THREE.MathUtils.clamp(ball.x * 0.65, -32, 32);
      const refTargetZ = THREE.MathUtils.clamp(ball.z - 8, -22, 22);
      refRig.group.position.x += (refTargetX - refRig.group.position.x) * dt * 2.5;
      refRig.group.position.z += (refTargetZ - refRig.group.position.z) * dt * 2.5;
      refRig.group.lookAt(ball.x, 0, ball.z);

      // Update Camera Mode
      const camMode = stateRef.current.cameraMode;
      if (camMode === "broadcast") {
        const targetCamPos = new THREE.Vector3(
          ball.x * 0.55,
          32,
          48 + ball.z * 0.25
        );
        camera.position.lerp(targetCamPos, 0.08);
        camera.lookAt(ball.x * 0.65, 0.8, ball.z * 0.35);
      } else if (camMode === "tactical") {
        const targetCamPos = new THREE.Vector3(0, 74, 18);
        camera.position.lerp(targetCamPos, 0.08);
        camera.lookAt(0, 0, 0);
      } else if (camMode === "closeup") {
        const focusX = ball.x;
        const focusZ = ball.z;
        const targetCamPos = new THREE.Vector3(focusX - 12, 11, focusZ + 14);
        camera.position.lerp(targetCamPos, 0.1);
        camera.lookAt(focusX, 1.2, focusZ);
      } else if (camMode === "orbit") {
        orbitAngle += rawDt * 0.35;
        camera.position.set(
          Math.cos(orbitAngle) * 72,
          38,
          Math.sin(orbitAngle) * 62
        );
        camera.lookAt(0, 2, 0);
      }

      drawRadar();
      renderer.render(scene, camera);
    };

    animFrameId = requestAnimationFrame(animate);

    // Clickable 3D Stadium LED Advertisement Boards (Raycaster)
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const handleCanvasClick = (ev: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects([northAd, southAd, sbMesh]);
      if (intersects.length > 0 && onClickAdRef.current) {
        onClickAdRef.current("3D Stadium LED Board");
        pushCommentary(
          "💰 3D STADIUM ADVERTISEMENT CLICKED! +£9,000,000 instant sponsor payout credited to your club treasury!"
        );
      }
    };
    renderer.domElement.addEventListener("click", handleCanvasClick);

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animFrameId);
      renderer.domElement.removeEventListener("click", handleCanvasClick);
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
    };
  }, [
    homeClub,
    awayClub,
    stadium.capacityLevel,
    stadium.lightingLevel,
    stadium.pitchLevel,
    nightMatch,
    playSound,
    pushCommentary,
    update3DScoreboard,
  ]);

  // Fast-forward / Sim to Full Time handler
  const handleSimToFullTime = () => {
    const remainingMins = Math.max(0, 90 - Math.floor(stateRef.current.minute));
    const intervals = Math.floor(remainingMins / 12);

    let hScore = stateRef.current.homeScore;
    let aScore = stateRef.current.awayScore;
    const newGoals = [...stateRef.current.goals];

    for (let i = 0; i < intervals; i++) {
      const simMin = Math.min(89, Math.floor(stateRef.current.minute) + (i + 1) * 11);
      const r = Math.random();
      if (r < 0.22) {
        hScore += 1;
        stateRef.current.homeShots += 2;
        stateRef.current.homeOnTarget += 1;
        const scorer =
          homeClub.squad.find((p) => p.position === "ST" || p.position === "LW") ||
          homeClub.squad[0];
        newGoals.push({
          minute: simMin,
          team: "home",
          scorerId: scorer.id,
          scorerName: scorer.name,
        });
      } else if (r > 0.79) {
        aScore += 1;
        stateRef.current.awayShots += 2;
        stateRef.current.awayOnTarget += 1;
        const scorer =
          awayClub.squad.find((p) => p.position === "ST" || p.position === "RW") ||
          awayClub.squad[0];
        newGoals.push({
          minute: simMin,
          team: "away",
          scorerId: scorer.id,
          scorerName: scorer.name,
        });
      }
    }

    stateRef.current.homeScore = hScore;
    stateRef.current.awayScore = aScore;
    stateRef.current.goals = newGoals;
    stateRef.current.minute = 90;
    stateRef.current.isFullTime = true;

    setHomeScore(hScore);
    setAwayScore(aScore);
    setGoalsList(newGoals);
    setMinute(90);
    setIsFullTime(true);
    playSound("whistle");
  };

  const handleFinishAndContinue = () => {
    const mvp =
      goalsList.length > 0
        ? goalsList[0].scorerName
        : homeClub.squad[0]?.name || "Star Midfielder";

    onMatchComplete({
      homeScore: stateRef.current.homeScore,
      awayScore: stateRef.current.awayScore,
      homePossession: possessionPct[0],
      awayPossession: possessionPct[1],
      homeShots: Math.max(stateRef.current.homeShots, stateRef.current.homeScore + 3),
      awayShots: Math.max(stateRef.current.awayShots, stateRef.current.awayScore + 2),
      homeOnTarget: Math.max(stateRef.current.homeOnTarget, stateRef.current.homeScore + 1),
      awayOnTarget: Math.max(stateRef.current.awayOnTarget, stateRef.current.awayScore + 1),
      homePasses: Math.max(stateRef.current.homePasses, 42),
      awayPasses: Math.max(stateRef.current.awayPasses, 38),
      homeTackles: Math.max(stateRef.current.homeTackles, 9),
      awayTackles: Math.max(stateRef.current.awayTackles, 8),
      goals: stateRef.current.goals,
      mvpName: mvp,
    });
  };

  const userSquad = homeClub.isUser ? homeClub.squad : awayClub.squad;
  const benchPlayers = userSquad.filter((p) => !p.isStarter);

  return (
    <div className="relative w-full h-[calc(100vh-76px)] min-h-[620px] bg-[#060913] overflow-hidden select-none flex flex-col">
      {/* 3D WebGL Canvas Viewport */}
      <div ref={mountRef} className="w-full h-full flex-1" />

      {/* TOP BROADCAST SCOREBUG HUD */}
      <div className="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none z-20">
        <div className="pointer-events-auto flex items-center bg-[#090D16]/90 backdrop-blur-md border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden">
          {/* Competition Badge */}
          <div className="px-3 py-2 bg-emerald-600/20 border-r border-slate-800 flex flex-col justify-center">
            <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
              {competitionLabel}
            </span>
            <span className="text-[11px] text-slate-300 font-medium truncate max-w-[140px]">
              {stadiumName}
            </span>
          </div>

          {/* Home Team */}
          <div className="flex items-center gap-2.5 px-4 py-2">
            <div
              className="w-3 h-7 rounded-sm"
              style={{ backgroundColor: homeClub.kit.primaryColor }}
            />
            {homeClub.badge && <ClubBadge badge={homeClub.badge} size={28} />}
            <div className="text-right">
              <div className="text-sm font-extrabold tracking-wide text-white uppercase">
                {homeClub.shortName}
              </div>
              <div className="text-[10px] text-slate-400 hidden sm:block">
                {homeClub.name}
              </div>
            </div>
          </div>

          {/* Live Score Pill */}
          <div className="px-4 py-1.5 bg-slate-900 border-x border-slate-800 flex items-center gap-3">
            <span className="text-2xl font-black font-mono text-white">
              {homeScore}
            </span>
            <span className="text-xs font-bold text-emerald-400 uppercase px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 font-mono">
              {minute}&apos;
            </span>
            <span className="text-2xl font-black font-mono text-white">
              {awayScore}
            </span>
          </div>

          {/* Away Team */}
          <div className="flex items-center gap-2.5 px-4 py-2">
            <div className="text-left">
              <div className="text-sm font-extrabold tracking-wide text-white uppercase">
                {awayClub.shortName}
              </div>
              <div className="text-[10px] text-slate-400 hidden sm:block">
                {awayClub.name}
              </div>
            </div>
            {awayClub.badge && <ClubBadge badge={awayClub.badge} size={28} />}
            <div
              className="w-3 h-7 rounded-sm"
              style={{ backgroundColor: awayClub.kit.primaryColor }}
            />
          </div>
        </div>

        {/* Camera & Speed Controls Pill */}
        <div className="pointer-events-auto flex items-center gap-2 bg-[#090D16]/90 backdrop-blur-md border border-slate-700/80 rounded-xl px-3 py-2 shadow-2xl">
          <div className="flex items-center gap-1 border-r border-slate-800 pr-2">
            <Camera className="w-4 h-4 text-emerald-400 mr-1" />
            {(["broadcast", "tactical", "closeup", "orbit"] as CameraMode[]).map(
              (mode) => (
                <button
                  key={mode}
                  onClick={() => setCameraMode(mode)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase transition ${
                    cameraMode === mode
                      ? "bg-emerald-500 text-slate-950 shadow"
                      : "text-slate-300 hover:bg-slate-800"
                  }`}
                >
                  {mode}
                </button>
              )
            )}
          </div>

          {/* Speed & Pause */}
          <button
            onClick={() => setIsPaused((p) => !p)}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition"
            title={isPaused ? "Resume Match" : "Pause Match"}
          >
            {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4" />}
          </button>

          {([1, 2, 4] as const).map((spd) => (
            <button
              key={spd}
              onClick={() => {
                setSimSpeed(spd);
                setIsPaused(false);
              }}
              className={`px-2 py-1 rounded-lg text-xs font-mono font-bold transition ${
                simSpeed === spd && !isPaused
                  ? "bg-amber-500 text-slate-950"
                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              }`}
            >
              {spd}x
            </button>
          ))}

          <button
            onClick={handleSimToFullTime}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-600/80 hover:bg-indigo-500 text-white text-xs font-bold uppercase transition"
            title="Simulate Remaining Minutes"
          >
            <FastForward className="w-3.5 h-3.5" />
            Sim End
          </button>

          <button
            onClick={() => setSoundEnabled((s) => !s)}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {onCancelQuickMatch && (
            <button
              onClick={onCancelQuickMatch}
              className="px-2.5 py-1 rounded-lg bg-rose-600/30 border border-rose-500/40 text-rose-300 hover:bg-rose-600/50 text-xs font-bold uppercase"
            >
              Exit
            </button>
          )}
        </div>

        {/* Clickable Live Broadcast Advertisement Banner (+£9,000,000 per click) */}
        {onClickAdvertisement && (
          <button
            type="button"
            onClick={() => {
              onClickAdvertisement("VORTEX ENERGY Broadcast Ad");
              pushCommentary(
                "💰 BROADCAST ADVERTISEMENT CLICKED! +£9,000,000 credited to your club balance!"
              );
            }}
            className="pointer-events-auto flex items-center gap-2.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-emerald-500 to-teal-500 hover:from-amber-400 hover:to-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-2xl border-2 border-white/40 transition transform hover:scale-105 active:scale-95"
            title="Click Advertisement to Earn £9,000,000 Instantly"
          >
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>📺 SPONSOR AD: CLICK HERE OR 3D LED BOARDS FOR +£9,000,000!</span>
          </button>
        )}
      </div>

      {/* GOAL CELEBRATION BANNER OVERLAY */}
      {goalBanner && (
        <div className="absolute inset-x-0 top-24 flex justify-center pointer-events-none z-30 animate-bounce">
          <div
            className="px-8 py-4 rounded-2xl border-2 shadow-2xl backdrop-blur-md text-center"
            style={{
              backgroundColor: "rgba(9, 13, 22, 0.92)",
              borderColor: goalBanner.color,
            }}
          >
            <div className="flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest text-amber-400">
              <Sparkles className="w-4 h-4" /> GOAL SCORED FOR {goalBanner.teamName}! <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-3xl sm:text-4xl font-black uppercase tracking-tight text-white mt-1">
              ⚽ {goalBanner.scorerName} ({goalBanner.minute}&apos;)
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM TACTICAL COMMAND BAR, LIVE COMMENTARY & 2D RADAR */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-col lg:flex-row items-stretch lg:items-end justify-between gap-3 pointer-events-none z-20">
        {/* Left: Live Play-by-Play Commentary & Ball Carrier */}
        <div className="pointer-events-auto flex-1 max-w-md bg-[#090D16]/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                Live Commentary
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-300">
              On Ball: <strong className="text-white">{ballCarrierName}</strong>
            </span>
          </div>
          <div className="space-y-1 max-h-20 overflow-y-auto pr-1 text-xs">
            {commentary.slice(0, 3).map((line, i) => (
              <div
                key={i}
                className={
                  i === 0 ? "text-white font-semibold" : "text-slate-400"
                }
              >
                {line}
              </div>
            ))}
          </div>
        </div>

        {/* Center: 2D Pitch Radar Minimap */}
        <div className="pointer-events-auto hidden sm:flex flex-col items-center bg-[#090D16]/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-2 shadow-2xl">
          <canvas
            ref={radarCanvasRef}
            width={210}
            height={128}
            className="rounded-lg border border-slate-700"
          />
          <div className="flex items-center justify-between w-full px-1 mt-1 text-[10px] font-mono text-slate-400">
            <span>Poss: {possessionPct[0]}% - {possessionPct[1]}%</span>
            <span>Shots: {shotsCount[0]} - {shotsCount[1]}</span>
          </div>
        </div>

        {/* Right: Touchline Manager Shouts, Direct Commands & Substitutions */}
        <div className="pointer-events-auto flex flex-col gap-2 bg-[#090D16]/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 shadow-2xl">
          <div className="flex items-center justify-between gap-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Touchline Tactics & Shouts
            </span>
            <button
              onClick={() => setShowSubDrawer((s) => !s)}
              className="flex items-center gap-1 text-xs font-bold text-emerald-400 hover:text-emerald-300"
            >
              <Users className="w-3.5 h-3.5" />
              Bench ({3 - subsUsed} Subs left)
            </button>
          </div>

          {/* Mentality Row */}
          <div className="grid grid-cols-3 gap-1.5">
            {(
              [
                { id: "defensive", label: "Park Bus", icon: Shield },
                { id: "balanced", label: "Balanced", icon: RefreshCw },
                { id: "attacking", label: "All Out", icon: Swords },
              ] as const
            ).map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setUserMentality(item.id);
                    pushCommentary(
                      `📋 Manager signals from the touchline: Switch to ${item.label.toUpperCase()} mentality!`
                    );
                  }}
                  className={`flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                    userMentality === item.id
                      ? "bg-emerald-500 text-slate-950 shadow"
                      : "bg-slate-800/90 text-slate-300 hover:bg-slate-700"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {item.label}
                </button>
              );
            })}
          </div>

          {/* Instant Action Commands */}
          <div className="grid grid-cols-3 gap-1.5">
            <button
              onClick={() => {
                stateRef.current.forceCommand = "shoot";
                pushCommentary("📣 Touchline Shout: 'SHOOT ON SIGHT!'");
              }}
              className="flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 hover:bg-amber-500/30 text-amber-300 text-xs font-bold uppercase transition"
            >
              <Target className="w-3.5 h-3.5" />
              Shoot!
            </button>
            <button
              onClick={() => {
                stateRef.current.forceCommand = "pass";
                pushCommentary("📣 Touchline Shout: 'WORK THE BALL FORWARD!'");
              }}
              className="flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg bg-sky-500/20 border border-sky-500/40 hover:bg-sky-500/30 text-sky-300 text-xs font-bold uppercase transition"
            >
              <Zap className="w-3.5 h-3.5" />
              Pass!
            </button>
            <button
              onClick={() => {
                stateRef.current.pressBoost = 12;
                setPressBoostTimer(12);
                pushCommentary("🔥 Touchline Shout: 'GEGENPRESS! HUNT IN PACKS!'");
              }}
              disabled={pressBoostTimer > 0}
              className={`flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                pressBoostTimer > 0
                  ? "bg-emerald-500 text-slate-950"
                  : "bg-emerald-500/20 border border-emerald-500/40 hover:bg-emerald-500/30 text-emerald-300"
              }`}
            >
              {pressBoostTimer > 0 ? `Press (${pressBoostTimer}s)` : "High Press"}
            </button>
          </div>
        </div>
      </div>

      {/* LIVE SUBSTITUTION POPOVER DRAWER */}
      {showSubDrawer && (
        <div className="absolute bottom-36 right-4 w-80 bg-[#090D16]/95 backdrop-blur-xl border border-slate-700 rounded-2xl p-4 shadow-2xl z-30">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Quick Tactical Substitution ({3 - subsUsed} remaining)
            </h4>
            <button
              onClick={() => setShowSubDrawer(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Close
            </button>
          </div>
          {subsUsed >= 3 ? (
            <p className="text-xs text-slate-400">
              All 3 substitutions have been used in this match.
            </p>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {benchPlayers.map((sub) => (
                <div
                  key={sub.id}
                  className="flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-lg px-3 py-2"
                >
                  <div>
                    <div className="text-xs font-bold text-white">
                      {sub.name}{" "}
                      <span className="text-emerald-400 font-mono">
                        {sub.overall} OVR
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {sub.position} • Fitness {sub.fitness}%
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setSubsUsed((c) => c + 1);
                      stateRef.current.pressBoost = 10;
                      pushCommentary(
                        `🔄 SUBSTITUTION: Fresh legs as ${sub.name} (${sub.position}, ${sub.overall} OVR) enters the pitch!`
                      );
                      setShowSubDrawer(false);
                    }}
                    className="px-2.5 py-1 rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold"
                  >
                    Sub On
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* FULL TIME SUMMARY MODAL */}
      {isFullTime && (
        <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 z-40">
          <div className="w-full max-w-xl bg-[#0F1623] border border-slate-700 rounded-2xl shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-900/60 via-slate-900 to-emerald-900/60 px-6 py-5 border-b border-slate-800 text-center">
              <div className="text-xs font-bold uppercase tracking-widest text-emerald-400">
                Full-Time Official Match Report • {competitionLabel}
              </div>
              <div className="flex items-center justify-center gap-6 mt-3">
                <div className="text-right flex-1">
                  <div className="text-lg font-extrabold text-white">
                    {homeClub.name}
                  </div>
                  <div className="text-xs text-slate-400">Home</div>
                </div>
                <div className="px-5 py-2 rounded-xl bg-slate-950 border border-slate-700 font-mono text-3xl font-black text-white">
                  {homeScore} - {awayScore}
                </div>
                <div className="text-left flex-1">
                  <div className="text-lg font-extrabold text-white">
                    {awayClub.name}
                  </div>
                  <div className="text-xs text-slate-400">Away</div>
                </div>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {/* Goalscorers list */}
              {goalsList.length > 0 && (
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Match Goalscorers
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      {goalsList
                        .filter((g) => g.team === "home")
                        .map((g, idx) => (
                          <div key={idx} className="text-emerald-300 font-semibold">
                            ⚽ {g.scorerName} ({g.minute}&apos;)
                          </div>
                        ))}
                    </div>
                    <div className="text-right">
                      {goalsList
                        .filter((g) => g.team === "away")
                        .map((g, idx) => (
                          <div key={idx} className="text-amber-300 font-semibold">
                            ⚽ {g.scorerName} ({g.minute}&apos;)
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Match Stat Bars */}
              <div className="space-y-2.5 text-xs">
                {[
                  {
                    label: "Possession %",
                    h: possessionPct[0],
                    a: possessionPct[1],
                    suffix: "%",
                  },
                  {
                    label: "Total Shots",
                    h: Math.max(stateRef.current.homeShots, homeScore + 3),
                    a: Math.max(stateRef.current.awayShots, awayScore + 2),
                    suffix: "",
                  },
                  {
                    label: "Shots on Target",
                    h: Math.max(stateRef.current.homeOnTarget, homeScore + 1),
                    a: Math.max(stateRef.current.awayOnTarget, awayScore + 1),
                    suffix: "",
                  },
                  {
                    label: "Completed Passes",
                    h: Math.max(stateRef.current.homePasses, 44),
                    a: Math.max(stateRef.current.awayPasses, 39),
                    suffix: "",
                  },
                  {
                    label: "Tackles Won",
                    h: Math.max(stateRef.current.homeTackles, 8),
                    a: Math.max(stateRef.current.awayTackles, 7),
                    suffix: "",
                  },
                ].map((row, idx) => {
                  const total = row.h + row.a || 1;
                  const hWidth = Math.round((row.h / total) * 100);
                  return (
                    <div key={idx}>
                      <div className="flex justify-between font-mono text-slate-300 mb-1">
                        <span>
                          {row.h}
                          {row.suffix}
                        </span>
                        <span className="font-sans text-slate-400 uppercase text-[11px] font-bold">
                          {row.label}
                        </span>
                        <span>
                          {row.a}
                          {row.suffix}
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden flex">
                        <div
                          className="h-full bg-emerald-500"
                          style={{ width: `${hWidth}%` }}
                        />
                        <div
                          className="h-full bg-amber-500"
                          style={{ width: `${100 - hWidth}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <button
                onClick={handleFinishAndContinue}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black uppercase tracking-wider text-sm shadow-lg flex items-center justify-center gap-2 transition"
              >
                <Award className="w-5 h-5" />
                Confirm Match Result & Update League Table
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
