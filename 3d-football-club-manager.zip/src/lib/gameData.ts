export type Position =
  | "GK"
  | "CB"
  | "LB"
  | "RB"
  | "CDM"
  | "CM"
  | "CAM"
  | "LW"
  | "RW"
  | "ST";

export type FormationName = "4-3-3" | "4-4-2" | "4-2-3-1" | "3-5-2" | "5-3-2";

export type Mentality = "defensive" | "balanced" | "attacking";

export type BadgeShape = "classic" | "hexagon" | "royal" | "diamond" | "circle";
export type BadgePattern = "stripes" | "sash" | "quartered" | "solid" | "chevron";
export type BadgeIcon =
  | "lion"
  | "eagle"
  | "crown"
  | "star"
  | "ball"
  | "lightning"
  | "anchor"
  | "flame";

export type KitPattern = "solid" | "stripes" | "hoops" | "sash" | "halves";

export interface BadgeConfig {
  shape: BadgeShape;
  pattern: BadgePattern;
  icon: BadgeIcon;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
}

export interface KitConfig {
  pattern: KitPattern;
  primaryColor: string;
  secondaryColor: string;
  shortsColor: string;
  socksColor: string;
}

export interface ClubIdentity {
  name: string;
  shortName: string;
  stadiumName: string;
  country: string;
  startingDivisionId: number; // 5 = Div 5 ... 0 = Premier Division
  managerName: string;
  badge: BadgeConfig;
  homeKit: KitConfig;
  awayKit: KitConfig;
}

export interface PlayerAttributes {
  shooting: number;
  passing: number;
  defending: number;
  speed: number;
  stamina: number;
  goalkeeping: number;
}

export interface Player {
  id: string;
  name: string;
  age: number;
  nationality: string;
  flag: string;
  position: Position;
  overall: number;
  potential: number;
  attributes: PlayerAttributes;
  marketValue: number;
  weeklySalary: number;
  contractYears: number;
  fitness: number; // 0-100
  morale: number; // 0-100
  injuryWeeks: number; // 0 = healthy
  injuryType?: string;
  isStarter: boolean;
  starterSlot: number | null; // 0..10
  kitNumber: number;
  goals: number;
  assists: number;
  appearances: number;
  xp: number; // 0-100 toward next OVR point
  skinTone: string;
  hairColor: string;
  clubId: string;
  clubName: string;
  aiClubStrategy?: string;
  transferListed?: boolean;
}

export interface AIClub {
  id: string;
  name: string;
  shortName: string;
  divisionId: number;
  overallRating: number;
  budget: number;
  strategy: "Youth Developers" | "Galactico Buyers" | "Bargain Hunters" | "Tactical Grinders" | "Balanced";
  primaryColor: string;
  secondaryColor: string;
  stadiumName: string;
  capacity: number;
  badgeShape: BadgeShape;
  badgeIcon: BadgeIcon;
}

export interface LeagueStanding {
  clubId: string;
  clubName: string;
  shortName: string;
  isUser: boolean;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  points: number;
  form: ("W" | "D" | "L")[];
  primaryColor: string;
  secondaryColor: string;
  overallRating: number;
}

export interface Fixture {
  id: string;
  week: number;
  divisionId: number;
  homeClubId: string;
  homeClubName: string;
  homeShort: string;
  homePrimary: string;
  homeSecondary: string;
  homeOvr: number;
  awayClubId: string;
  awayClubName: string;
  awayShort: string;
  awayPrimary: string;
  awaySecondary: string;
  awayOvr: number;
  played: boolean;
  homeScore?: number;
  awayScore?: number;
  isUserMatch: boolean;
}

export interface IncomingTransferOffer {
  id: string;
  playerId: string;
  playerName: string;
  playerPosition: Position;
  playerOvr: number;
  buyingClubName: string;
  buyingClubStrategy: string;
  offeredFee: number;
  marketValue: number;
  week: number;
  status: "pending" | "accepted" | "rejected";
}

export interface NewsItem {
  id: string;
  week: number;
  season: number;
  title: string;
  body: string;
  category: "match" | "transfer" | "training" | "finance" | "league" | "injury";
  timestamp: string;
}

export interface SeasonObjective {
  id: string;
  title: string;
  description: string;
  targetText: string;
  reward: number;
  progress: number; // 0-100
  completed: boolean;
}

export interface StadiumState {
  capacityLevel: number; // 1..5
  pitchLevel: number; // 1..5
  lightingLevel: number; // 1..5
  commercialLevel: number; // 1..5
  ticketPrice: number; // £15..£85
}

export interface SponsorOption {
  id: string;
  brandName: string;
  sector: string;
  slogan: string;
  weeklyBase: number;
  winBonus: number;
  signingBonus: number;
  minDivisionId: number; // 5 = available in Div 5, 3 = needs Div 3+, etc.
  accentColor: string;
}

export interface FinancialRecord {
  id: string;
  week: number;
  season: number;
  description: string;
  amount: number; // positive = income, negative = expense
  category: "gate" | "wages" | "transfer" | "sponsor" | "stadium" | "prize" | "loan";
}

export type TrainingCategory =
  | "shooting"
  | "passing"
  | "defending"
  | "speed"
  | "fitness"
  | "goalkeeping";

export interface CareerState {
  initialized: boolean;
  club: ClubIdentity;
  season: number;
  week: number;
  maxWeeksPerSeason: number;
  currentDivisionId: number; // 5 down to 0
  balance: number;
  clubDebt: number;
  formation: FormationName;
  mentality: Mentality;
  squad: Player[];
  transferMarket: Player[];
  incomingOffers: IncomingTransferOffer[];
  divisions: Record<number, LeagueStanding[]>; // 0..5 -> 20 teams each
  fixtures: Fixture[]; // User division fixtures for current season
  stadium: StadiumState;
  activeSponsorId: string;
  finances: FinancialRecord[];
  news: NewsItem[];
  objectives: SeasonObjective[];
  trainingFocus: TrainingCategory;
  trainingIntensity: "light" | "balanced" | "intense";
  trainedThisWeek: boolean;
  trophies: { season: number; title: string; divisionName: string }[];
}

export interface DivisionMeta {
  id: number;
  name: string;
  tierLabel: string;
  avgOvr: number;
  championPrize: number;
  promotionPrize: number;
  tvRevenuePerMatch: number;
  baseAttendanceFactor: number;
}

export const DIVISIONS_META: DivisionMeta[] = [
  {
    id: 5,
    name: "Division 5",
    tierLabel: "Tier 6 • National Grassroots",
    avgOvr: 59,
    championPrize: 750000,
    promotionPrize: 400000,
    tvRevenuePerMatch: 12000,
    baseAttendanceFactor: 0.62,
  },
  {
    id: 4,
    name: "Division 4",
    tierLabel: "Tier 5 • Regional Pro League",
    avgOvr: 65,
    championPrize: 1500000,
    promotionPrize: 800000,
    tvRevenuePerMatch: 28000,
    baseAttendanceFactor: 0.7,
  },
  {
    id: 3,
    name: "Division 3",
    tierLabel: "Tier 4 • National League One",
    avgOvr: 71,
    championPrize: 3200000,
    promotionPrize: 1600000,
    tvRevenuePerMatch: 55000,
    baseAttendanceFactor: 0.76,
  },
  {
    id: 2,
    name: "Division 2",
    tierLabel: "Tier 3 • Championship Tier",
    avgOvr: 76,
    championPrize: 6500000,
    promotionPrize: 3200000,
    tvRevenuePerMatch: 110000,
    baseAttendanceFactor: 0.83,
  },
  {
    id: 1,
    name: "Division 1",
    tierLabel: "Tier 2 • First Division Challenger",
    avgOvr: 81,
    championPrize: 14000000,
    promotionPrize: 7500000,
    tvRevenuePerMatch: 220000,
    baseAttendanceFactor: 0.9,
  },
  {
    id: 0,
    name: "Premier Division",
    tierLabel: "Tier 1 • World Elite Top Flight",
    avgOvr: 87,
    championPrize: 35000000,
    promotionPrize: 15000000,
    tvRevenuePerMatch: 480000,
    baseAttendanceFactor: 0.97,
  },
];

export function getDivisionMeta(divisionId: number): DivisionMeta {
  return DIVISIONS_META.find((d) => d.id === divisionId) || DIVISIONS_META[0];
}

export const STADIUM_CAPACITY_TIERS = [
  { level: 1, name: "Community Ground", capacity: 5000, cost: 0, maintenance: 4500 },
  { level: 2, name: "Borough Arena", capacity: 12000, cost: 450000, maintenance: 11000 },
  { level: 3, name: "Metropolitan Stadium", capacity: 25000, cost: 1350000, maintenance: 24000 },
  { level: 4, name: "Continental Bowl", capacity: 42000, cost: 3400000, maintenance: 48000 },
  { level: 5, name: "Colossus World Cathedral", capacity: 65000, cost: 7800000, maintenance: 85000 },
];

export const SPONSOR_OPTIONS: SponsorOption[] = [
  {
    id: "sp_vortex",
    brandName: "VORTEX ENERGY",
    sector: "Sports Beverage",
    slogan: "Unleash Raw Velocity",
    weeklyBase: 32000,
    winBonus: 18000,
    signingBonus: 150000,
    minDivisionId: 5,
    accentColor: "#10B981",
  },
  {
    id: "sp_apex",
    brandName: "APEX BOOTS",
    sector: "Athletic Footwear",
    slogan: "Precision Every Touch",
    weeklyBase: 26000,
    winBonus: 30000,
    signingBonus: 120000,
    minDivisionId: 5,
    accentColor: "#F59E0B",
  },
  {
    id: "sp_kinetic",
    brandName: "KINETIC TELECOM",
    sector: "5G Fibre Network",
    slogan: "Connected at Match Speed",
    weeklyBase: 58000,
    winBonus: 35000,
    signingBonus: 320000,
    minDivisionId: 4,
    accentColor: "#3B82F6",
  },
  {
    id: "sp_turbo",
    brandName: "TURBO AIRWAYS",
    sector: "Global Aviation",
    slogan: "Fly Above the Rest",
    weeklyBase: 115000,
    winBonus: 65000,
    signingBonus: 750000,
    minDivisionId: 3,
    accentColor: "#EC4899",
  },
  {
    id: "sp_hyperion",
    brandName: "HYPERION BANK",
    sector: "Private Wealth & FinTech",
    slogan: "Capital of Champions",
    weeklyBase: 240000,
    winBonus: 125000,
    signingBonus: 1800000,
    minDivisionId: 1,
    accentColor: "#8B5CF6",
  },
];

export interface FormationSlot {
  slotIndex: number;
  role: Position;
  label: string;
  // Normalized pitch coordinates: x from -1 (own goal line) to 0 (halfway), y from -1 (left wing) to +1 (right wing)
  normX: number;
  normZ: number;
  // 2D UI display coordinates in % (0..100)
  uiX: number;
  uiY: number;
}

export const FORMATIONS: Record<FormationName, FormationSlot[]> = {
  "4-3-3": [
    { slotIndex: 0, role: "GK", label: "GK", normX: -0.9, normZ: 0, uiX: 50, uiY: 88 },
    { slotIndex: 1, role: "LB", label: "LB", normX: -0.64, normZ: -0.68, uiX: 16, uiY: 70 },
    { slotIndex: 2, role: "CB", label: "LCB", normX: -0.68, normZ: -0.24, uiX: 38, uiY: 73 },
    { slotIndex: 3, role: "CB", label: "RCB", normX: -0.68, normZ: 0.24, uiX: 62, uiY: 73 },
    { slotIndex: 4, role: "RB", label: "RB", normX: -0.64, normZ: 0.68, uiX: 84, uiY: 70 },
    { slotIndex: 5, role: "CDM", label: "CDM", normX: -0.45, normZ: 0, uiX: 50, uiY: 54 },
    { slotIndex: 6, role: "CM", label: "LCM", normX: -0.32, normZ: -0.36, uiX: 30, uiY: 44 },
    { slotIndex: 7, role: "CAM", label: "RCM", normX: -0.28, normZ: 0.36, uiX: 70, uiY: 42 },
    { slotIndex: 8, role: "LW", label: "LW", normX: -0.12, normZ: -0.66, uiX: 18, uiY: 22 },
    { slotIndex: 9, role: "ST", label: "ST", normX: -0.08, normZ: 0, uiX: 50, uiY: 16 },
    { slotIndex: 10, role: "RW", label: "RW", normX: -0.12, normZ: 0.66, uiX: 82, uiY: 22 },
  ],
  "4-4-2": [
    { slotIndex: 0, role: "GK", label: "GK", normX: -0.9, normZ: 0, uiX: 50, uiY: 88 },
    { slotIndex: 1, role: "LB", label: "LB", normX: -0.65, normZ: -0.68, uiX: 16, uiY: 70 },
    { slotIndex: 2, role: "CB", label: "LCB", normX: -0.68, normZ: -0.24, uiX: 38, uiY: 73 },
    { slotIndex: 3, role: "CB", label: "RCB", normX: -0.68, normZ: 0.24, uiX: 62, uiY: 73 },
    { slotIndex: 4, role: "RB", label: "RB", normX: -0.65, normZ: 0.68, uiX: 84, uiY: 70 },
    { slotIndex: 5, role: "LW", label: "LM", normX: -0.36, normZ: -0.68, uiX: 16, uiY: 46 },
    { slotIndex: 6, role: "CM", label: "LCM", normX: -0.4, normZ: -0.22, uiX: 38, uiY: 49 },
    { slotIndex: 7, role: "CM", label: "RCM", normX: -0.4, normZ: 0.22, uiX: 62, uiY: 49 },
    { slotIndex: 8, role: "RW", label: "RM", normX: -0.36, normZ: 0.68, uiX: 84, uiY: 46 },
    { slotIndex: 9, role: "ST", label: "LST", normX: -0.1, normZ: -0.24, uiX: 36, uiY: 18 },
    { slotIndex: 10, role: "ST", label: "RST", normX: -0.1, normZ: 0.24, uiX: 64, uiY: 18 },
  ],
  "4-2-3-1": [
    { slotIndex: 0, role: "GK", label: "GK", normX: -0.9, normZ: 0, uiX: 50, uiY: 88 },
    { slotIndex: 1, role: "LB", label: "LB", normX: -0.65, normZ: -0.68, uiX: 16, uiY: 72 },
    { slotIndex: 2, role: "CB", label: "LCB", normX: -0.68, normZ: -0.24, uiX: 38, uiY: 75 },
    { slotIndex: 3, role: "CB", label: "RCB", normX: -0.68, normZ: 0.24, uiX: 62, uiY: 75 },
    { slotIndex: 4, role: "RB", label: "RB", normX: -0.65, normZ: 0.68, uiX: 84, uiY: 72 },
    { slotIndex: 5, role: "CDM", label: "LCDM", normX: -0.46, normZ: -0.24, uiX: 36, uiY: 56 },
    { slotIndex: 6, role: "CDM", label: "RCDM", normX: -0.46, normZ: 0.24, uiX: 64, uiY: 56 },
    { slotIndex: 7, role: "LW", label: "LAM", normX: -0.24, normZ: -0.62, uiX: 20, uiY: 34 },
    { slotIndex: 8, role: "CAM", label: "CAM", normX: -0.24, normZ: 0, uiX: 50, uiY: 36 },
    { slotIndex: 9, role: "RW", label: "RAM", normX: -0.24, normZ: 0.62, uiX: 80, uiY: 34 },
    { slotIndex: 10, role: "ST", label: "ST", normX: -0.08, normZ: 0, uiX: 50, uiY: 15 },
  ],
  "3-5-2": [
    { slotIndex: 0, role: "GK", label: "GK", normX: -0.9, normZ: 0, uiX: 50, uiY: 88 },
    { slotIndex: 1, role: "CB", label: "LCB", normX: -0.68, normZ: -0.44, uiX: 28, uiY: 72 },
    { slotIndex: 2, role: "CB", label: "CCB", normX: -0.71, normZ: 0, uiX: 50, uiY: 74 },
    { slotIndex: 3, role: "CB", label: "RCB", normX: -0.68, normZ: 0.44, uiX: 72, uiY: 72 },
    { slotIndex: 4, role: "CDM", label: "CDM", normX: -0.48, normZ: 0, uiX: 50, uiY: 56 },
    { slotIndex: 5, role: "LW", label: "LWB", normX: -0.36, normZ: -0.72, uiX: 14, uiY: 45 },
    { slotIndex: 6, role: "CM", label: "LCM", normX: -0.34, normZ: -0.26, uiX: 35, uiY: 44 },
    { slotIndex: 7, role: "CAM", label: "RCM", normX: -0.32, normZ: 0.26, uiX: 65, uiY: 44 },
    { slotIndex: 8, role: "RW", label: "RWB", normX: -0.36, normZ: 0.72, uiX: 86, uiY: 45 },
    { slotIndex: 9, role: "ST", label: "LST", normX: -0.1, normZ: -0.24, uiX: 36, uiY: 18 },
    { slotIndex: 10, role: "ST", label: "RST", normX: -0.1, normZ: 0.24, uiX: 64, uiY: 18 },
  ],
  "5-3-2": [
    { slotIndex: 0, role: "GK", label: "GK", normX: -0.9, normZ: 0, uiX: 50, uiY: 88 },
    { slotIndex: 1, role: "LB", label: "LWB", normX: -0.58, normZ: -0.74, uiX: 12, uiY: 66 },
    { slotIndex: 2, role: "CB", label: "LCB", normX: -0.68, normZ: -0.38, uiX: 31, uiY: 73 },
    { slotIndex: 3, role: "CB", label: "CCB", normX: -0.71, normZ: 0, uiX: 50, uiY: 75 },
    { slotIndex: 4, role: "CB", label: "RCB", normX: -0.68, normZ: 0.38, uiX: 69, uiY: 73 },
    { slotIndex: 5, role: "RB", label: "RWB", normX: -0.58, normZ: 0.74, uiX: 88, uiY: 66 },
    { slotIndex: 6, role: "CDM", label: "CDM", normX: -0.45, normZ: 0, uiX: 50, uiY: 53 },
    { slotIndex: 7, role: "CM", label: "LCM", normX: -0.34, normZ: -0.34, uiX: 32, uiY: 42 },
    { slotIndex: 8, role: "CAM", label: "RCM", normX: -0.34, normZ: 0.34, uiX: 68, uiY: 42 },
    { slotIndex: 9, role: "ST", label: "LST", normX: -0.1, normZ: -0.24, uiX: 36, uiY: 18 },
    { slotIndex: 10, role: "ST", label: "RST", normX: -0.1, normZ: 0.24, uiX: 64, uiY: 18 },
  ],
};

const FIRST_NAMES = [
  "Marcus", "Lucas", "Mateo", "Jude", "Kylian", "Erling", "Pedri", "Bukayo",
  "Declan", "Enzo", "Rafael", "Victor", "Florian", "Jamal", "Alejandro", "Gavi",
  "Theo", "William", "Ruben", "Bernardo", "Bruno", "Federico", "Lautaro", "Julian",
  "Ollie", "Cole", "Kobbie", "Leny", "Warren", "Xavi", "Joao", "Goncalo",
  "Nico", "Lamine", "Pau", "Micky", "Destiny", "Tijjani", "Teun", "Joshua",
  "Liam", "Noah", "Ethan", "Callum", "Harvey", "Finley", "Archie", "Toby",
  "Santiago", "Thiago", "Gabriel", "Vinicius", "Rodrygo", "Endrick", "Savio", "Murillo",
  "Kenan", "Arda", "Hakan", "Dominik", "Josko", "Luka", "Martin", "Alexander",
];

const LAST_NAMES = [
  "Vance", "Silva", "Fernandez", "Bellingham", "Moreno", "Halvorsen", "Gonzalez", "Saka",
  "Sterling", "Alvarez", "Leao", "Osimhen", "Wirtz", "Musiala", "Garnacho", "Torres",
  "Hernandez", "Saliba", "Dias", "Guimaraes", "Valverde", "Martinez", "Palmer", "Mainoo",
  "Yoro", "Simons", "Neves", "Ramos", "Williams", "Cubarsi", "Van de Ven", "Reijnders",
  "Zirkzee", "Gallagher", "Branthwaite", "Wharton", "Eze", "Olise", "Gordon", "Isak",
  "Gyokeres", "Kudus", "Mitoma", "Mac Allister", "Szoboszlai", "Gvardiol", "Odegaard", "Costa",
  "Mendes", "Vitinha", "Barcola", "Thuram", "Barella", "Bastoni", "Dimarco", "Kvaratskhelia",
  "Schlotterbeck", "Tah", "Frimpong", "Grimaldo", "Sesko", "Openda", "Bakayoko", "Hato",
];

const NATIONALITIES = [
  { country: "England", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿" },
  { country: "Spain", flag: "🇪🇸" },
  { country: "Germany", flag: "🇩🇪" },
  { country: "France", flag: "🇫🇷" },
  { country: "Brazil", flag: "🇧🇷" },
  { country: "Italy", flag: "🇮🇹" },
  { country: "Netherlands", flag: "🇳🇱" },
  { country: "Portugal", flag: "🇵🇹" },
  { country: "Argentina", flag: "🇦🇷" },
  { country: "Belgium", flag: "🇧🇪" },
  { country: "Norway", flag: "🇳🇴" },
  { country: "Sweden", flag: "🇸🇪" },
  { country: "Croatia", flag: "🇭🇷" },
  { country: "Japan", flag: "🇯🇵" },
  { country: "USA", flag: "🇺🇸" },
  { country: "Nigeria", flag: "🇳🇬" },
];

const SKIN_TONES = ["#F7D7C4", "#E8B89A", "#D1946A", "#A66A43", "#6E4226", "#4B2B17"];
const HAIR_COLORS = ["#1C1917", "#3F271E", "#78350F", "#D97706", "#B45309", "#E5E7EB"];

// 20 fictional club names for each of the 6 divisions (120 clubs total)
export const DIVISION_CLUB_NAMES: Record<number, string[]> = {
  5: [
    "Oakwood Rovers", "Ironbridge Town", "Millbrook United", "Redcliffe Athletic", "Ashford Vale FC",
    "Brampton Albion", "Cinderford City", "Dunmore Wanderers", "Eastgate Rangers", "Fenwick Borough",
    "Greystone County", "Hartwell Thistle", "Kingswood Olympic", "Larkspur Celtic", "Moorland Forest",
    "Northgate Harriers", "Pinehurst Spurs", "Queensbury Argyle", "Ravenscroft Town", "Silverdale United",
  ],
  4: [
    "Alderney Port FC", "Blackwater City", "Clearwater Rovers", "Davenport United", "Elmhurst Athletic",
    "Fairview Town", "Glenhaven Wanderers", "Highbury Vale", "Inverness Albion", "Junction Park FC",
    "Kestrel County", "Lancaster Forge", "Meadowbank Rangers", "Newhaven Mariners", "Oakhaven Victoria",
    "Pendleton City", "Quarryvale United", "Ridgeway Town", "Stonebridge FC", "Thornbury Rovers",
  ],
  3: [
    "Avalon Athletic", "Beacon Hill FC", "Castleton United", "Derwent Valley", "Edgemont City",
    "Falconbridge Rovers", "Granite Harbor", "Hawthorne Forest", "Ironclad FC", "Jade Coast United",
    "Kingsport Mariners", "Lochside Thistle", "Marlborough Town", "Norwood Albion", "Orion Park FC",
    "Portsmouth Emerald", "Queensgate City", "Riverdale Wanderers", "Sunderland Steel", "Trafalgar United",
  ],
  2: [
    "Albion Metro FC", "Brighton Crest", "Camden Royal", "Durham Dynamo", "Exeter Phoenix",
    "Foxborough United", "Gloucester Lions", "Hampshire Crown", "Imperial Wharf FC", "Kensington Sporting",
    "Leeds Vanguard", "Midland Colts", "Newcastle Falcons", "Oxford Monarchs", "Plymouth Armada",
    "Reading Spartans", "Sheffield Titans", "Swansea Dragons", "Warwick Knights", "Yorkshire United",
  ],
  1: [
    "Aston Valkyries", "Birmingham Core", "Bristol Mercury", "Cardiff Griffins", "Coventry Spire",
    "Derby Centurions", "Evergreen City", "Fulham Wharf", "Glasgow Highlanders", "Hull Mariners",
    "Ipswich Stallions", "Leicester Foxes FC", "Middlesbrough Iron", "Norwich Canaries", "Nottingham Arrows",
    "Southampton Waves", "Stoke Potters FC", "Sunderland Red", "West Bromwich Albion", "Wolverhampton Pack",
  ],
  0: [
    "London Arsenal FC", "Manchester Blue", "Liverpool Reds", "Manchester Red", "Chelsea Royal",
    "Tottenham Lilywhites", "Newcastle Magpies", "Madrid Blancos", "Barcelona Blaugrana", "Munich Bavaria",
    "Milan Rossoneri", "Milan Nerazzurri", "Turin Zebras", "Paris Saint-Etoile", "Dortmund Yellow",
    "Leverkusen Works", "Atletico Metropolitano", "Lisbon Eagles", "Amsterdam Ajax", "Napoli Vesuvio",
  ],
};

const CLUB_COLOR_PAIRS: [string, string][] = [
  ["#10B981", "#0F172A"],
  ["#EF4444", "#FFFFFF"],
  ["#3B82F6", "#F8FAFC"],
  ["#F59E0B", "#1E293B"],
  ["#8B5CF6", "#FDE047"],
  ["#EC4899", "#0F172A"],
  ["#06B6D4", "#0F172A"],
  ["#DC2626", "#111827"],
  ["#2563EB", "#FACC15"],
  ["#16A34A", "#FFFFFF"],
  ["#EA580C", "#18181B"],
  ["#7C3AED", "#FFFFFF"],
  ["#0284C7", "#F1F5F9"],
  ["#E11D48", "#1E293B"],
  ["#FACC15", "#0F172A"],
  ["#14B8A6", "#111827"],
  ["#4F46E5", "#FFFFFF"],
  ["#B91C1C", "#FCD34D"],
  ["#059669", "#F8FAFC"],
  ["#9333EA", "#18181B"],
];

function seededRandom(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function computeOverallFromAttributes(pos: Position, attrs: PlayerAttributes): number {
  if (pos === "GK") {
    return Math.round(
      attrs.goalkeeping * 0.72 +
        attrs.passing * 0.1 +
        attrs.speed * 0.08 +
        attrs.stamina * 0.1
    );
  }
  if (pos === "CB") {
    return Math.round(
      attrs.defending * 0.56 +
        attrs.stamina * 0.18 +
        attrs.speed * 0.14 +
        attrs.passing * 0.12
    );
  }
  if (pos === "LB" || pos === "RB") {
    return Math.round(
      attrs.defending * 0.4 +
        attrs.speed * 0.28 +
        attrs.stamina * 0.18 +
        attrs.passing * 0.14
    );
  }
  if (pos === "CDM") {
    return Math.round(
      attrs.defending * 0.42 +
        attrs.passing * 0.28 +
        attrs.stamina * 0.2 +
        attrs.speed * 0.1
    );
  }
  if (pos === "CM") {
    return Math.round(
      attrs.passing * 0.42 +
        attrs.stamina * 0.22 +
        attrs.defending * 0.18 +
        attrs.shooting * 0.18
    );
  }
  if (pos === "CAM") {
    return Math.round(
      attrs.passing * 0.44 +
        attrs.shooting * 0.3 +
        attrs.speed * 0.16 +
        attrs.stamina * 0.1
    );
  }
  if (pos === "LW" || pos === "RW") {
    return Math.round(
      attrs.speed * 0.38 +
        attrs.shooting * 0.3 +
        attrs.passing * 0.22 +
        attrs.stamina * 0.1
    );
  }
  // ST
  return Math.round(
    attrs.shooting * 0.54 +
      attrs.speed * 0.24 +
      attrs.passing * 0.12 +
      attrs.stamina * 0.1
  );
}

export function calculateMarketValue(overall: number, age: number, potential: number): number {
  const base = Math.pow(Math.max(1, overall - 44), 2.55) * 420;
  const ageFactor = age <= 21 ? 1.35 : age <= 26 ? 1.15 : age <= 30 ? 0.9 : 0.6;
  const potBonus = Math.max(0, potential - overall) * 28000;
  return Math.round((base * ageFactor + potBonus) / 5000) * 5000;
}

export function calculateWeeklySalary(overall: number): number {
  const base = Math.pow(Math.max(1, overall - 45), 2.15) * 18;
  return Math.max(600, Math.round(base / 100) * 100);
}

export function generatePlayer(
  id: string,
  position: Position,
  targetOvr: number,
  clubId: string,
  clubName: string,
  kitNumber: number,
  rng: () => number,
  isStarter = false,
  starterSlot: number | null = null
): Player {
  const fn = FIRST_NAMES[Math.floor(rng() * FIRST_NAMES.length)];
  const ln = LAST_NAMES[Math.floor(rng() * LAST_NAMES.length)];
  const nat = NATIONALITIES[Math.floor(rng() * NATIONALITIES.length)];
  const age = 17 + Math.floor(rng() * 16); // 17..32
  const clamp = (v: number) => Math.max(30, Math.min(99, Math.round(v)));

  const spread = () => (rng() - 0.5) * 10;

  let attrs: PlayerAttributes;
  if (position === "GK") {
    attrs = {
      goalkeeping: clamp(targetOvr + 3 + spread()),
      defending: clamp(targetOvr - 18 + spread()),
      passing: clamp(targetOvr - 10 + spread()),
      speed: clamp(targetOvr - 12 + spread()),
      stamina: clamp(targetOvr - 6 + spread()),
      shooting: clamp(28 + rng() * 15),
    };
  } else if (position === "CB") {
    attrs = {
      defending: clamp(targetOvr + 4 + spread()),
      stamina: clamp(targetOvr + 1 + spread()),
      speed: clamp(targetOvr - 4 + spread()),
      passing: clamp(targetOvr - 6 + spread()),
      shooting: clamp(targetOvr - 18 + spread()),
      goalkeeping: 15,
    };
  } else if (position === "LB" || position === "RB") {
    attrs = {
      defending: clamp(targetOvr + 1 + spread()),
      speed: clamp(targetOvr + 4 + spread()),
      stamina: clamp(targetOvr + 2 + spread()),
      passing: clamp(targetOvr - 2 + spread()),
      shooting: clamp(targetOvr - 14 + spread()),
      goalkeeping: 15,
    };
  } else if (position === "CDM") {
    attrs = {
      defending: clamp(targetOvr + 3 + spread()),
      passing: clamp(targetOvr + 1 + spread()),
      stamina: clamp(targetOvr + 3 + spread()),
      speed: clamp(targetOvr - 4 + spread()),
      shooting: clamp(targetOvr - 10 + spread()),
      goalkeeping: 15,
    };
  } else if (position === "CM") {
    attrs = {
      passing: clamp(targetOvr + 3 + spread()),
      stamina: clamp(targetOvr + 2 + spread()),
      defending: clamp(targetOvr - 2 + spread()),
      shooting: clamp(targetOvr - 2 + spread()),
      speed: clamp(targetOvr - 1 + spread()),
      goalkeeping: 15,
    };
  } else if (position === "CAM") {
    attrs = {
      passing: clamp(targetOvr + 4 + spread()),
      shooting: clamp(targetOvr + 2 + spread()),
      speed: clamp(targetOvr + 1 + spread()),
      stamina: clamp(targetOvr - 3 + spread()),
      defending: clamp(targetOvr - 14 + spread()),
      goalkeeping: 15,
    };
  } else if (position === "LW" || position === "RW") {
    attrs = {
      speed: clamp(targetOvr + 5 + spread()),
      shooting: clamp(targetOvr + 1 + spread()),
      passing: clamp(targetOvr + 1 + spread()),
      stamina: clamp(targetOvr - 2 + spread()),
      defending: clamp(targetOvr - 18 + spread()),
      goalkeeping: 15,
    };
  } else {
    // ST
    attrs = {
      shooting: clamp(targetOvr + 5 + spread()),
      speed: clamp(targetOvr + 2 + spread()),
      passing: clamp(targetOvr - 4 + spread()),
      stamina: clamp(targetOvr - 1 + spread()),
      defending: clamp(targetOvr - 20 + spread()),
      goalkeeping: 15,
    };
  }

  const overall = computeOverallFromAttributes(position, attrs);
  const potentialBoost = age <= 21 ? 8 + Math.floor(rng() * 14) : age <= 25 ? 3 + Math.floor(rng() * 8) : Math.floor(rng() * 3);
  const potential = Math.min(96, Math.max(overall, overall + potentialBoost));

  return {
    id,
    name: `${fn} ${ln}`,
    age,
    nationality: nat.country,
    flag: nat.flag,
    position,
    overall,
    potential,
    attributes: attrs,
    marketValue: calculateMarketValue(overall, age, potential),
    weeklySalary: calculateWeeklySalary(overall),
    contractYears: 1 + Math.floor(rng() * 4),
    fitness: 92 + Math.floor(rng() * 9),
    morale: 78 + Math.floor(rng() * 18),
    injuryWeeks: 0,
    isStarter,
    starterSlot,
    kitNumber,
    goals: 0,
    assists: 0,
    appearances: 0,
    xp: Math.floor(rng() * 45),
    skinTone: SKIN_TONES[Math.floor(rng() * SKIN_TONES.length)],
    hairColor: HAIR_COLORS[Math.floor(rng() * HAIR_COLORS.length)],
    clubId,
    clubName,
  };
}

export function generateStartingSquad(clubName: string, divisionId: number): Player[] {
  const rng = seededRandom(Date.now() % 100000 + 777);
  const divMeta = getDivisionMeta(divisionId);
  const baseOvr = divMeta.avgOvr - 1; // Starts slightly underdog in chosen division

  // 11 starters matching 4-3-3 + 7 substitutes covering all 10 positions
  const starterPositions: Position[] = [
    "GK", "LB", "CB", "CB", "RB", "CDM", "CM", "CAM", "LW", "ST", "RW",
  ];
  const benchPositions: Position[] = ["GK", "CB", "LB", "CDM", "CM", "LW", "ST"];
  const starterNumbers = [1, 3, 4, 5, 2, 6, 8, 10, 11, 9, 7];
  const benchNumbers = [13, 15, 12, 16, 18, 17, 19];

  const squad: Player[] = [];

  starterPositions.forEach((pos, idx) => {
    const ovr = baseOvr + Math.floor((rng() - 0.45) * 6);
    squad.push(
      generatePlayer(
        `usr_p_${idx + 1}`,
        pos,
        ovr,
        "user_club",
        clubName,
        starterNumbers[idx],
        rng,
        true,
        idx
      )
    );
  });

  benchPositions.forEach((pos, idx) => {
    const ovr = baseOvr - 2 + Math.floor((rng() - 0.4) * 6);
    squad.push(
      generatePlayer(
        `usr_p_${12 + idx}`,
        pos,
        ovr,
        "user_club",
        clubName,
        benchNumbers[idx],
        rng,
        false,
        null
      )
    );
  });

  return squad;
}

export function generateTransferMarket(seed = 2026): Player[] {
  const rng = seededRandom(seed);
  const allPositions: Position[] = [
    "GK", "CB", "LB", "RB", "CDM", "CM", "CAM", "LW", "RW", "ST",
  ];
  const strategies = [
    "Youth Developers",
    "Galactico Buyers",
    "Bargain Hunters",
    "Tactical Grinders",
    "Balanced",
  ];

  const players: Player[] = [];
  let counter = 1;

  // Generate 70 players across OVR tiers (55 to 90) so player can find signings from Div 5 all the way to Premier Division
  for (let div = 5; div >= 0; div--) {
    const divMeta = getDivisionMeta(div);
    const clubList = DIVISION_CLUB_NAMES[div];
    for (let i = 0; i < 12; i++) {
      const pos = allPositions[(counter + i) % allPositions.length];
      const clubName = clubList[(i + 3) % clubList.length];
      const targetOvr = divMeta.avgOvr - 2 + Math.floor(rng() * 8);
      const p = generatePlayer(
        `mkt_${counter}`,
        pos,
        targetOvr,
        `ai_${div}_${i}`,
        clubName,
        1 + ((counter * 7) % 35),
        rng,
        false,
        null
      );
      p.aiClubStrategy = strategies[counter % strategies.length];
      players.push(p);
      counter++;
    }
  }

  return players;
}

export function makeShortName(name: string): string {
  const clean = name.replace(/FC|United|Rovers|City|Athletic|Town/gi, "").trim();
  const parts = clean.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1].slice(0, 2)).toUpperCase();
  }
  return (clean.slice(0, 3) || "CLB").toUpperCase();
}

export function generateAllDivisionsStandings(
  userClub: ClubIdentity
): Record<number, LeagueStanding[]> {
  const rng = seededRandom(4049);
  const result: Record<number, LeagueStanding[]> = {};

  for (let divId = 5; divId >= 0; divId--) {
    const meta = getDivisionMeta(divId);
    const names = [...DIVISION_CLUB_NAMES[divId]];
    const standings: LeagueStanding[] = [];

    for (let i = 0; i < 20; i++) {
      if (divId === userClub.startingDivisionId && i === 0) {
        standings.push({
          clubId: "user_club",
          clubName: userClub.name,
          shortName: userClub.shortName,
          isUser: true,
          played: 0,
          won: 0,
          drawn: 0,
          lost: 0,
          goalsFor: 0,
          goalsAgainst: 0,
          points: 0,
          form: [],
          primaryColor: userClub.badge.primaryColor,
          secondaryColor: userClub.badge.secondaryColor,
          overallRating: meta.avgOvr,
        });
      } else {
        const clubName = names[i];
        const colors = CLUB_COLOR_PAIRS[i % CLUB_COLOR_PAIRS.length];
        const ovr = meta.avgOvr - 4 + Math.floor(rng() * 9);
        standings.push({
          clubId: `club_${divId}_${i}`,
          clubName,
          shortName: makeShortName(clubName),
          isUser: false,
          played: 0,
          won: 0,
          drawn: 0,
          lost: 0,
          goalsFor: 0,
          goalsAgainst: 0,
          points: 0,
          form: [],
          primaryColor: colors[0],
          secondaryColor: colors[1],
          overallRating: ovr,
        });
      }
    }

    result[divId] = standings;
  }

  return result;
}

// Round-robin fixture generator for 20 teams (19 matchweeks per season so every team plays every rival once per campaign)
export function generateSeasonFixtures(
  divisionId: number,
  teams: LeagueStanding[]
): Fixture[] {
  const fixtures: Fixture[] = [];
  const n = teams.length; // 20
  const clubList = [...teams];
  const numWeeks = n - 1; // 19 weeks

  for (let round = 0; round < numWeeks; round++) {
    const week = round + 1;
    for (let match = 0; match < n / 2; match++) {
      const homeIdx = (round + match) % (n - 1);
      let awayIdx = (n - 1 - match + round) % (n - 1);
      if (match === 0) {
        awayIdx = n - 1;
      }

      const flip = (round + match) % 2 === 1;
      const home = flip ? clubList[awayIdx] : clubList[homeIdx];
      const away = flip ? clubList[homeIdx] : clubList[awayIdx];

      fixtures.push({
        id: `fix_${divisionId}_w${week}_${match}`,
        week,
        divisionId,
        homeClubId: home.clubId,
        homeClubName: home.clubName,
        homeShort: home.shortName,
        homePrimary: home.primaryColor,
        homeSecondary: home.secondaryColor,
        homeOvr: home.overallRating,
        awayClubId: away.clubId,
        awayClubName: away.clubName,
        awayShort: away.shortName,
        awayPrimary: away.primaryColor,
        awaySecondary: away.secondaryColor,
        awayOvr: away.overallRating,
        played: false,
        isUserMatch: home.isUser || away.isUser,
      });
    }
  }

  return fixtures;
}

export function sortStandings(standings: LeagueStanding[]): LeagueStanding[] {
  return [...standings].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    const gdA = a.goalsFor - a.goalsAgainst;
    const gdB = b.goalsFor - b.goalsAgainst;
    if (gdB !== gdA) return gdB - gdA;
    if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
    return a.clubName.localeCompare(b.clubName);
  });
}

export function calculateSquadOverall(squad: Player[]): number {
  const starters = squad.filter((p) => p.isStarter);
  const list = starters.length > 0 ? starters : squad.slice(0, 11);
  if (list.length === 0) return 60;
  const sum = list.reduce((acc, p) => acc + p.overall, 0);
  return Math.round(sum / list.length);
}

export function calculateSquadValue(squad: Player[]): number {
  return squad.reduce((acc, p) => acc + p.marketValue, 0);
}

export function calculateWeeklyWageBill(squad: Player[]): number {
  return squad.reduce((acc, p) => acc + p.weeklySalary, 0);
}

export function createDefaultObjectives(divisionId: number): SeasonObjective[] {
  const divMeta = getDivisionMeta(divisionId);
  return [
    {
      id: "obj_promotion",
      title: `Push for Top 3 Promotion in ${divMeta.name}`,
      description: "Finish inside the top 3 promotion spots by Week 19 to advance to the next division.",
      targetText: "Top 3 League Finish",
      reward: divMeta.promotionPrize,
      progress: 35,
      completed: false,
    },
    {
      id: "obj_finance",
      title: "Maintain Sound Club Finances",
      description: "Keep club balance above £500,000 and grow matchday stadium revenue.",
      targetText: "Balance > £500,000",
      reward: 150000,
      progress: 100,
      completed: true,
    },
    {
      id: "obj_youth",
      title: "Develop Squad Potential in Training",
      description: "Run at least 5 squad training drills at the Training Center to boost player OVR.",
      targetText: "5 Training Sessions",
      reward: 100000,
      progress: 20,
      completed: false,
    },
    {
      id: "obj_stadium",
      title: "Expand Club Infrastructure",
      description: "Upgrade any Stadium facility (Seating, Pitch, Floodlights, or Commercial LED).",
      targetText: "Level 2+ Facility",
      reward: 125000,
      progress: 0,
      completed: false,
    },
  ];
}

export function createInitialCareerState(customClub?: Partial<ClubIdentity>): CareerState {
  const defaultClub: ClubIdentity = {
    name: customClub?.name || "Oakwood Rovers FC",
    shortName: customClub?.shortName || makeShortName(customClub?.name || "Oakwood Rovers"),
    stadiumName: customClub?.stadiumName || "Oakwood Park Arena",
    country: customClub?.country || "England",
    startingDivisionId:
      typeof customClub?.startingDivisionId === "number" ? customClub.startingDivisionId : 5,
    managerName: customClub?.managerName || "Alex Mercer",
    badge: customClub?.badge || {
      shape: "classic",
      pattern: "stripes",
      icon: "lion",
      primaryColor: "#10B981",
      secondaryColor: "#0F172A",
      accentColor: "#F59E0B",
    },
    homeKit: customClub?.homeKit || {
      pattern: "stripes",
      primaryColor: "#10B981",
      secondaryColor: "#064E3B",
      shortsColor: "#0F172A",
      socksColor: "#10B981",
    },
    awayKit: customClub?.awayKit || {
      pattern: "sash",
      primaryColor: "#F8FAFC",
      secondaryColor: "#F59E0B",
      shortsColor: "#1E293B",
      socksColor: "#F8FAFC",
    },
  };

  const startDiv = defaultClub.startingDivisionId;
  const squad = generateStartingSquad(defaultClub.name, startDiv);
  const divisions = generateAllDivisionsStandings(defaultClub);
  const fixtures = generateSeasonFixtures(startDiv, divisions[startDiv]);
  const market = generateTransferMarket(2026);

  // Create 2 initial incoming transfer offers so the player can immediately test negotiations if they want
  const targetPlayer1 = squad[9]; // ST
  const targetPlayer2 = squad[6]; // CM
  const incomingOffers: IncomingTransferOffer[] = [
    {
      id: "offer_init_1",
      playerId: targetPlayer1.id,
      playerName: targetPlayer1.name,
      playerPosition: targetPlayer1.position,
      playerOvr: targetPlayer1.overall,
      buyingClubName: "Ironbridge Town",
      buyingClubStrategy: "Galactico Buyers",
      offeredFee: Math.round(targetPlayer1.marketValue * 1.15),
      marketValue: targetPlayer1.marketValue,
      week: 1,
      status: "pending",
    },
    {
      id: "offer_init_2",
      playerId: targetPlayer2.id,
      playerName: targetPlayer2.name,
      playerPosition: targetPlayer2.position,
      playerOvr: targetPlayer2.overall,
      buyingClubName: "Millbrook United",
      buyingClubStrategy: "Bargain Hunters",
      offeredFee: Math.round(targetPlayer2.marketValue * 0.95),
      marketValue: targetPlayer2.marketValue,
      week: 1,
      status: "pending",
    },
  ];

  const startingBalance = startDiv === 5 ? 1250000 : (6 - startDiv) * 1800000;

  return {
    initialized: Boolean(customClub),
    club: defaultClub,
    season: 1,
    week: 1,
    maxWeeksPerSeason: 19,
    currentDivisionId: startDiv,
    balance: startingBalance,
    clubDebt: 0,
    formation: "4-3-3",
    mentality: "balanced",
    squad,
    transferMarket: market,
    incomingOffers,
    divisions,
    fixtures,
    stadium: {
      capacityLevel: 1,
      pitchLevel: 1,
      lightingLevel: 1,
      commercialLevel: 1,
      ticketPrice: 22,
    },
    activeSponsorId: "sp_vortex",
    finances: [
      {
        id: "fin_init_1",
        week: 1,
        season: 1,
        description: "Owner Initial Takeover Capital Injection",
        amount: startingBalance,
        category: "prize",
      },
      {
        id: "fin_init_2",
        week: 1,
        season: 1,
        description: "VORTEX ENERGY Kit Sponsorship Advance",
        amount: 150000,
        category: "sponsor",
      },
    ],
    news: [
      {
        id: "news_init_1",
        week: 1,
        season: 1,
        title: `${defaultClub.name} Unveils New Era Under Manager ${defaultClub.managerName}`,
        body: `Supporters packed around ${defaultClub.stadiumName} today as new owner-manager ${defaultClub.managerName} promised an ambitious climb from ${getDivisionMeta(startDiv).name} to the Premier Division.`,
        category: "league",
        timestamp: "Season 1 • Week 1",
      },
      {
        id: "news_init_2",
        week: 1,
        season: 1,
        title: `Transfer Window Open: Two Clubs Submit Bids for Your Starters`,
        body: `Ironbridge Town and Millbrook United have lodged formal transfer inquiries. Visit the Transfer Market to accept, negotiate, or reject their offers.`,
        category: "transfer",
        timestamp: "Season 1 • Week 1",
      },
    ],
    objectives: createDefaultObjectives(startDiv),
    trainingFocus: "shooting",
    trainingIntensity: "balanced",
    trainedThisWeek: false,
    trophies: [],
  };
}

export const AD_CLICK_REWARD = 9000000; // £9,000,000 per advertisement click

export interface ClickableAdCampaign {
  id: string;
  brandName: string;
  headline: string;
  tagline: string;
  category: string;
  reward: number;
  bgGradient: string;
  accentColor: string;
  badgeText: string;
}

export const CLICKABLE_ADVERTISEMENTS: ClickableAdCampaign[] = [
  {
    id: "ad_vortex_9m",
    brandName: "VORTEX ENERGY DRINK",
    headline: "HYPER-CHARGE YOUR MATCHDAY!",
    tagline: "Official Global Energy Partner • Click Advertisement for Instant £9,000,000 Club Grant",
    category: "Beverage Partner",
    reward: AD_CLICK_REWARD,
    bgGradient: "from-emerald-950 via-teal-900 to-slate-900",
    accentColor: "#10B981",
    badgeText: "+£9.00M INSTANT",
  },
  {
    id: "ad_apex_9m",
    brandName: "APEX CARBON ELITE BOOTS",
    headline: "STRIKE WITH LASER PRECISION",
    tagline: "Next-Gen Carbon Fiber Football Boots • Click Ad to Collect £9,000,000 Sponsor Payout",
    category: "Kit & Footwear",
    reward: AD_CLICK_REWARD,
    bgGradient: "from-amber-950 via-orange-900 to-slate-900",
    accentColor: "#F59E0B",
    badgeText: "+£9.00M INSTANT",
  },
  {
    id: "ad_hyperion_9m",
    brandName: "HYPERION GLOBAL BANK",
    headline: "FINANCING CHAMPIONS OF TOMORROW",
    tagline: "Zero-Fee Club Treasury & Stadium Equity • Click Advertisement to Claim £9,000,000",
    category: "Financial Partner",
    reward: AD_CLICK_REWARD,
    bgGradient: "from-purple-950 via-indigo-900 to-slate-900",
    accentColor: "#A855F7",
    badgeText: "+£9.00M INSTANT",
  },
  {
    id: "ad_turbo_9m",
    brandName: "TURBO AIRWAYS INTERNATIONAL",
    headline: "FLY FIRST CLASS TO THE PREMIER DIVISION",
    tagline: "Official Club Charter Airline • Click Advertisement to Earn £9,000,000 Ad Revenue",
    category: "Aviation Partner",
    reward: AD_CLICK_REWARD,
    bgGradient: "from-sky-950 via-blue-900 to-slate-900",
    accentColor: "#38BDF8",
    badgeText: "+£9.00M INSTANT",
  },
  {
    id: "ad_kinetic_9m",
    brandName: "KINETIC 5G STADIUM NETWORK",
    headline: "ULTRA-LOW LATENCY SMART ARENAS",
    tagline: "Powering 3D Broadcasts Worldwide • Click Advertisement for £9,000,000 Payout",
    category: "Telecom Partner",
    reward: AD_CLICK_REWARD,
    bgGradient: "from-rose-950 via-pink-900 to-slate-900",
    accentColor: "#F43F5E",
    badgeText: "+£9.00M INSTANT",
  },
];

export function formatCurrency(value: number): string {
  const abs = Math.abs(value);
  const sign = value < 0 ? "-" : "";
  if (abs >= 1000000) {
    return `${sign}£${(abs / 1000000).toFixed(2)}M`;
  }
  if (abs >= 1000) {
    return `${sign}£${Math.round(abs / 1000).toLocaleString()}K`;
  }
  return `${sign}£${Math.round(abs).toLocaleString()}`;
}
