"use client";

import React from "react";
import {
  calculateSquadOverall,
  calculateSquadValue,
  CareerState,
  CLICKABLE_ADVERTISEMENTS,
  formatCurrency,
  getDivisionMeta,
  sortStandings,
  STADIUM_CAPACITY_TIERS,
} from "@/lib/gameData";
import { ClubBadge, KitJerseyPreview } from "@/components/ClubBadge";
import {
  Award,
  Bell,
  Building2,
  Calendar,
  CheckCircle2,
  Coins,
  Dumbbell,
  Edit3,
  FastForward,
  Megaphone,
  Newspaper,
  Play,
  Shield,
  Sparkles,
  Target,
  TrendingUp,
  Trophy,
  Users,
} from "lucide-react";

interface DashboardViewProps {
  career: CareerState;
  onPlayMatch3D: () => void;
  onQuickSimWeek: () => void;
  onOpenCustomizeClub: () => void;
  onClickAdvertisement: (brandName: string) => void;
  onNavigateTab: (
    tab:
      | "dashboard"
      | "squad"
      | "transfers"
      | "league"
      | "training"
      | "stadium"
      | "quickmatch"
  ) => void;
}

export function DashboardView({
  career,
  onPlayMatch3D,
  onQuickSimWeek,
  onOpenCustomizeClub,
  onClickAdvertisement,
  onNavigateTab,
}: DashboardViewProps) {
  const divMeta = getDivisionMeta(career.currentDivisionId);
  const standings = sortStandings(
    career.divisions[career.currentDivisionId] || []
  );
  const userRank = standings.findIndex((s) => s.isUser) + 1 || 1;
  const userStanding = standings.find((s) => s.isUser);
  const squadVal = calculateSquadValue(career.squad);
  const squadOvr = calculateSquadOverall(career.squad);

  const nextFixture = career.fixtures.find(
    (f) => f.week === career.week && f.isUserMatch
  );
  const recentResults = career.fixtures
    .filter((f) => f.played && f.isUserMatch)
    .slice(-5)
    .reverse();
  const upcomingFixtures = career.fixtures
    .filter((f) => !f.played && f.isUserMatch)
    .slice(0, 4);

  const stadiumCap =
    STADIUM_CAPACITY_TIERS.find(
      (t) => t.level === career.stadium.capacityLevel
    )?.capacity || 5000;

  const pendingOffersCount = career.incomingOffers.filter(
    (o) => o.status === "pending"
  ).length;

  return (
    <div className="space-y-6">
      {/* Top 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Card 1: Club Identity & Division */}
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3.5 min-w-0">
            <ClubBadge badge={career.club.badge} size={56} />
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                {divMeta.name} • {career.club.country}
              </div>
              <div className="text-base font-black text-white truncate">
                {career.club.name}
              </div>
              <div className="text-xs text-slate-400 truncate">
                Mgr: {career.club.managerName}
              </div>
            </div>
          </div>
          <button
            onClick={onOpenCustomizeClub}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300"
            title="Customize Club Badge & Kits"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        </div>

        {/* Card 2: League Position & Points */}
        <div
          onClick={() => onNavigateTab("league")}
          className="bg-[#111827] border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-4 cursor-pointer transition flex items-center justify-between"
        >
          <div>
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
              League Position ({divMeta.name})
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black font-mono text-white">
                #{userRank}
              </span>
              <span className="text-xs font-semibold text-emerald-400">
                of 20 Clubs ({userStanding?.points || 0} pts)
              </span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              W:{userStanding?.won || 0} D:{userStanding?.drawn || 0} L:
              {userStanding?.lost || 0} •{" "}
              {userRank <= 3 ? "Promotion Zone!" : "Chasing Top 3"}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
            <Trophy className="w-6 h-6" />
          </div>
        </div>

        {/* Card 3: Club Balance */}
        <div
          onClick={() => onNavigateTab("stadium")}
          className="bg-[#111827] border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-4 cursor-pointer transition flex items-center justify-between"
        >
          <div>
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
              Club Treasury Balance
            </div>
            <div className="text-3xl font-black font-mono text-emerald-400 mt-1">
              {formatCurrency(career.balance)}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              🏟️ {career.club.stadiumName} ({stadiumCap.toLocaleString()} cap)
            </div>
          </div>
          <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
            <Coins className="w-6 h-6" />
          </div>
        </div>

        {/* Card 4: Squad Value & Rating */}
        <div
          onClick={() => onNavigateTab("squad")}
          className="bg-[#111827] border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-4 cursor-pointer transition flex items-center justify-between"
        >
          <div>
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
              Squad Value & Rating
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black font-mono text-white">
                {formatCurrency(squadVal)}
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold">
                {squadOvr} OVR
              </span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {career.squad.length} Players • Formation {career.formation}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-400">
            <Users className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* CLICKABLE SPONSOR ADVERTISEMENTS STRIP (EACH AD WORTH £9,000,000) */}
      <div className="bg-[#111827] border border-emerald-500/40 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black uppercase tracking-wider text-white">
                  Official Broadcast & Stadium Advertisements
                </h3>
                <span className="px-2 py-0.5 rounded bg-emerald-500 text-slate-950 font-mono font-black text-[10px] uppercase">
                  +£9,000,000 Per Click
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Click any sponsor advertisement below to instantly earn £9,000,000 in commercial ad revenue for your club treasury!
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {CLICKABLE_ADVERTISEMENTS.map((ad) => (
            <button
              key={ad.id}
              type="button"
              onClick={() => onClickAdvertisement(ad.brandName)}
              className={`group relative overflow-hidden rounded-xl border border-white/15 hover:border-emerald-400 bg-gradient-to-br ${ad.bgGradient} p-3.5 text-left transition transform hover:-translate-y-0.5 hover:shadow-lg active:scale-95 flex flex-col justify-between`}
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-1.5">
                  <span className="text-[9px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded bg-black/40 text-slate-200">
                    AD • {ad.category}
                  </span>
                  <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded bg-emerald-400 text-slate-950 shadow">
                    +£9.00M
                  </span>
                </div>
                <div
                  className="text-xs font-black uppercase tracking-wide truncate"
                  style={{ color: ad.accentColor }}
                >
                  {ad.brandName}
                </div>
                <div className="text-[11px] font-bold text-white mt-0.5 leading-snug">
                  {ad.headline}
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] font-black uppercase text-emerald-300 group-hover:text-white">
                <span>Click Ad to Claim</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400 group-hover:rotate-12 transition" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Centerpiece Next 3D Match + Fixtures + Standings + News + Objectives */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left 8 Cols */}
        <div className="xl:col-span-8 space-y-6">
          {/* NEXT 3D MATCH HERO ACTION CARD */}
          <div className="relative overflow-hidden rounded-2xl border border-emerald-500/40 bg-gradient-to-br from-[#0d261f] via-[#111827] to-[#0f172a] p-6 shadow-2xl">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-4 mb-5">
              <div>
                <span className="px-2.5 py-1 rounded-md bg-emerald-500 text-slate-950 font-black text-[10px] uppercase tracking-wider">
                  Next 3D Matchday • Season {career.season} • Week {career.week} of{" "}
                  {career.maxWeeksPerSeason}
                </span>
                <h2 className="text-xl font-black uppercase text-white mt-2">
                  {nextFixture
                    ? `${nextFixture.homeClubName} vs ${nextFixture.awayClubName}`
                    : "Season Finale Complete — Ready for Promotion!"}
                </h2>
              </div>

              <div className="flex items-center gap-3">
                <KitJerseyPreview
                  kit={career.club.homeKit}
                  size={44}
                  label="Home"
                />
                <KitJerseyPreview
                  kit={career.club.awayKit}
                  size={44}
                  label="Away"
                />
              </div>
            </div>

            {nextFixture ? (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                <div className="md:col-span-7 flex items-center justify-around bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
                  <div className="text-center">
                    <div
                      className="w-12 h-12 mx-auto rounded-2xl flex items-center justify-center font-mono font-black text-sm text-white border border-white/20 shadow"
                      style={{ backgroundColor: nextFixture.homePrimary }}
                    >
                      {nextFixture.homeShort}
                    </div>
                    <div className="text-xs font-extrabold text-white mt-2">
                      {nextFixture.homeClubName}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {nextFixture.homeOvr} OVR (Home)
                    </div>
                  </div>

                  <div className="text-center px-3">
                    <div className="text-xs font-black text-amber-400 font-mono px-2.5 py-1 rounded bg-slate-900 border border-slate-700">
                      VS
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1">
                      3D Stadium Engine
                    </div>
                  </div>

                  <div className="text-center">
                    <div
                      className="w-12 h-12 mx-auto rounded-2xl flex items-center justify-center font-mono font-black text-sm text-white border border-white/20 shadow"
                      style={{ backgroundColor: nextFixture.awayPrimary }}
                    >
                      {nextFixture.awayShort}
                    </div>
                    <div className="text-xs font-extrabold text-white mt-2">
                      {nextFixture.awayClubName}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {nextFixture.awayOvr} OVR (Away)
                    </div>
                  </div>
                </div>

                <div className="md:col-span-5 flex flex-col gap-2.5">
                  <button
                    onClick={onPlayMatch3D}
                    className="w-full py-4 px-5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black uppercase tracking-wider text-sm shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2 transition transform hover:scale-[1.01]"
                  >
                    <Play className="w-5 h-5 fill-current" />
                    Play Live 3D Match
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={onQuickSimWeek}
                      className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase flex items-center justify-center gap-1.5 transition"
                    >
                      <FastForward className="w-3.5 h-3.5 text-amber-400" />
                      Quick Sim
                    </button>
                    <button
                      onClick={() => onNavigateTab("training")}
                      className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold text-xs uppercase flex items-center justify-center gap-1.5 transition"
                    >
                      <Dumbbell className="w-3.5 h-3.5" />
                      Train Squad
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between bg-slate-950/80 border border-slate-800 rounded-xl p-4">
                <span className="text-sm font-bold text-white">
                  All 19 Matchweeks Completed! Proceed to the League Table to claim your season prize & promotion!
                </span>
                <button
                  onClick={() => onNavigateTab("league")}
                  className="px-4 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs uppercase"
                >
                  View Final Standings
                </button>
              </div>
            )}
          </div>

          {/* Recent Results & Upcoming Fixtures Split */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Recent Results */}
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
              <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2 mb-3">
                <Award className="w-4 h-4 text-emerald-400" />
                Recent Match Results
              </h3>
              {recentResults.length === 0 ? (
                <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 text-xs text-slate-400">
                  No matches played yet this season. Kick off Matchweek 1 in 3D above!
                </div>
              ) : (
                <div className="space-y-2">
                  {recentResults.map((fix) => {
                    const userIsHome = fix.homeClubId === "user_club";
                    const uGoals = userIsHome
                      ? fix.homeScore || 0
                      : fix.awayScore || 0;
                    const oGoals = userIsHome
                      ? fix.awayScore || 0
                      : fix.homeScore || 0;
                    const outcome =
                      uGoals > oGoals ? "W" : uGoals === oGoals ? "D" : "L";
                    return (
                      <div
                        key={fix.id}
                        className="flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className={`w-5 h-5 rounded font-mono font-black text-[10px] flex items-center justify-center ${
                              outcome === "W"
                                ? "bg-emerald-500 text-slate-950"
                                : outcome === "D"
                                ? "bg-slate-600 text-white"
                                : "bg-rose-500 text-white"
                            }`}
                          >
                            {outcome}
                          </span>
                          <span className="text-slate-400 font-mono">
                            W{fix.week}
                          </span>
                          <span className="font-bold text-white truncate">
                            {fix.homeClubName} vs {fix.awayClubName}
                          </span>
                        </div>
                        <span className="font-mono font-black text-white px-2 py-0.5 rounded bg-slate-950">
                          {fix.homeScore} - {fix.awayScore}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Upcoming Fixtures */}
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
              <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2 mb-3">
                <Calendar className="w-4 h-4 text-amber-400" />
                Upcoming Fixtures
              </h3>
              <div className="space-y-2">
                {upcomingFixtures.map((fix) => (
                  <div
                    key={fix.id}
                    className="flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="px-2 py-0.5 rounded bg-slate-800 font-mono text-[10px] font-bold text-emerald-400">
                        WK {fix.week}
                      </span>
                      <span className="font-bold text-white truncate">
                        {fix.homeClubName} vs {fix.awayClubName}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">
                      {fix.homeClubId === "user_club" ? "HOME" : "AWAY"}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Season Objectives */}
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                <Target className="w-4 h-4 text-emerald-400" />
                Board Season Objectives & Milestones
              </h3>
              <span className="text-xs text-slate-400">
                Complete objectives to earn bonus transfer capital
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {career.objectives.map((obj) => (
                <div
                  key={obj.id}
                  className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-xs font-black text-white uppercase">
                        {obj.title}
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 font-mono text-[10px] font-bold shrink-0">
                        +{formatCurrency(obj.reward)}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {obj.description}
                    </p>
                  </div>

                  <div className="mt-3">
                    <div className="flex justify-between text-[10px] font-bold mb-1">
                      <span className="text-slate-400">{obj.targetText}</span>
                      <span
                        className={
                          obj.completed ? "text-emerald-400" : "text-amber-400"
                        }
                      >
                        {obj.completed ? "COMPLETED ✓" : `${obj.progress}%`}
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full ${
                          obj.completed ? "bg-emerald-400" : "bg-amber-400"
                        }`}
                        style={{ width: `${obj.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 4 Cols: News & Notifications Inbox + Mini League Table */}
        <div className="xl:col-span-4 space-y-6">
          {/* Club News & Notifications Feed */}
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-400" />
                Club News & Notifications
              </h3>
              {pendingOffersCount > 0 && (
                <button
                  onClick={() => onNavigateTab("transfers")}
                  className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-black text-[10px] uppercase"
                >
                  {pendingOffersCount} Transfer Bids
                </button>
              )}
            </div>

            <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
              {career.news.slice(0, 8).map((item) => (
                <div
                  key={item.id}
                  className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5"
                >
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase mb-1">
                    <span className="text-emerald-400">{item.category}</span>
                    <span className="text-slate-500 font-mono">
                      {item.timestamp}
                    </span>
                  </div>
                  <div className="text-xs font-extrabold text-white">
                    {item.title}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                    {item.body}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Live Division Standings Snapshot */}
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                <Trophy className="w-4 h-4 text-emerald-400" />
                {divMeta.name} Table Snapshot
              </h3>
              <button
                onClick={() => onNavigateTab("league")}
                className="text-xs font-bold text-emerald-400 hover:underline"
              >
                Full 20 Clubs →
              </button>
            </div>

            <div className="space-y-1.5 text-xs">
              {standings.slice(0, 7).map((row, idx) => (
                <div
                  key={row.clubId}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg ${
                    row.isUser
                      ? "bg-emerald-500/20 border border-emerald-500/40 font-black text-white"
                      : "bg-slate-900/70 text-slate-300"
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className={`w-5 h-5 rounded text-[10px] font-mono font-bold flex items-center justify-center ${
                        idx < 3
                          ? "bg-emerald-500 text-slate-950"
                          : "bg-slate-800 text-slate-400"
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <span className="truncate">{row.clubName}</span>
                  </div>
                  <div className="font-mono text-xs flex items-center gap-3">
                    <span className="text-slate-400">{row.played}P</span>
                    <span className="font-black text-white w-7 text-right">
                      {row.points}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
