"use client";

import React, { useState } from "react";
import {
  calculateSquadOverall,
  calculateWeeklyWageBill,
  FormationName,
  FORMATIONS,
  formatCurrency,
  Mentality,
  Player,
} from "@/lib/gameData";
import {
  Activity,
  ArrowLeftRight,
  Award,
  DollarSign,
  FileSignature,
  HeartPulse,
  Shield,
  Sparkles,
  Swords,
  UserCheck,
  Users,
} from "lucide-react";

interface SquadManagementViewProps {
  squad: Player[];
  formation: FormationName;
  mentality: Mentality;
  balance: number;
  onChangeFormation: (f: FormationName) => void;
  onChangeMentality: (m: Mentality) => void;
  onSwapPlayers: (playerAId: string, playerBId: string) => void;
  onAutoPickBestXI: () => void;
  onExtendContract: (playerId: string) => void;
  onSellPlayer: (playerId: string) => void;
  onRestSquad: () => void;
}

export function SquadManagementView({
  squad,
  formation,
  mentality,
  balance,
  onChangeFormation,
  onChangeMentality,
  onSwapPlayers,
  onAutoPickBestXI,
  onExtendContract,
  onSellPlayer,
  onRestSquad,
}: SquadManagementViewProps) {
  const [selectedSwapId, setSelectedSwapId] = useState<string | null>(null);
  const [inspectedPlayerId, setInspectedPlayerId] = useState<string>(
    squad[0]?.id || ""
  );
  const [posFilter, setPosFilter] = useState<string>("ALL");

  const slots = FORMATIONS[formation] || FORMATIONS["4-3-3"];
  const starters = squad.filter((p) => p.isStarter);
  const bench = squad.filter((p) => !p.isStarter);
  const inspectedPlayer =
    squad.find((p) => p.id === inspectedPlayerId) || squad[0];

  const handlePlayerClick = (player: Player) => {
    setInspectedPlayerId(player.id);
    if (!selectedSwapId) {
      setSelectedSwapId(player.id);
    } else if (selectedSwapId === player.id) {
      setSelectedSwapId(null);
    } else {
      onSwapPlayers(selectedSwapId, player.id);
      setSelectedSwapId(null);
    }
  };

  const filteredSquad = squad.filter((p) =>
    posFilter === "ALL" ? true : p.position === posFilter
  );

  return (
    <div className="space-y-6">
      {/* Top Bar: Formation, Mentality, Squad Summary & Quick Actions */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Tactical Formation
            </div>
            <div className="flex items-center gap-1.5 mt-1">
              {(["4-3-3", "4-4-2", "4-2-3-1", "3-5-2", "5-3-2"] as FormationName[]).map(
                (f) => (
                  <button
                    key={f}
                    onClick={() => onChangeFormation(f)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition ${
                      formation === f
                        ? "bg-emerald-500 text-slate-950 shadow"
                        : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                    }`}
                  >
                    {f}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="border-l border-slate-800 pl-4">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Match Mentality
            </div>
            <div className="flex items-center gap-1.5 mt-1">
              {(
                [
                  { id: "defensive", label: "Defensive", icon: Shield },
                  { id: "balanced", label: "Balanced", icon: Activity },
                  { id: "attacking", label: "Attacking", icon: Swords },
                ] as const
              ).map((m) => {
                const Icon = m.icon;
                return (
                  <button
                    key={m.id}
                    onClick={() => onChangeMentality(m.id)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                      mentality === m.id
                        ? "bg-amber-500 text-slate-950 shadow"
                        : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {m.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-right">
            <div className="text-[10px] font-bold uppercase text-slate-400">
              Starting XI OVR
            </div>
            <div className="text-lg font-black font-mono text-emerald-400">
              {calculateSquadOverall(squad)} OVR
            </div>
          </div>
          <div className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-right">
            <div className="text-[10px] font-bold uppercase text-slate-400">
              Weekly Wage Bill
            </div>
            <div className="text-lg font-black font-mono text-white">
              {formatCurrency(calculateWeeklyWageBill(squad))}/wk
            </div>
          </div>

          <button
            onClick={onAutoPickBestXI}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 hover:bg-emerald-500/30 text-emerald-300 text-xs font-bold uppercase transition"
          >
            <Sparkles className="w-4 h-4" />
            Auto Best XI
          </button>

          <button
            onClick={onRestSquad}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-sky-500/20 border border-sky-500/40 hover:bg-sky-500/30 text-sky-300 text-xs font-bold uppercase transition"
          >
            <HeartPulse className="w-4 h-4" />
            Recovery Bath (+Fitness)
          </button>
        </div>
      </div>

      {/* Main Split: Left 5 Cols Formation Pitch + Bench, Right 7 Cols Detailed Roster & Inspector */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left 5 Cols: Interactive Formation Pitch */}
        <div className="xl:col-span-5 space-y-4">
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                Starting XI Pitch Board ({formation})
              </span>
              <span className="text-[11px] text-slate-400">
                {selectedSwapId
                  ? "Click another player to swap positions"
                  : "Click any two players to swap"}
              </span>
            </div>

            {/* 2D Football Pitch Graphic */}
            <div className="relative w-full h-[430px] rounded-xl overflow-hidden border-2 border-emerald-700/60 bg-gradient-to-b from-emerald-900 via-emerald-800 to-emerald-900 shadow-inner">
              {/* Pitch Lines */}
              <div className="absolute inset-3 border border-white/30 rounded-sm pointer-events-none">
                <div className="absolute inset-x-0 top-1/2 border-t border-white/30" />
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full border border-white/30" />
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-36 h-14 border-b border-x border-white/30" />
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-36 h-14 border-t border-x border-white/30" />
              </div>

              {/* 11 Formation Nodes */}
              {slots.map((slot, idx) => {
                const player =
                  starters.find((p) => p.starterSlot === idx) ||
                  starters[idx] ||
                  squad[idx];
                if (!player) return null;
                const isSelected = selectedSwapId === player.id;

                return (
                  <button
                    key={slot.slotIndex}
                    type="button"
                    onClick={() => handlePlayerClick(player)}
                    style={{
                      left: `${slot.uiX}%`,
                      top: `${slot.uiY}%`,
                    }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group transition transform hover:scale-110 ${
                      isSelected ? "scale-115 z-20" : "z-10"
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex flex-col items-center justify-center font-mono font-black text-xs border-2 shadow-lg ${
                        isSelected
                          ? "bg-amber-400 text-slate-950 border-white ring-4 ring-amber-400/40"
                          : slot.role === "GK"
                          ? "bg-amber-500 text-slate-950 border-amber-200"
                          : "bg-slate-950 text-emerald-400 border-emerald-400"
                      }`}
                    >
                      <span>{player.overall}</span>
                    </div>
                    <div className="mt-1 px-2 py-0.5 rounded bg-slate-950/90 border border-slate-700 text-[10px] font-bold text-white whitespace-nowrap shadow">
                      <span className="text-emerald-400 mr-1">{slot.label}</span>
                      {player.name.split(" ").pop()}
                    </div>
                    {/* Fitness mini-bar */}
                    <div className="w-12 h-1 rounded-full bg-slate-950 mt-0.5 overflow-hidden">
                      <div
                        className={`h-full ${
                          player.fitness > 75
                            ? "bg-emerald-400"
                            : player.fitness > 50
                            ? "bg-amber-400"
                            : "bg-rose-500"
                        }`}
                        style={{ width: `${player.fitness}%` }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Substitutes Strip */}
            <div className="mt-4">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Substitutes & Reserves (Click to Swap into XI)
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {bench.map((sub) => {
                  const isSelected = selectedSwapId === sub.id;
                  return (
                    <button
                      key={sub.id}
                      type="button"
                      onClick={() => handlePlayerClick(sub)}
                      className={`p-2 rounded-xl border text-left transition flex items-center justify-between ${
                        isSelected
                          ? "bg-amber-500/20 border-amber-400 text-white"
                          : "bg-slate-900/90 border-slate-800 hover:border-slate-700 text-slate-200"
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-bold truncate">
                          {sub.name}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          <span className="text-emerald-400 font-bold">
                            {sub.position}
                          </span>{" "}
                          • Fit {sub.fitness}%
                        </div>
                      </div>
                      <span className="px-2 py-1 rounded-lg bg-slate-950 font-mono text-xs font-black text-emerald-400">
                        {sub.overall}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right 7 Cols: Selected Player Inspector + Complete Squad Table */}
        <div className="xl:col-span-7 space-y-4">
          {/* Player Inspector Card */}
          {inspectedPlayer && (
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-slate-900 border border-emerald-500/40 flex flex-col items-center justify-center">
                    <span className="text-2xl font-black font-mono text-emerald-400">
                      {inspectedPlayer.overall}
                    </span>
                    <span className="text-[10px] font-bold uppercase text-slate-300">
                      {inspectedPlayer.position}
                    </span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-black text-white">
                        #{inspectedPlayer.kitNumber} {inspectedPlayer.name}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {inspectedPlayer.flag} {inspectedPlayer.nationality}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
                      <span>Age: <strong className="text-white">{inspectedPlayer.age}</strong></span>
                      <span>Potential: <strong className="text-amber-400 font-mono">{inspectedPlayer.potential} POT</strong></span>
                      <span>Value: <strong className="text-emerald-400 font-mono">{formatCurrency(inspectedPlayer.marketValue)}</strong></span>
                      <span>Wage: <strong className="text-white font-mono">{formatCurrency(inspectedPlayer.weeklySalary)}/wk</strong></span>
                      <span>Contract: <strong className="text-white">{inspectedPlayer.contractYears} yrs</strong></span>
                    </div>
                  </div>
                </div>

                {/* Actions on Inspected Player */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => onExtendContract(inspectedPlayer.id)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 hover:bg-emerald-500/30 text-emerald-300 text-xs font-bold uppercase transition"
                  >
                    <FileSignature className="w-4 h-4" />
                    Extend Contract (+2 Yrs)
                  </button>
                  <button
                    onClick={() => onSellPlayer(inspectedPlayer.id)}
                    disabled={squad.length <= 12}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/20 border border-rose-500/40 hover:bg-rose-500/30 disabled:opacity-40 text-rose-300 text-xs font-bold uppercase transition"
                    title={
                      squad.length <= 12
                        ? "Minimum 12 players required in squad"
                        : "Sell player for immediate transfer fee"
                    }
                  >
                    <DollarSign className="w-4 h-4" />
                    Sell ({formatCurrency(Math.round(inspectedPlayer.marketValue * 0.9))})
                  </button>
                </div>
              </div>

              {/* 6 Core Attributes & Condition */}
              <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 mt-4">
                {(
                  [
                    { label: "Shooting", val: inspectedPlayer.attributes.shooting },
                    { label: "Passing", val: inspectedPlayer.attributes.passing },
                    { label: "Defending", val: inspectedPlayer.attributes.defending },
                    { label: "Speed", val: inspectedPlayer.attributes.speed },
                    { label: "Stamina", val: inspectedPlayer.attributes.stamina },
                    { label: "GK Reflex", val: inspectedPlayer.attributes.goalkeeping },
                  ] as const
                ).map((attr) => (
                  <div
                    key={attr.label}
                    className="bg-slate-900/90 border border-slate-800 rounded-xl p-2.5 text-center"
                  >
                    <div className="text-[10px] font-bold uppercase text-slate-400">
                      {attr.label}
                    </div>
                    <div className="text-lg font-black font-mono text-white mt-0.5">
                      {attr.val}
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 mt-1 overflow-hidden">
                      <div
                        className="h-full bg-emerald-500"
                        style={{ width: `${attr.val}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Complete Squad Table with Position Filter */}
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
              <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-400" />
                Full Club Squad ({squad.length} Players)
              </h3>
              <div className="flex flex-wrap gap-1">
                {[
                  "ALL",
                  "GK",
                  "CB",
                  "LB",
                  "RB",
                  "CDM",
                  "CM",
                  "CAM",
                  "LW",
                  "RW",
                  "ST",
                ].map((pos) => (
                  <button
                    key={pos}
                    onClick={() => setPosFilter(pos)}
                    className={`px-2 py-1 rounded text-[10px] font-bold uppercase transition ${
                      posFilter === pos
                        ? "bg-emerald-500 text-slate-950"
                        : "bg-slate-900 text-slate-400 hover:text-white"
                    }`}
                  >
                    {pos}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] font-bold uppercase text-slate-400">
                    <th className="py-2.5 px-2">Role</th>
                    <th className="py-2.5 px-2">Player</th>
                    <th className="py-2.5 px-2">Pos</th>
                    <th className="py-2.5 px-2">Age</th>
                    <th className="py-2.5 px-2">OVR / POT</th>
                    <th className="py-2.5 px-2">Fitness</th>
                    <th className="py-2.5 px-2">Morale</th>
                    <th className="py-2.5 px-2">Value</th>
                    <th className="py-2.5 px-2">Salary</th>
                    <th className="py-2.5 px-2 text-right">Swap</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-xs">
                  {filteredSquad.map((p) => {
                    const isSelected = selectedSwapId === p.id;
                    return (
                      <tr
                        key={p.id}
                        onClick={() => setInspectedPlayerId(p.id)}
                        className={`cursor-pointer transition ${
                          inspectedPlayerId === p.id
                            ? "bg-emerald-500/10"
                            : "hover:bg-slate-900/70"
                        }`}
                      >
                        <td className="py-2.5 px-2">
                          {p.isStarter ? (
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-[10px]">
                              XI
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-bold text-[10px]">
                              SUB
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-2 font-bold text-white">
                          <span className="mr-1.5">{p.flag}</span>
                          {p.name}
                          {p.goals > 0 && (
                            <span className="ml-1.5 text-[10px] text-amber-400 font-mono">
                              ⚽{p.goals}
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-2 font-mono font-bold text-emerald-400">
                          {p.position}
                        </td>
                        <td className="py-2.5 px-2 font-mono text-slate-300">
                          {p.age}
                        </td>
                        <td className="py-2.5 px-2 font-mono">
                          <span className="font-black text-white">
                            {p.overall}
                          </span>{" "}
                          <span className="text-amber-400 text-[11px]">
                            / {p.potential}
                          </span>
                        </td>
                        <td className="py-2.5 px-2">
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                              <div
                                className={`h-full ${
                                  p.fitness > 75
                                    ? "bg-emerald-400"
                                    : p.fitness > 50
                                    ? "bg-amber-400"
                                    : "bg-rose-500"
                                }`}
                                style={{ width: `${p.fitness}%` }}
                              />
                            </div>
                            <span className="font-mono text-[11px] text-slate-300">
                              {p.fitness}%
                            </span>
                          </div>
                        </td>
                        <td className="py-2.5 px-2 font-mono text-slate-300">
                          {p.morale}%
                        </td>
                        <td className="py-2.5 px-2 font-mono text-emerald-400">
                          {formatCurrency(p.marketValue)}
                        </td>
                        <td className="py-2.5 px-2 font-mono text-slate-300">
                          {formatCurrency(p.weeklySalary)}/w
                        </td>
                        <td className="py-2.5 px-2 text-right">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePlayerClick(p);
                            }}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase transition ${
                              isSelected
                                ? "bg-amber-400 text-slate-950"
                                : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                            }`}
                          >
                            <ArrowLeftRight className="w-3 h-3 inline mr-1" />
                            {isSelected ? "Selected" : "Swap"}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
