import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { matchHistory } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const matches = await db
      .select()
      .from(matchHistory)
      .orderBy(desc(matchHistory.playedAt))
      .limit(20);
    return NextResponse.json({ matches });
  } catch (err) {
    console.error("GET /api/matches error:", err);
    return NextResponse.json({ matches: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      homeClub,
      awayClub,
      homeScore,
      awayScore,
      divisionName = "Division 5",
      season = 1,
      week = 1,
      mode = "career",
    } = body;

    const inserted = await db
      .insert(matchHistory)
      .values({
        homeClub: String(homeClub || "Home FC"),
        awayClub: String(awayClub || "Away FC"),
        homeScore: Number(homeScore) || 0,
        awayScore: Number(awayScore) || 0,
        divisionName: String(divisionName),
        season: Number(season) || 1,
        week: Number(week) || 1,
        mode: String(mode),
      })
      .returning();

    return NextResponse.json({ ok: true, match: inserted[0] });
  } catch (err) {
    console.error("POST /api/matches error:", err);
    return NextResponse.json({ ok: false });
  }
}
