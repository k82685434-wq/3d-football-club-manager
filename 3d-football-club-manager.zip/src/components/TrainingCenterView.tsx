"use client";

import React, { useState } from "react";
import {
  formatCurrency,
  Player,
  TrainingCategory,
} from "@/lib/gameData";
import {
  Activity,
  Award,
  CheckCircle2,
  Dumbbell,
  Flame,
  HeartPulse,
  Shield,
  Sparkles,
  Target,
  TrendingUp,
  Zap,
} from "lucide-react";

interface TrainingCenterViewProps {
  squad: Player[];
  trainingFocus: TrainingCategory;
  trainingIntensity: "light" | "balanced" | "intense";
  trainedThisWeek: boolean;
  balance: number;
  onSelectCategory: (cat: TrainingCategory) => void;
  onSelectIntensity: (intensity: "light" | "balanced" | "intense") => void;
  onRunSquadTraining: () => void;
  onRunIndividualDrill: (playerId: string, category: TrainingCategory) => void;
}

const CATEGORIES: {
  id: TrainingCategory;
  title: string;
  subtitle: string;
  primaryStat: string;
  description: string;
  color: string;
}[] = [
  {
    id: "shooting",
    title: "Shooting & Finishing",
    subtitle: "Box Precision & Shot Power",
    primaryStat: "SHOOTING",
    description:
      "Improves clinical finishing inside the box, volley technique, and long-range shot velocity in 3D matches.",
    color: "text-amber-400 border-amber-500/40 bg-amber-500/10",
  },
  {
    id: "passing",
    title: "Passing & Vision",
    subtitle: "Rondo Possession & Through Balls",
    primaryStat: "PASSING",
    description:
      "Sharpens ground passing crispness, progressive through-balls, and midfield build-up play.",
    color: "text-emerald-400 border-emerald-500/40 bg-emerald-500/10",
  },
  {
    id: "defending",
    title: "Defending & Pressing",
    subtitle: "Tackle Timing & Defensive Line",
    primaryStat: "DEFENDING",
    description:
      "Boosts 1v1 standing tackle success rate, defensive positioning, and aerial duel dominance.",
    color: "text-sky-400 border-sky-500/40 bg-sky-500/10",
  },
  {
    id: "speed",
    title: "Speed & Explosiveness",
    subtitle: "Sprint Mechanics & Agility",
    primaryStat: "SPEED",
    description:
      "Increases top sprint speed on counter-attacks and recovery pace when tracking back.",
    color: "text-purple-400 border-purple-500/40 bg-purple-500/10",
  },
  {
    id: "fitness",
    title: "Fitness & Conditioning",
    subtitle: "Stamina & Full Squad Recovery",
    primaryStat: "STAMINA + FITNESS",
    description:
      "Restores squad match fitness (+18% Fitness) while building long-term stamina and reducing injury risk.",
    color: "text-rose-400 border-rose-500/40 bg-rose-500/10",
  },
  {
    id: "goalkeeping",
    title: "Goalkeeping & Reflexes",
    subtitle: "Shot-Stopping Dives & Command",
    primaryStat: "GOALKEEPING",
    description:
      "Accelerates goalkeeper dive reaction speed, high-claim handling, and 1v1 shot parrying.",
    color: "text-yellow-400 border-yellow-500/40 bg-yellow-500/10",
  },
];

export function TrainingCenterView({
  squad,
  trainingFocus,
  trainingIntensity,
  trainedThisWeek,
  balance,
  onSelectCategory,
  onSelectIntensity,
  onRunSquadTraining,
  onRunIndividualDrill,
}: TrainingCenterViewProps) {
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>(
    squad[0]?.id || ""
  );

  const selectedPlayer =
    squad.find((p) => p.id === selectedPlayerId) || squad[0];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-400">
            Performance & Player Development Complex
          </div>
          <h2 className="text-xl font-black uppercase text-white mt-0.5 flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-emerald-400" />
            Club Training Center
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Select a training focus and intensity to develop your squad&apos;s attributes and unlock their Potential OVR.
          </p>
        </div>

        {/* Intensity & Run Button */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
            {(["light", "balanced", "intense"] as const).map((level) => (
              <button
                key={level}
                onClick={() => onSelectIntensity(level)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                  trainingIntensity === level
                    ? "bg-emerald-500 text-slate-950 shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {level}
              </button>
            ))}
          </div>

          <button
            onClick={onRunSquadTraining}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg transition"
          >
            <Sparkles className="w-4 h-4" />
            {trainedThisWeek
              ? "Run Extra Bonus Session (£15K)"
              : "Run Weekly Squad Training Drill"}
          </button>
        </div>
      </div>

      {/* 6 Training Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {CATEGORIES.map((cat) => {
          const isSelected = trainingFocus === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => onSelectCategory(cat.id)}
              className={`p-5 rounded-2xl border text-left transition flex flex-col justify-between ${
                isSelected
                  ? "bg-emerald-500/15 border-emerald-500 ring-2 ring-emerald-500/30 shadow-xl"
                  : "bg-[#111827] border-slate-800 hover:border-slate-700"
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-md border text-[10px] font-black uppercase ${cat.color}`}
                  >
                    Boosts {cat.primaryStat}
                  </span>
                  {isSelected && (
                    <span className="flex items-center gap-1 text-xs font-bold text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" /> Active Focus
                    </span>
                  )}
                </div>
                <h3 className="text-base font-black text-white uppercase">
                  {cat.title}
                </h3>
                <div className="text-xs font-semibold text-slate-400">
                  {cat.subtitle}
                </div>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  {cat.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
                <span className="text-slate-400">
                  Fitness Impact:{" "}
                  <strong className="text-white">
                    {cat.id === "fitness"
                      ? "+18% Recovery"
                      : trainingIntensity === "light"
                      ? "-3%"
                      : trainingIntensity === "balanced"
                      ? "-6%"
                      : "-10%"}
                  </strong>
                </span>
                <span className="text-emerald-400 font-bold">
                  +XP & Stat Growth
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Individual Specialist Coaching & Squad Development Progress Table */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left 5 Cols: Individual 1-on-1 Coaching Lab */}
        {selectedPlayer && (
          <div className="xl:col-span-5 bg-[#111827] border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4">
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Flame className="w-4 h-4" />
                1-on-1 Specialist Player Coaching
              </div>
              <h3 className="text-lg font-black text-white mt-1">
                {selectedPlayer.flag} {selectedPlayer.name} (
                {selectedPlayer.position})
              </h3>
              <p className="text-xs text-slate-400">
                Age {selectedPlayer.age} • Current{" "}
                <strong className="text-emerald-400 font-mono">
                  {selectedPlayer.overall} OVR
                </strong>{" "}
                • Ceiling{" "}
                <strong className="text-amber-400 font-mono">
                  {selectedPlayer.potential} POT
                </strong>
              </p>

              {/* XP Progress Bar to Next OVR */}
              <div className="mt-4 bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                <div className="flex justify-between text-xs font-bold mb-1.5">
                  <span className="text-slate-300">
                    Development Progress to {selectedPlayer.overall + 1} OVR
                  </span>
                  <span className="font-mono text-emerald-400">
                    {selectedPlayer.xp}%
                  </span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-amber-400 transition-all duration-300"
                    style={{ width: `${selectedPlayer.xp}%` }}
                  />
                </div>
              </div>

              {/* Attributes Breakdown */}
              <div className="grid grid-cols-2 gap-2.5 mt-4">
                {(
                  [
                    {
                      id: "shooting" as TrainingCategory,
                      label: "Shooting",
                      val: selectedPlayer.attributes.shooting,
                    },
                    {
                      id: "passing" as TrainingCategory,
                      label: "Passing",
                      val: selectedPlayer.attributes.passing,
                    },
                    {
                      id: "defending" as TrainingCategory,
                      label: "Defending",
                      val: selectedPlayer.attributes.defending,
                    },
                    {
                      id: "speed" as TrainingCategory,
                      label: "Speed",
                      val: selectedPlayer.attributes.speed,
                    },
                    {
                      id: "fitness" as TrainingCategory,
                      label: "Stamina",
                      val: selectedPlayer.attributes.stamina,
                    },
                    {
                      id: "goalkeeping" as TrainingCategory,
                      label: "Goalkeeping",
                      val: selectedPlayer.attributes.goalkeeping,
                    },
                  ] as const
                ).map((stat) => (
                  <div
                    key={stat.id}
                    className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-[10px] font-bold uppercase text-slate-400">
                        {stat.label}
                      </div>
                      <div className="text-base font-black font-mono text-white">
                        {stat.val}
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        onRunIndividualDrill(selectedPlayer.id, stat.id)
                      }
                      disabled={balance < 8000}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 hover:bg-emerald-500/30 disabled:opacity-40 text-emerald-300 text-[10px] font-bold uppercase transition"
                    >
                      Train +1 (£8K)
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-[11px] text-slate-400 bg-slate-900/70 border border-slate-800 rounded-xl p-3">
              💡 Tip: Players aged 21 and under gain <strong>double XP</strong>{" "}
              during weekly squad training sessions until they reach their Potential ceiling!
            </div>
          </div>
        )}

        {/* Right 7 Cols: Squad Progression & Potential Table */}
        <div className="xl:col-span-7 bg-[#111827] border border-slate-800 rounded-2xl p-5">
          <h3 className="text-sm font-black uppercase tracking-wider text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            Squad Development & Growth Tracker (Click Player for 1-on-1 Coaching)
          </h3>

          <div className="overflow-x-auto max-h-[420px] overflow-y-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] font-bold uppercase text-slate-400">
                  <th className="py-2 px-2">Player</th>
                  <th className="py-2 px-2">Pos</th>
                  <th className="py-2 px-2">Age</th>
                  <th className="py-2 px-2">OVR → POT</th>
                  <th className="py-2 px-2">Next Level XP</th>
                  <th className="py-2 px-2">Fitness</th>
                  <th className="py-2 px-2 text-right">Focus</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs">
                {squad.map((p) => (
                  <tr
                    key={p.id}
                    onClick={() => setSelectedPlayerId(p.id)}
                    className={`cursor-pointer transition ${
                      selectedPlayerId === p.id
                        ? "bg-emerald-500/15"
                        : "hover:bg-slate-900/60"
                    }`}
                  >
                    <td className="py-2.5 px-2 font-bold text-white">
                      {p.flag} {p.name}
                    </td>
                    <td className="py-2.5 px-2 font-mono font-bold text-emerald-400">
                      {p.position}
                    </td>
                    <td className="py-2.5 px-2 font-mono text-slate-300">
                      {p.age}
                    </td>
                    <td className="py-2.5 px-2 font-mono">
                      <span className="font-black text-white">{p.overall}</span>{" "}
                      <span className="text-slate-500">→</span>{" "}
                      <span className="text-amber-400 font-bold">
                        {p.potential}
                      </span>
                    </td>
                    <td className="py-2.5 px-2">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-emerald-400"
                            style={{ width: `${p.xp}%` }}
                          />
                        </div>
                        <span className="font-mono text-[10px] text-slate-400">
                          {p.xp}%
                        </span>
                      </div>
                    </td>
                    <td className="py-2.5 px-2 font-mono text-slate-300">
                      {p.fitness}%
                    </td>
                    <td className="py-2.5 px-2 text-right">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPlayerId(p.id);
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-emerald-300 uppercase"
                      >
                        Select
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
