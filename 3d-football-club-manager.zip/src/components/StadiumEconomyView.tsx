"use client";

import React from "react";
import {
  calculateWeeklyWageBill,
  CLICKABLE_ADVERTISEMENTS,
  FinancialRecord,
  formatCurrency,
  getDivisionMeta,
  Player,
  SPONSOR_OPTIONS,
  STADIUM_CAPACITY_TIERS,
  StadiumState,
} from "@/lib/gameData";
import { Stadium3DPreview } from "@/components/Stadium3DPreview";
import {
  Building2,
  CheckCircle2,
  Coins,
  CreditCard,
  DollarSign,
  Landmark,
  Lightbulb,
  Megaphone,
  Sparkles,
  Ticket,
  TrendingUp,
  Users,
} from "lucide-react";

interface StadiumEconomyViewProps {
  stadiumName: string;
  primaryColor: string;
  stadium: StadiumState;
  currentDivisionId: number;
  balance: number;
  clubDebt: number;
  squad: Player[];
  activeSponsorId: string;
  finances: FinancialRecord[];
  onUpgradeStadium: (
    module: "capacityLevel" | "pitchLevel" | "lightingLevel" | "commercialLevel",
    cost: number
  ) => void;
  onChangeTicketPrice: (price: number) => void;
  onSelectSponsor: (sponsorId: string) => void;
  onTakeLoan: (amount: number) => void;
  onRepayLoan: (amount: number) => void;
  onClickAdvertisement: (brandName: string) => void;
}

export function StadiumEconomyView({
  stadiumName,
  primaryColor,
  stadium,
  currentDivisionId,
  balance,
  clubDebt,
  squad,
  activeSponsorId,
  finances,
  onUpgradeStadium,
  onChangeTicketPrice,
  onSelectSponsor,
  onTakeLoan,
  onRepayLoan,
  onClickAdvertisement,
}: StadiumEconomyViewProps) {
  const capTier =
    STADIUM_CAPACITY_TIERS.find((t) => t.level === stadium.capacityLevel) ||
    STADIUM_CAPACITY_TIERS[0];
  const nextCapTier = STADIUM_CAPACITY_TIERS.find(
    (t) => t.level === stadium.capacityLevel + 1
  );

  const divMeta = getDivisionMeta(currentDivisionId);
  const activeSponsor =
    SPONSOR_OPTIONS.find((s) => s.id === activeSponsorId) || SPONSOR_OPTIONS[0];

  // Calculate projected matchday attendance & gate revenue
  const idealTicketPrice = 22 + (5 - currentDivisionId) * 9;
  const priceSensitivity = Math.max(
    0.42,
    Math.min(1.0, 1 - (stadium.ticketPrice - idealTicketPrice) * 0.015)
  );
  const projectedAttendance = Math.round(
    capTier.capacity * divMeta.baseAttendanceFactor * priceSensitivity
  );
  const projectedGateRevenue =
    projectedAttendance * stadium.ticketPrice +
    stadium.commercialLevel * 18000 +
    stadium.lightingLevel * 12000;

  const weeklyWages = calculateWeeklyWageBill(squad);
  const loanInterest = Math.round(clubDebt * 0.015);
  const weeklyNetProjection =
    projectedGateRevenue +
    activeSponsor.weeklyBase -
    weeklyWages -
    capTier.maintenance -
    loanInterest;

  const upgradeModules = [
    {
      key: "capacityLevel" as const,
      title: "Stadium Stands & Seating Capacity",
      level: stadium.capacityLevel,
      currentDesc: `${capTier.name} (${capTier.capacity.toLocaleString()} seats)`,
      nextDesc: nextCapTier
        ? `Expand to ${nextCapTier.capacity.toLocaleString()} seats`
        : "Max Colossal Capacity Reached",
      cost: nextCapTier ? nextCapTier.cost : 0,
      icon: Users,
    },
    {
      key: "pitchLevel" as const,
      title: "Grass Pitch & Under-Soil Heating",
      level: stadium.pitchLevel,
      currentDesc: `Level ${stadium.pitchLevel} Hybrid Turf Surface`,
      nextDesc:
        stadium.pitchLevel < 5
          ? "Boost passing accuracy & cut player injuries by 20%"
          : "World-Class Desso GrassMaster Installed",
      cost: stadium.pitchLevel < 5 ? stadium.pitchLevel * 220000 : 0,
      icon: Sparkles,
    },
    {
      key: "lightingLevel" as const,
      title: "Floodlight Towers & Broadcast Rig",
      level: stadium.lightingLevel,
      currentDesc: `Level ${stadium.lightingLevel} Stadium Floodlights`,
      nextDesc:
        stadium.lightingLevel < 5
          ? "+£12,000 TV Broadcast revenue per matchday"
          : "8K Ultra Broadcast Towers Active",
      cost: stadium.lightingLevel < 5 ? stadium.lightingLevel * 180000 : 0,
      icon: Lightbulb,
    },
    {
      key: "commercialLevel" as const,
      title: "3D Scoreboard & Perimeter LED Boards",
      level: stadium.commercialLevel,
      currentDesc: `Level ${stadium.commercialLevel} Commercial Hospitality`,
      nextDesc:
        stadium.commercialLevel < 5
          ? "+£18,000 commercial & ad-board income per match"
          : "360° Ribbon LED & VIP Suites Active",
      cost: stadium.commercialLevel < 5 ? stadium.commercialLevel * 260000 : 0,
      icon: Megaphone,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top KPI Financial Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Club Balance
          </div>
          <div className="text-2xl font-black font-mono text-emerald-400 mt-1">
            {formatCurrency(balance)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Available Transfer & Upgrade Capital
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Stadium Capacity
          </div>
          <div className="text-2xl font-black font-mono text-white mt-1">
            {capTier.capacity.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-400 mt-0.5">
            Est. Crowd: {projectedAttendance.toLocaleString()} fans
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Matchday Gate + Commercial
          </div>
          <div className="text-2xl font-black font-mono text-amber-400 mt-1">
            +{formatCurrency(projectedGateRevenue)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Ticket £{stadium.ticketPrice} + LED Adverts
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Weekly Player Wages
          </div>
          <div className="text-2xl font-black font-mono text-rose-400 mt-1">
            -{formatCurrency(weeklyWages)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {squad.length} Contracted Players
          </div>
        </div>

        <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Net Matchweek Projection
          </div>
          <div
            className={`text-2xl font-black font-mono mt-1 ${
              weeklyNetProjection >= 0 ? "text-emerald-400" : "text-rose-400"
            }`}
          >
            {weeklyNetProjection >= 0 ? "+" : ""}
            {formatCurrency(weeklyNetProjection)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Includes Sponsor + Gate - Wages
          </div>
        </div>
      </div>

      {/* Main Split: 3D Stadium Preview + Upgrade Modules */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left 6 Cols: Live 3D Stadium Orbit Preview & Ticket Price Control */}
        <div className="xl:col-span-6 space-y-4">
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                  Live 3D Architectural View
                </span>
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-emerald-400" />
                  {stadiumName}
                </h3>
              </div>
              <span className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-800 font-mono text-xs font-bold text-amber-400">
                Tier {stadium.capacityLevel} • {capTier.capacity.toLocaleString()} Seats
              </span>
            </div>

            <Stadium3DPreview stadium={stadium} primaryColor={primaryColor} />

            {/* Ticket Pricing Control */}
            <div className="mt-4 bg-slate-900/90 border border-slate-800 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase text-white flex items-center gap-1.5">
                  <Ticket className="w-4 h-4 text-amber-400" />
                  Matchday Ticket Price: £{stadium.ticketPrice}
                </span>
                <span className="text-xs font-mono text-emerald-400 font-bold">
                  Est. Gate: {formatCurrency(projectedGateRevenue)} / match
                </span>
              </div>
              <input
                type="range"
                min={15}
                max={85}
                value={stadium.ticketPrice}
                onChange={(e) => onChangeTicketPrice(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                <span>£15 (Packed Crowd)</span>
                <span>Optimal for Div: £{idealTicketPrice}</span>
                <span>£85 (VIP Pricing)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 6 Cols: 4 Stadium Facility Upgrade Cards */}
        <div className="xl:col-span-6 space-y-3.5">
          {upgradeModules.map((mod) => {
            const Icon = mod.icon;
            const isMax = mod.level >= 5;
            const canAfford = balance >= mod.cost;

            return (
              <div
                key={mod.key}
                className="bg-[#111827] border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3.5">
                  <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-black uppercase text-white">
                        {mod.title}
                      </h4>
                      <span className="px-2 py-0.5 rounded bg-slate-800 font-mono text-[10px] font-bold text-emerald-400">
                        LVL {mod.level}/5
                      </span>
                    </div>
                    <div className="text-xs font-semibold text-slate-300 mt-0.5">
                      {mod.currentDesc}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {mod.nextDesc}
                    </div>
                    {/* Level dots */}
                    <div className="flex gap-1.5 mt-2">
                      {[1, 2, 3, 4, 5].map((lv) => (
                        <span
                          key={lv}
                          className={`w-6 h-1.5 rounded-full ${
                            lv <= mod.level ? "bg-emerald-500" : "bg-slate-800"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onUpgradeStadium(mod.key, mod.cost)}
                  disabled={isMax || !canAfford}
                  className={`shrink-0 px-4 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition ${
                    isMax
                      ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                      : canAfford
                      ? "bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow"
                      : "bg-slate-800 text-slate-400 opacity-60 cursor-not-allowed"
                  }`}
                >
                  {isMax
                    ? "Max Level"
                    : `Upgrade (${formatCurrency(mod.cost)})`}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Clickable Stadium Perimeter LED Advertisements (+£9,000,000 per click) */}
      <div className="bg-[#111827] border border-amber-500/40 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black uppercase tracking-wider text-white">
                  Interactive Stadium LED Advertisements
                </h3>
                <span className="px-2 py-0.5 rounded bg-emerald-500 text-slate-950 font-mono font-black text-[10px] uppercase">
                  +£9,000,000 Each Click
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Click any stadium advertisement board below to immediately collect £9,000,000 in commercial ad revenue!
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {CLICKABLE_ADVERTISEMENTS.map((ad) => (
            <button
              key={ad.id}
              type="button"
              onClick={() => onClickAdvertisement(ad.brandName)}
              className={`group relative overflow-hidden rounded-xl border border-white/15 hover:border-emerald-400 bg-gradient-to-br ${ad.bgGradient} p-3.5 text-left transition transform hover:-translate-y-0.5 hover:shadow-lg active:scale-95 flex flex-col justify-between`}
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-[9px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded bg-black/40 text-slate-200">
                    LED AD
                  </span>
                  <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded bg-emerald-400 text-slate-950">
                    +£9.00M
                  </span>
                </div>
                <div
                  className="text-xs font-black uppercase tracking-wide truncate"
                  style={{ color: ad.accentColor }}
                >
                  {ad.brandName}
                </div>
                <div className="text-[11px] font-bold text-white mt-0.5">
                  {ad.headline}
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] font-black uppercase text-emerald-300 group-hover:text-white">
                <span>Click for +£9M</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Split: Official Club Sponsorships + Bank Debt & Financial Ledger */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left 6 Cols: Fictional Brand Sponsorship Contracts */}
        <div className="xl:col-span-6 bg-[#111827] border border-slate-800 rounded-2xl p-5">
          <h3 className="text-sm font-black uppercase tracking-wider text-white mb-1 flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            Official Kit & Stadium Sponsorship Partners
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Select your primary commercial partner. Higher divisions unlock mega-sponsors.
          </p>

          <div className="space-y-2.5">
            {SPONSOR_OPTIONS.map((sp) => {
              const isSelected = sp.id === activeSponsorId;
              const isUnlocked = currentDivisionId <= sp.minDivisionId;
              return (
                <div
                  key={sp.id}
                  className={`p-3.5 rounded-xl border flex flex-wrap items-center justify-between gap-3 transition ${
                    isSelected
                      ? "bg-emerald-500/15 border-emerald-500"
                      : "bg-slate-900/90 border-slate-800"
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: sp.accentColor }}
                      />
                      <span className="text-sm font-black text-white">
                        {sp.brandName}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-semibold">
                        {sp.sector}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 mt-1 font-mono">
                      Weekly:{" "}
                      <strong className="text-emerald-400">
                        +{formatCurrency(sp.weeklyBase)}
                      </strong>{" "}
                      • Win Bonus:{" "}
                      <strong className="text-amber-400">
                        +{formatCurrency(sp.winBonus)}
                      </strong>
                    </div>
                  </div>

                  {isSelected ? (
                    <span className="flex items-center gap-1 text-xs font-black text-emerald-400 uppercase">
                      <CheckCircle2 className="w-4 h-4" /> Active Partner
                    </span>
                  ) : (
                    <button
                      onClick={() => onSelectSponsor(sp.id)}
                      disabled={!isUnlocked}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                        isUnlocked
                          ? "bg-emerald-500 hover:bg-emerald-400 text-slate-950"
                          : "bg-slate-800 text-slate-500 cursor-not-allowed"
                      }`}
                    >
                      {isUnlocked
                        ? "Sign Deal"
                        : `Requires ${getDivisionMeta(sp.minDivisionId).name}`}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 6 Cols: Club Debt / Bank Facility & Financial Ledger */}
        <div className="xl:col-span-6 space-y-4">
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                  <Landmark className="w-4 h-4 text-sky-400" />
                  Football Bank Credit & Club Debt Facility
                </h3>
                <p className="text-xs text-slate-400">
                  Current Club Debt:{" "}
                  <strong className="text-rose-400 font-mono">
                    {formatCurrency(clubDebt)}
                  </strong>{" "}
                  (Weekly Interest: {formatCurrency(loanInterest)})
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onTakeLoan(500000)}
                  disabled={clubDebt >= 3000000}
                  className="px-3 py-2 rounded-xl bg-sky-500/20 border border-sky-500/40 hover:bg-sky-500/30 disabled:opacity-40 text-sky-300 text-xs font-bold uppercase transition"
                >
                  Borrow +£500K
                </button>
                <button
                  onClick={() => onRepayLoan(Math.min(clubDebt, 500000))}
                  disabled={clubDebt <= 0 || balance < Math.min(clubDebt, 500000)}
                  className="px-3 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 hover:bg-emerald-500/30 disabled:opacity-40 text-emerald-300 text-xs font-bold uppercase transition"
                >
                  Repay Debt
                </button>
              </div>
            </div>
          </div>

          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
            <h3 className="text-sm font-black uppercase tracking-wider text-white mb-3 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-400" />
              Recent Financial Ledger
            </h3>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {finances.slice(0, 12).map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between bg-slate-900/80 border border-slate-800 rounded-xl px-3.5 py-2 text-xs"
                >
                  <div>
                    <div className="font-semibold text-white">
                      {item.description}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Season {item.season} • Week {item.week} •{" "}
                      <span className="uppercase">{item.category}</span>
                    </div>
                  </div>
                  <span
                    className={`font-mono font-black ${
                      item.amount >= 0 ? "text-emerald-400" : "text-rose-400"
                    }`}
                  >
                    {item.amount >= 0 ? "+" : ""}
                    {formatCurrency(item.amount)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
