"use client";

import React, { useState } from "react";
import {
  DIVISIONS_META,
  Fixture,
  formatCurrency,
  getDivisionMeta,
  LeagueStanding,
  sortStandings,
} from "@/lib/gameData";
import {
  ArrowUpCircle,
  Calendar,
  FastForward,
  Play,
  Shield,
  Sparkles,
  Trophy,
} from "lucide-react";

interface LeagueTableViewProps {
  currentDivisionId: number;
  season: number;
  week: number;
  maxWeeks: number;
  divisions: Record<number, LeagueStanding[]>;
  fixtures: Fixture[];
  onPlayNextMatch3D: () => void;
  onQuickSimWeek: () => void;
  onSimRestOfSeason: () => void;
}

export function LeagueTableView({
  currentDivisionId,
  season,
  week,
  maxWeeks,
  divisions,
  fixtures,
  onPlayNextMatch3D,
  onQuickSimWeek,
  onSimRestOfSeason,
}: LeagueTableViewProps) {
  const [viewedDivisionId, setViewedDivisionId] =
    useState<number>(currentDivisionId);

  const standings = sortStandings(divisions[viewedDivisionId] || []);
  const divMeta = getDivisionMeta(viewedDivisionId);
  const currentWeekFixtures = fixtures.filter((f) => f.week === week);

  return (
    <div className="space-y-6">
      {/* Division Pyramid Selector Tabs */}
      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-400">
              6-Tier Football Pyramid • Season {season} • Matchweek {week} of {maxWeeks}
            </div>
            <h2 className="text-xl font-black uppercase text-white mt-0.5 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              {divMeta.name}{" "}
              <span className="text-xs font-semibold text-slate-400">
                ({divMeta.tierLabel})
              </span>
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {week <= maxWeeks && (
              <>
                <button
                  onClick={onPlayNextMatch3D}
                  className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow transition"
                >
                  <Play className="w-4 h-4 fill-current" />
                  Play Week {week} in 3D
                </button>
                <button
                  onClick={onQuickSimWeek}
                  className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase transition"
                >
                  <FastForward className="w-4 h-4 text-amber-400" />
                  Quick Sim Week {week}
                </button>
              </>
            )}
            <button
              onClick={onSimRestOfSeason}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-indigo-500/20 border border-indigo-500/40 hover:bg-indigo-500/30 text-indigo-300 font-bold text-xs uppercase transition"
            >
              <Sparkles className="w-4 h-4" />
              {week > maxWeeks
                ? "Complete Season & Promotion"
                : "Sim to Season Finale"}
            </button>
          </div>
        </div>

        {/* 6 Division Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {DIVISIONS_META.map((d) => {
            const isUserDiv = d.id === currentDivisionId;
            const isActive = d.id === viewedDivisionId;
            return (
              <button
                key={d.id}
                onClick={() => setViewedDivisionId(d.id)}
                className={`p-3 rounded-xl border text-left transition relative ${
                  isActive
                    ? "bg-emerald-500/15 border-emerald-500 text-white shadow"
                    : "bg-slate-900/90 border-slate-800 text-slate-400 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-white">
                    {d.name}
                  </span>
                  {isUserDiv && (
                    <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-black text-[9px] uppercase">
                      YOU
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-400 mt-1 font-mono">
                  Prize: {formatCurrency(d.championPrize)}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Split: 20-Club Standings Table + Matchweek Fixtures */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left 8 Cols: 20-Club League Table */}
        <div className="xl:col-span-8 bg-[#111827] border border-slate-800 rounded-2xl p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-white">
              {divMeta.name} Official Standings (20 Clubs)
            </h3>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block" />
                Top 3: Automatic Promotion
              </span>
              {viewedDivisionId < 5 && (
                <span className="flex items-center gap-1.5 text-rose-400 font-semibold">
                  <span className="w-2.5 h-2.5 rounded-sm bg-rose-500 inline-block" />
                  Bottom 3: Relegation Zone
                </span>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] font-bold uppercase text-slate-400">
                  <th className="py-2.5 px-2">Pos</th>
                  <th className="py-2.5 px-2">Club</th>
                  <th className="py-2.5 px-2 text-center">OVR</th>
                  <th className="py-2.5 px-2 text-center">P</th>
                  <th className="py-2.5 px-2 text-center">W</th>
                  <th className="py-2.5 px-2 text-center">D</th>
                  <th className="py-2.5 px-2 text-center">L</th>
                  <th className="py-2.5 px-2 text-center">GF</th>
                  <th className="py-2.5 px-2 text-center">GA</th>
                  <th className="py-2.5 px-2 text-center">GD</th>
                  <th className="py-2.5 px-2 text-center">Pts</th>
                  <th className="py-2.5 px-2 text-right">Form</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs">
                {standings.map((row, idx) => {
                  const pos = idx + 1;
                  const isPromo = pos <= 3;
                  const isReleg = viewedDivisionId < 5 && pos >= 18;
                  const gd = row.goalsFor - row.goalsAgainst;

                  return (
                    <tr
                      key={row.clubId}
                      className={`transition ${
                        row.isUser
                          ? "bg-emerald-500/15 font-bold"
                          : "hover:bg-slate-900/60"
                      }`}
                    >
                      <td className="py-2.5 px-2 font-mono">
                        <span
                          className={`inline-flex items-center justify-center w-6 h-6 rounded-md text-xs font-black ${
                            pos === 1
                              ? "bg-amber-400 text-slate-950"
                              : isPromo
                              ? "bg-emerald-500/25 text-emerald-300 border border-emerald-500/40"
                              : isReleg
                              ? "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                              : "text-slate-400"
                          }`}
                        >
                          {pos}
                        </span>
                      </td>
                      <td className="py-2.5 px-2">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full shrink-0 border border-white/20"
                            style={{ backgroundColor: row.primaryColor }}
                          />
                          <span
                            className={
                              row.isUser
                                ? "text-emerald-300 font-black"
                                : "text-white font-semibold"
                            }
                          >
                            {row.clubName}
                          </span>
                          {row.isUser && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-black">
                              YOUR CLUB
                            </span>
                          )}
                          {pos <= 3 && viewedDivisionId > 0 && (
                            <ArrowUpCircle className="w-3.5 h-3.5 text-emerald-400 inline" />
                          )}
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-400">
                        {row.overallRating}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">
                        {row.played}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">
                        {row.won}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">
                        {row.drawn}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">
                        {row.lost}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">
                        {row.goalsFor}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-slate-300">
                        {row.goalsAgainst}
                      </td>
                      <td
                        className={`py-2.5 px-2 text-center font-mono font-bold ${
                          gd > 0
                            ? "text-emerald-400"
                            : gd < 0
                            ? "text-rose-400"
                            : "text-slate-400"
                        }`}
                      >
                        {gd > 0 ? `+${gd}` : gd}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-sm font-black text-white">
                        {row.points}
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <div className="inline-flex items-center gap-1">
                          {row.form.slice(-5).map((res, fIdx) => (
                            <span
                              key={fIdx}
                              className={`w-4 h-4 rounded text-[9px] font-black flex items-center justify-center ${
                                res === "W"
                                  ? "bg-emerald-500 text-slate-950"
                                  : res === "D"
                                  ? "bg-slate-600 text-white"
                                  : "bg-rose-500 text-white"
                              }`}
                            >
                              {res}
                            </span>
                          ))}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 4 Cols: Matchweek Fixtures & Division Prize Breakdown */}
        <div className="xl:col-span-4 space-y-4">
          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
            <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2 mb-3">
              <Calendar className="w-4 h-4 text-emerald-400" />
              Matchweek {Math.min(week, maxWeeks)} Fixtures (
              {getDivisionMeta(currentDivisionId).name})
            </h3>
            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {currentWeekFixtures.map((fix) => (
                <div
                  key={fix.id}
                  className={`p-3 rounded-xl border text-xs flex items-center justify-between ${
                    fix.isUserMatch
                      ? "bg-emerald-500/15 border-emerald-500/50"
                      : "bg-slate-900/90 border-slate-800"
                  }`}
                >
                  <div className="flex-1 text-right pr-2 font-bold text-white truncate">
                    {fix.homeClubName}
                  </div>
                  <div className="px-2.5 py-1 rounded bg-slate-950 border border-slate-800 font-mono font-black text-emerald-400 text-xs">
                    {fix.played
                      ? `${fix.homeScore} - ${fix.awayScore}`
                      : "VS"}
                  </div>
                  <div className="flex-1 text-left pl-2 font-bold text-white truncate">
                    {fix.awayClubName}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              Promotion & Prize Rules
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Finish in the <strong>Top 3</strong> of {divMeta.name} after 19
              matchweeks to earn automatic promotion to{" "}
              <strong>
                {viewedDivisionId > 0
                  ? getDivisionMeta(viewedDivisionId - 1).name
                  : "European Champions Glory"}
              </strong>
              !
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-xs">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                <div className="text-[10px] font-sans uppercase text-slate-400 font-bold">
                  1st Place Champion
                </div>
                <div className="text-base font-black text-amber-400 mt-0.5">
                  {formatCurrency(divMeta.championPrize)}
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3">
                <div className="text-[10px] font-sans uppercase text-slate-400 font-bold">
                  Top 3 Promotion Bonus
                </div>
                <div className="text-base font-black text-emerald-400 mt-0.5">
                  {formatCurrency(divMeta.promotionPrize)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
