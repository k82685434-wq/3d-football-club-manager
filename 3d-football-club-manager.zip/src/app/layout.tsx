import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ULTIMATE FOOTBALL CLUB MANAGER — 3D Browser Game",
  description:
    "Playable 3D football club management simulator with 11v11 WebGL 3D matches, club creation studio, transfer market, 6-tier league pyramid, training center, and upgradeable 3D stadium.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#090D16] text-slate-100 antialiased selection:bg-emerald-500 selection:text-slate-950">
        {children}
      </body>
    </html>
  );
}
