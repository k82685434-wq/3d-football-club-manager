import { pgTable, serial, text, integer, jsonb, timestamp } from "drizzle-orm/pg-core";

export const careerSaves = pgTable("career_saves", {
  id: serial("id").primaryKey(),
  slotKey: text("slot_key").notNull().unique(),
  clubName: text("club_name").notNull(),
  managerName: text("manager_name").notNull(),
  divisionId: integer("division_id").notNull().default(5),
  season: integer("season").notNull().default(1),
  week: integer("week").notNull().default(1),
  balance: integer("balance").notNull().default(1250000),
  stadiumLevel: integer("stadium_level").notNull().default(1),
  stateJson: jsonb("state_json").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const matchHistory = pgTable("match_history", {
  id: serial("id").primaryKey(),
  homeClub: text("home_club").notNull(),
  awayClub: text("away_club").notNull(),
  homeScore: integer("home_score").notNull(),
  awayScore: integer("away_score").notNull(),
  divisionName: text("division_name").notNull(),
  season: integer("season").notNull(),
  week: integer("week").notNull(),
  mode: text("mode").notNull().default("career"),
  playedAt: timestamp("played_at").defaultNow().notNull(),
});
