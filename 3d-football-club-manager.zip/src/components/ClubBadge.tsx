"use client";

import React from "react";
import { BadgeConfig, KitConfig } from "@/lib/gameData";

interface ClubBadgeProps {
  badge: BadgeConfig;
  size?: number;
  className?: string;
}

export function ClubBadge({ badge, size = 56, className = "" }: ClubBadgeProps) {
  const uid = React.useId().replace(/:/g, "");

  const getShieldPath = (shape: BadgeConfig["shape"]) => {
    switch (shape) {
      case "hexagon":
        return "M50 4 L92 26 L92 74 L50 96 L8 74 L8 26 Z";
      case "royal":
        return "M14 10 H86 V48 C86 74 68 89 50 96 C32 89 14 74 14 48 Z";
      case "diamond":
        return "M50 4 L94 50 L50 96 L6 50 Z";
      case "circle":
        return "M50 6 A44 44 0 1 1 49.99 6 Z";
      case "classic":
      default:
        return "M12 12 L50 6 L88 12 L86 54 C84 78 66 90 50 96 C34 90 16 78 14 54 Z";
    }
  };

  const renderIcon = (icon: BadgeConfig["icon"], color: string) => {
    switch (icon) {
      case "lion":
        return (
          <path
            d="M36 36 C36 28 44 26 50 26 C56 26 64 28 64 36 C64 42 60 46 60 52 L66 66 H34 L40 52 C40 46 36 42 36 36 Z M44 36 A2 2 0 1 0 44 40 A2 2 0 1 0 44 36 M56 36 A2 2 0 1 0 56 40 A2 2 0 1 0 56 36"
            fill={color}
          />
        );
      case "eagle":
        return (
          <path
            d="M24 38 L42 44 L50 30 L58 44 L76 38 L64 56 L50 68 L36 56 Z"
            fill={color}
          />
        );
      case "crown":
        return (
          <path
            d="M26 62 L30 36 L43 48 L50 32 L57 48 L70 36 L74 62 Z M28 65 H72 V70 H28 Z"
            fill={color}
          />
        );
      case "star":
        return (
          <polygon
            points="50,25 56,42 74,42 60,52 65,69 50,59 35,69 40,52 26,42 44,42"
            fill={color}
          />
        );
      case "lightning":
        return (
          <polygon
            points="54,24 34,52 48,52 44,74 66,46 52,46"
            fill={color}
          />
        );
      case "anchor":
        return (
          <path
            d="M47 28 H53 V58 C60 57 65 52 66 46 H71 C69 57 61 65 50 66 C39 65 31 57 29 46 H34 C35 52 40 57 47 58 V28 Z M42 36 H58 V41 H42 Z"
            fill={color}
          />
        );
      case "flame":
        return (
          <path
            d="M52 24 C56 36 68 42 66 56 C64 66 56 72 48 72 C38 72 32 64 34 52 C36 44 44 40 52 24 Z"
            fill={color}
          />
        );
      case "ball":
      default:
        return (
          <g>
            <circle cx="50" cy="50" r="17" fill={color} />
            <polygon
              points="50,40 58,46 55,56 45,56 42,46"
              fill={badge.secondaryColor}
            />
          </g>
        );
    }
  };

  const path = getShieldPath(badge.shape);

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={`shrink-0 drop-shadow-md ${className}`}
    >
      <defs>
        <clipPath id={`clip_${uid}`}>
          <path d={path} />
        </clipPath>
      </defs>

      <g clipPath={`url(#clip_${uid})`}>
        <rect x="0" y="0" width="100" height="100" fill={badge.primaryColor} />

        {badge.pattern === "stripes" && (
          <>
            <rect x="15" y="0" width="14" height="100" fill={badge.secondaryColor} />
            <rect x="43" y="0" width="14" height="100" fill={badge.secondaryColor} />
            <rect x="71" y="0" width="14" height="100" fill={badge.secondaryColor} />
          </>
        )}

        {badge.pattern === "sash" && (
          <polygon
            points="-10,15 15,-10 110,85 85,110"
            fill={badge.secondaryColor}
          />
        )}

        {badge.pattern === "quartered" && (
          <>
            <rect x="50" y="0" width="50" height="50" fill={badge.secondaryColor} />
            <rect x="0" y="50" width="50" height="50" fill={badge.secondaryColor} />
          </>
        )}

        {badge.pattern === "chevron" && (
          <polygon
            points="0,25 50,62 100,25 100,48 50,85 0,48"
            fill={badge.secondaryColor}
          />
        )}

        {badge.pattern === "solid" && (
          <circle
            cx="50"
            cy="50"
            r="28"
            fill={badge.secondaryColor}
            opacity="0.85"
          />
        )}

        <circle
          cx="50"
          cy="50"
          r="23"
          fill="#090D16"
          fillOpacity="0.65"
          stroke={badge.accentColor}
          strokeWidth="2.5"
        />

        {renderIcon(badge.icon, badge.accentColor)}
      </g>

      <path
        d={path}
        fill="none"
        stroke={badge.accentColor}
        strokeWidth="4"
      />
    </svg>
  );
}

export function KitJerseyPreview({
  kit,
  size = 64,
  label,
}: {
  kit: KitConfig;
  size?: number;
  label?: string;
}) {
  const uid = React.useId().replace(/:/g, "");
  const shirtPath =
    "M28 12 L40 16 L60 16 L72 12 L92 28 L82 44 L70 37 L70 76 L30 76 L30 37 L18 44 L8 28 Z";

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={size} height={size} viewBox="0 0 100 100" className="drop-shadow">
        <defs>
          <clipPath id={`kit_${uid}`}>
            <path d={shirtPath} />
          </clipPath>
        </defs>
        <g clipPath={`url(#kit_${uid})`}>
          <rect x="0" y="0" width="100" height="80" fill={kit.primaryColor} />
          {kit.pattern === "stripes" && (
            <>
              <rect x="34" y="0" width="8" height="80" fill={kit.secondaryColor} />
              <rect x="46" y="0" width="8" height="80" fill={kit.secondaryColor} />
              <rect x="58" y="0" width="8" height="80" fill={kit.secondaryColor} />
            </>
          )}
          {kit.pattern === "hoops" && (
            <>
              <rect x="0" y="26" width="100" height="10" fill={kit.secondaryColor} />
              <rect x="0" y="46" width="100" height="10" fill={kit.secondaryColor} />
              <rect x="0" y="64" width="100" height="10" fill={kit.secondaryColor} />
            </>
          )}
          {kit.pattern === "sash" && (
            <polygon points="20,10 34,10 78,78 64,78" fill={kit.secondaryColor} />
          )}
          {kit.pattern === "halves" && (
            <rect x="50" y="0" width="50" height="80" fill={kit.secondaryColor} />
          )}
        </g>
        <path
          d={shirtPath}
          fill="none"
          stroke="#ffffff33"
          strokeWidth="2.5"
        />
        {/* Shorts */}
        <path
          d="M32 77 H68 L72 95 H53 L50 86 L47 95 H28 Z"
          fill={kit.shortsColor}
          stroke="#ffffff33"
          strokeWidth="2"
        />
      </svg>
      {label && (
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          {label}
        </span>
      )}
    </div>
  );
}
